# D：Codex 评审与 S07 修复证据包

归档日期：2026-10-21。此包包含 5 次视觉评审、S07 修复的 64 项程序回归、28 项保存输出回放检查，以及前期程序验证和报告历史。

- [最新 D 报告](docs/D-阶段性报告.md)
- [逐文件证据索引](docs/D-Codex证据索引.md)
- [可移植验证证据](docs/D-验证证据.json)
- [S07 修复说明](docs/2026-10-21-S07去重修复.md)
- [原始与发布哈希映射](publication-manifest.json)

`evidence/` 与 `docs/history/` 中保留原始归档；原始文件中的历史路径、测试状态和运行时间保持原值。`docs/` 中的当前阅读版使用包内相对链接。`reproduction/source/` 为修复后的精简项目源码；原执行脚本保留在 `reproduction/original-scripts/`，其运行时目录约定保持原值。

在 `reproduction/source/` 中安装依赖后，可使用示例配置运行 `python -m pytest -q -p no:cacheprovider`。原始测试结果记录 64/64 通过；此归档动作没有增加模型评审。
