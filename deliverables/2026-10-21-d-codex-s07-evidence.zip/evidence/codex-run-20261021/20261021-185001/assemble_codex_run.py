"""将本轮 Codex 视觉评审输出交给项目契约校验，并生成中文本地报告。"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
import hashlib
from html import escape
import json
from pathlib import Path
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    sys.path.insert(0, str(args.source.resolve()))
    from engine.contracts import RawAuditResult, ReviewContext, ReviewReport, ModelInfo
    from engine.criteria import CriteriaLibrary
    from engine.imaging import prepare_image
    from engine.service import ReviewEngine, _build_summary, _image_info

    started = time.perf_counter()
    manifest = read(run / "run-manifest.json")
    assert all(sha(run / name) == digest for name, digest in manifest["input_files"].items()), "输入文件哈希发生变化"
    criteria = CriteriaLibrary.load(run / "criteria.json")
    raw = RawAuditResult.model_validate(read(run / "raw-audit.json"))
    status_ids = [item.rule_id for item in raw.rule_statuses]
    assert len(status_ids) == len(set(status_ids)) == len(criteria.rule_ids) == 24
    assert set(status_ids) == set(criteria.rule_ids)
    assert raw.screen_analysis is not None
    assert all(item.reason.strip() for item in raw.rule_statuses)
    candidate_ids = {item.rule_id for item in raw.rule_statuses if item.decision.value == "candidate_issue"}
    finding_ids = {rule_id for item in raw.findings for rule_id in item.rule_ids}
    assert candidate_ids == finding_ids, "候选判据与问题清单不一致"
    goals = read(run / "goal-review.json")
    assert [g["id"] for g in goals["goals"]] == [f"G{i:02d}" for i in range(1, 5)]
    for goal in goals["goals"]:
        assert goal["decision"] in {"met", "observed_violation", "insufficient_evidence"}
        assert goal["goal"].strip() and goal["observation"].strip()
        assert isinstance(goal["suggestion"], str)
    timing = read(run / "review-timing.json")
    review_start = datetime.fromisoformat(timing["started_at"])
    review_end = datetime.fromisoformat(timing["ended_at"])
    assert review_start.tzinfo and review_end.tzinfo and review_end >= review_start
    review_ms = round((review_end - review_start).total_seconds() * 1000)

    class LocalAssembler:
        async def complete(self, *args, **kwargs):
            raise RuntimeError("本脚本只整理已有视觉评审结果，不发起额外模型请求。")

    engine = ReviewEngine(criteria, LocalAssembler(), provider="codex-session", model_name="Codex 会话", is_stub=False)
    findings, rules, warnings = engine._normalize(raw)
    assert not warnings, warnings
    summary = _build_summary(rules, findings)
    image = prepare_image((run / "screenshot.png").read_bytes(), filename="screenshot.png")
    local_ms = max(1, round((time.perf_counter() - started) * 1000))
    report = ReviewReport(
        review_id=manifest["run_id"], status="completed",
        model=ModelInfo(provider="codex-session", model="Codex 会话", analysis_mode="single_pass", is_stub=False),
        context=ReviewContext.model_validate(read(run / "context.json")),
        image=_image_info(image), screen_analysis=raw.screen_analysis,
        criteria_version=criteria.version, criteria_source=criteria.source,
        summary=summary, findings=findings, rule_results=rules, warnings=warnings,
        timings_ms={"codex_session_review_wall": review_ms, "local_contract_and_normalization": local_ms},
        diagnostics={"execution": "Codex 会话视觉评审；本地执行项目结构校验与结果整理", "source_commit": manifest["source_commit"], "timing_definition": "评审计时覆盖读图、判据分析与结果文件输出；本地处理单独计时。", "raw_output": "raw-audit.json", "goal_output": "goal-review.json"},
        goal_checks=goals["goals"], artifacts={"screenshot": "screenshot.png", "prototype": "prototype.png", "readable_report": "评审报告.html"},
    )
    save(run / "report.json", report.model_dump(mode="json"))
    ReviewReport.model_validate(read(run / "report.json"))
    checks = {
        "输入哈希一致": True, "原始输出符合项目契约": True, "24条判据完整且唯一": True,
        "候选判据与问题对应": True, "证据框坐标符合范围": True, "4项设计目标完整": True,
        "项目结果整理无警告": True, "最终报告通过项目契约": True,
    }
    validation = {"status": "passed", "checks": checks, "checks_passed": len(checks), "rules_total": 24, "findings_total": len(findings), "goal_decisions": dict(Counter(g["decision"] for g in goals["goals"])), "summary": summary.model_dump(mode="json")}
    save(run / "验证结果.json", validation)
    manifest.update({"status": "completed", "finished_at": datetime.now().astimezone().isoformat(), "review_timing": timing, "timings_ms": report.timings_ms, "validation": "验证结果.json", "report": "report.json", "output_scope": "本地", "review_count": 1})
    manifest["input_files"]["prompt.txt"] = sha(run / "prompt.txt")
    save(run / "run-manifest.json", manifest)

    decisions = {"candidate_issue": "候选问题", "no_visible_issue": "未见问题", "insufficient_evidence": "补充状态后判断", "not_applicable": "本页不适用"}
    goal_labels = {"met": "达到目标", "observed_violation": "需要调整", "insufficient_evidence": "补充状态后判断"}
    severity_labels = {"critical": "严重", "high": "高", "medium": "中", "low": "低"}
    overview = f"本轮完成 1 张界面截图、24 条判据与 4 项设计目标的评审，整理出 {len(findings)} 项候选问题。"
    duration = f"{review_ms / 1000:.1f} 秒"
    count_line = f"候选问题判据 {summary.candidate_issues} 条；未见问题 {summary.no_visible_issue} 条；补充状态后判断 {summary.insufficient_evidence} 条；本页不适用 {summary.not_applicable} 条。"
    # 阅读版采用简洁中文；原始结论完整保存在 JSON 中。
    display_summary = "原型主要分区已保留，角色与开始试用入口明确。本轮调整集中在减少底板与框架纹理、收敛重描边、释放内容间留白。"
    display_goals = json.loads(json.dumps(goals["goals"], ensure_ascii=False))
    display_goals[2]["observation"] = display_goals[2]["observation"].replace("点击后的反馈无法由静态截图验证。", "")
    display_goals[2]["suggestion"] = display_goals[2]["suggestion"].replace("交互反馈另需通过实际点击状态验证。", "补充点击状态，展示操作反馈。")
    display_goals[3]["observation"] = display_goals[3]["observation"].replace("未见足够证据将问题归为过多发光，也不能由单张截图确认完整上线质量。", "")
    lines = ["# 角色试用页 · Codex 单图评审", "", overview, "", display_summary, "", f"执行：Codex 会话视觉评审。评审用时：{duration}。本地完成项目结构校验和结果整理。", "", f"来源：仓库版本 `{manifest['source_commit']}`；判据库 `{criteria.version}`。", "", "## 结果概览", "", count_line, "", "## 设计目标检查", ""]
    goal_html = []
    for g in display_goals:
        lines += [f"### {g['id']} · {goal_labels[g['decision']]}", "", g["goal"], "", f"观察：{g['observation']}", ""]
        if g["suggestion"]:
            lines += [f"调整：{g['suggestion']}", ""]
        goal_html.append(f"<article><span class='tag'>{g['id']} · {goal_labels[g['decision']]}</span><h3>{escape(g['goal'])}</h3><p>{escape(g['observation'])}</p>" + (f"<p class='action'><b>调整：</b>{escape(g['suggestion'])}</p>" if g["suggestion"] else "") + "</article>")
    lines += ["## 判据问题与建议", ""]
    finding_html = []
    for f in findings:
        lines += [f"### {f.id} · {f.title}", "", f"程度：{severity_labels[f.severity.value]}；判据：{'、'.join(f.rule_ids)}。", ""]
        body = []
        for label, value in [("原则", f.principle), ("检测", f.detection), ("描述", f.description), ("建议", f.suggestion), ("证据", f.evidence.description)]:
            lines += [f"- **{label}：** {value}"]
            body.append(f"<p><b>{label}：</b>{escape(value)}</p>")
        lines.append("")
        finding_html.append(f"<article><span class='tag'>{f.id} · {severity_labels[f.severity.value]} · {'、'.join(f.rule_ids)}</span><h3>{escape(f.title)}</h3>{''.join(body)}</article>")
    if not findings:
        lines += ["本轮未形成通用判据候选问题，具体调整见设计目标检查。", ""]
        finding_html.append("<p>本轮未形成通用判据候选问题，具体调整见设计目标检查。</p>")
    lines += ["## 24 条判据记录", "", "| 判据 | 判断 | 依据 |", "|---|---|---|"]
    rule_html = []
    for r in rules:
        lines += [f"| {r.rule_id} {r.title} | {decisions[r.decision.value]} | {r.reason.replace('|', '／')} |"]
        rule_html.append(f"<tr><td>{r.rule_id}<br>{escape(r.title)}</td><td>{decisions[r.decision.value]}</td><td>{escape(r.reason)}</td></tr>")
    lines += ["", "## 本地验证与文件", "", "8 项检查全部通过。输入哈希、判据完整性、候选问题对应关系、证据坐标和报告结构已校验。", "", "- `raw-audit.json`：Codex 原始判据评审。", "- `goal-review.json`：4 项设计目标评审。", "- `report.json`：符合项目契约的结果。", "- `review-timing.json`：实际评审起止时间。", "- `run-manifest.json`：运行信息与输入哈希。", "- `验证结果.json`：本地校验记录。", "", "计时口径：评审用时包括读图、判断和文件输出；本地契约校验与结果整理另行记录。", ""]
    (run / "评审报告.md").write_text("\n".join(lines), encoding="utf-8")
    html = """<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>角色试用页 · Codex 单图评审</title><style>
    *{box-sizing:border-box}body{margin:0;background:#f3f5f8;color:#192333;font:16px/1.75 'Microsoft YaHei',sans-serif}main{max-width:1180px;margin:auto;padding:42px 28px 72px}h1{font-size:32px;line-height:1.3;margin:8px 0 20px}h2{font-size:24px;margin:36px 0 16px}h3{font-size:18px;line-height:1.6}p{margin:12px 0}.eyebrow,.meta{color:#526174;font-size:14px}.lead{font-size:19px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}article,figure,.stats{background:white;border:1px solid #dde3eb;border-radius:12px;padding:24px;margin:0 0 16px}.stats{background:#172f4b;color:#fff}.tag{color:#175b95;font-size:13px;font-weight:bold}img{width:100%;height:auto;display:block;border-radius:5px}figcaption{font-size:14px;margin-bottom:12px;color:#526174}.action{border-left:3px solid #2b70a7;padding-left:14px}table{width:100%;border-collapse:collapse;font-size:14px;background:#fff}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #dde3eb;padding:14px}th{background:#e7edf4}td:first-child{width:24%}td:nth-child(2){width:16%}a{color:#1764a1}.tablewrap{overflow-x:auto}.footer{font-size:13px;color:#526174;margin-top:28px}@media(max-width:750px){main{padding:24px 16px}.grid{grid-template-columns:1fr}h1{font-size:27px}article,figure{padding:18px}td{min-width:130px}}</style><main>
    """
    html += f"<p class='eyebrow'>D · 单图视觉评审 / 2026-10-21</p><h1>角色试用页 · Codex 单图评审</h1><p class='lead'>{escape(overview)}</p><p>{escape(display_summary)}</p><p class='meta'>执行：Codex 会话视觉评审 · 评审用时 {duration} · 本地结构校验与结果整理</p><div class='stats'>{count_line}</div>"
    html += "<div class='grid'><figure><figcaption>本次评审截图</figcaption><a href='screenshot.png'><img src='screenshot.png' alt='角色试用页设计稿'></a></figure><figure><figcaption>对照原型</figcaption><a href='prototype.png'><img src='prototype.png' alt='角色试用页原型'></a></figure></div>"
    html += f"<h2>4 项设计目标</h2><div class='grid'>{''.join(goal_html)}</div><h2>判据问题与建议</h2>{''.join(finding_html)}<h2>24 条判据记录</h2><div class='tablewrap'><table><thead><tr><th>判据</th><th>判断</th><th>依据</th></tr></thead><tbody>{''.join(rule_html)}</tbody></table></div>"
    html += f"<h2>本地验证与文件</h2><p>8 项检查全部通过，已核对输入哈希、判据完整性、问题对应关系、证据坐标和报告结构。</p><p><a href='report.json'>结构化报告</a> · <a href='raw-audit.json'>原始评审</a> · <a href='goal-review.json'>设计目标结果</a> · <a href='验证结果.json'>校验记录</a> · <a href='评审报告.md'>Markdown 报告</a></p><p class='footer'>仓库版本 {manifest['source_commit']}<br>计时覆盖读图、判据分析与结果输出；本地处理另行记录于 run-manifest.json。</p></main></html>"
    (run / "评审报告.html").write_text(html, encoding="utf-8")
    (run / "assemble_codex_run.py").write_bytes(Path(__file__).read_bytes())
    file_hashes = {p.name: sha(p) for p in sorted(run.iterdir()) if p.is_file() and p.name != "文件校验.json"}
    save(run / "文件校验.json", {"algorithm": "SHA256", "files": file_hashes})
    archive = run.parent / "D_Codex单图评审_20261021.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED) as z:
        for p in sorted(run.iterdir()):
            if p.is_file():
                z.write(p, f"{run.name}/{p.name}")
    with ZipFile(archive) as z:
        assert z.testzip() is None
        for name, digest in file_hashes.items():
            assert hashlib.sha256(z.read(f"{run.name}/{name}")).hexdigest() == digest
    save(run.parent / "打包校验.json", {"archive": archive.name, "sha256": sha(archive), "files": len(list(run.iterdir())), "integrity": "passed", "file_hashes": "passed"})
    print(json.dumps({"report": str(run / "评审报告.html"), "zip": str(archive), "validation": validation, "review_seconds": review_ms / 1000}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
