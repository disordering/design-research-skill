"""D offline execution; no live model calls and no human study results."""
from __future__ import annotations
import asyncio, collections, hashlib, json, os, platform, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
SOURCE = ROOT / 'source/design-research-skill-main'
OUT = WORKSPACE / 'outputs/d_execution_20261021'
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'logs').mkdir(exist_ok=True)
ENV = dict(os.environ)
for name in list(ENV):
    if name.startswith('REVIEW_') or name in ('DASHSCOPE_API_KEY', 'DEEPSEEK_API_KEY', 'OPENAI_API_KEY'):
        ENV.pop(name)
ENV['PYTHONIOENCODING'] = 'utf-8'
ENV['PYTHONDONTWRITEBYTECODE'] = '1'
EXAMPLE = ROOT / 'reviewer.offline.toml'
shutil.copyfile(SOURCE / 'config/reviewer.example.toml', EXAMPLE)
results = {'date': '2026-10-21', 'scope': 'D offline program checks and cached-case metric replay; no real model rerun or human participants', 'source': {'repository': 'https://github.com/disordering/design-research-skill', 'browser_observed_head': '5e08a6628e92dcede3fcb180cca28856633f6689', 'archive_sha256': hashlib.sha256(Path('C:/Users/nozomi222333/Downloads/design-research-skill-main.zip').read_bytes()).hexdigest(), 'config_file_in_archive': (SOURCE / 'config/reviewer.toml').exists(), 'dotenv_file_in_archive': (SOURCE / '.env').exists()}, 'environment': {'python': sys.version, 'platform': platform.platform()}, 'commands': [], 'upload_checks': [], 'metric_replay': {}}

def command(label, args, configured=True):
    env = dict(ENV)
    if configured:
        env['REVIEW_CONFIG'] = str(EXAMPLE)
    started = time.perf_counter()
    proc = subprocess.run([sys.executable, *args], cwd=SOURCE, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    log = OUT / 'logs' / f'{label}.log'
    log.write_text(proc.stdout + '\n' + proc.stderr, encoding='utf-8')
    item = {'name': label, 'args': args, 'exit_code': proc.returncode, 'elapsed_seconds': round(time.perf_counter()-started, 3), 'config': 'empty-key example' if configured else 'unconfigured fresh archive', 'log': str(log.relative_to(OUT))}
    results['commands'].append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)
    return proc

command('pytest_fresh_archive', ['-m', 'pytest', '-q', '-p', 'no:cacheprovider'], configured=False)
command('pytest_with_example_config', ['-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--junitxml='+str(OUT/'logs/pytest_existing.xml')])
command('validate_criteria', ['-m', 'engine', 'validate-criteria'])
command('validate_config_empty_key', ['-m', 'engine', 'validate-config'])
command('health_empty_key', ['-m', 'engine', 'health'])
command('pip_freeze', ['-m', 'pip', 'freeze'])

# The rest calls local code with an explicit stub, never a provider factory.
os.environ.clear()
os.environ.update(ENV)
os.environ['REVIEW_CONFIG'] = str(EXAMPLE)
sys.path.insert(0, str(SOURCE))
os.chdir(SOURCE)
from fastapi.testclient import TestClient
from PIL import Image
from engine.api import create_app
from engine.criteria import CriteriaLibrary
from engine.service import ReviewEngine
from engine.stub import StubModel
from engine.advanced_contracts import OCRResult, UIResult
from engine.contracts import ReviewReport
from engine.cv_metrics import compute_pipeline_metrics
criteria = CriteriaLibrary.load(SOURCE/'判据库_v1.json')
def factory(provider, model):
    return ReviewEngine(criteria, StubModel(), provider='stub', model_name='contract-stub-v1', is_stub=True)
client = TestClient(create_app(engine_factory=factory))
samples = WORKSPACE / 'outputs/d_testing_20261019/samples'
for path in sorted(samples.glob('S*.png')):
    response = client.post('/api/review-audit', files={'image': (path.name, path.read_bytes(), 'image/png')}, data={'design_goal': 'D离线接口验收；不进行真实截图判断', 'platform': 'web', 'analysis_mode': 'two_pass'})
    body = response.json()
    checks = {'http_200': response.status_code == 200, 'is_stub_explicit': body.get('model',{}).get('is_stub') is True, 'all_24_rule_records': len(body.get('rule_results',[])) == 24, 'stub_warning_present': any('Stub' in x for x in body.get('warnings',[]))}
    results['upload_checks'].append({'sample': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'checks': checks, 'passed': all(checks.values()), 'finding_accuracy': 'not_evaluated'})
(OUT/'logs/sample_uploads.json').write_text(json.dumps(results['upload_checks'],ensure_ascii=False,indent=2),encoding='utf-8')

case = SOURCE/'deliverables/2026-10-21-character-trial'
read = lambda name: json.loads((case/name).read_text(encoding='utf-8'))
ReviewReport.model_validate(read('report.json'))
ocr = OCRResult.model_validate(read('ocr.json'))
ui = UIResult.model_validate(read('ui-elements.json'))
reference_ui = UIResult.model_validate(read('prototype-elements.json'))
original_metrics = read('metrics.json')
rounds=[]
for iteration in range(1,4):
    started=time.perf_counter()
    with Image.open(case/'screenshot.png') as img:
        replay=compute_pipeline_metrics(img,ui.elements,ocr.blocks,reference_ui.elements)
    blob=json.dumps(replay,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    rounds.append({'round':iteration,'seconds':round(time.perf_counter()-started,4),'sha256':hashlib.sha256(blob).hexdigest(),'equals_archived_metrics':replay==original_metrics})
    (OUT/'logs'/f'metrics_replay_{iteration}.json').write_text(json.dumps(replay,ensure_ascii=False,indent=2),encoding='utf-8')
results['metric_replay']={'method':'Local deterministic metrics only, using archived OCR/UI boxes. OCR, UI detection, retrieval, audit and narrative models NOT rerun.', 'rounds':rounds, 'three_rounds_equal':len({r['sha256'] for r in rounds})==1, 'archived_report_schema_valid':True}
(OUT/'execution_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'sample_uploads':len(results['upload_checks']),'passed':sum(row['passed'] for row in results['upload_checks']),'metric_replay':results['metric_replay'],'output':str(OUT)},ensure_ascii=False,indent=2))
