"""用已保存的 Codex 输出复现并验证 S07 去重修复，不新增模型调用。"""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument("--phase", choices=["before", "after"], required=True)
args = parser.parse_args()
SOURCE = Path(__file__).parent / "source/design-research-skill-main"
sys.path.insert(0, str(SOURCE))
from engine.contracts import RawAuditResult, ReviewReport
from engine.criteria import CriteriaLibrary
from engine.service import ReviewEngine, _build_summary


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class NoModelCall:
    async def complete(self, *args, **kwargs):
        raise AssertionError("本次仅回放已保存的输出，不调用模型。")


def replay(sample):
    started_at = datetime.now().astimezone().isoformat()
    started = time.perf_counter()
    original = ROOT / f"outputs/d_codex_pilot_v11_20261021/20261021-192850-{sample.lower()}"
    destination = ROOT / f"outputs/d_s07_fix_20261021/replay-{args.phase}/{sample}"
    destination.mkdir(parents=True, exist_ok=True)
    original_hashes = {p.name: sha(p) for p in original.iterdir() if p.is_file()}
    manifest = read(original / "run-manifest.json")
    input_valid = all(sha(original / name) == digest for name, digest in manifest["input_files"].items())
    library = CriteriaLibrary.load(original / "criteria.json")
    raw = RawAuditResult.model_validate(read(original / "raw-audit.json"))
    engine = ReviewEngine(library, NoModelCall(), provider="codex-session", model_name="Codex 会话", is_stub=False)
    findings, rules, warnings = engine._normalize(raw)
    summary = _build_summary(rules, findings)
    data = read(original / "report.json")
    elapsed_ms = max(1, round((time.perf_counter() - started) * 1000))
    data.update({
        "review_id": f"s07-fix-{args.phase}-{sample.lower()}", "status": "partial" if warnings else "completed",
        "findings": [f.model_dump(mode="json") for f in findings], "rule_results": [r.model_dump(mode="json") for r in rules],
        "summary": summary.model_dump(mode="json"), "warnings": warnings,
        "timings_ms": {"saved_output_replay": elapsed_ms},
        "artifacts": {"raw_audit": str(original / "raw-audit.json"), "screenshot": str(original / "screenshot.png"), "validation": "验证结果.json"},
    })
    data["diagnostics"].update({
        "execution": "已保存 Codex 输出的本地程序回放", "phase": args.phase, "new_model_calls": 0,
        "original_review_id": manifest["run_id"], "original_review_timing": read(original / "review-timing.json"),
        "source_copy": str(SOURCE), "source_service_sha256": sha(SOURCE / "engine/service.py"),
        "source_prompting_sha256": sha(SOURCE / "engine/prompting.py"),
        "raw_audit_sha256": original_hashes["raw-audit.json"], "started_at": started_at,
        "finished_at": datetime.now().astimezone().isoformat(),
    })
    result = ReviewReport.model_validate(data)
    save(destination / "report.json", result.model_dump(mode="json"))
    mapping = []
    for i, f in enumerate(raw.findings):
        matched = [x.id for x in findings if x.title == f.title and x.rule_ids == f.rule_ids and x.evidence == f.evidence and x.suggestion == f.suggestion and x.detection == f.detection and x.description == f.description]
        mapping.append({"raw_reference": f"raw.findings[{i}]", "title": f.title, "rule_ids": f.rule_ids, "output_ids": matched, "preserved": len(matched) == 1})
    raw_r17 = [f.evidence.model_dump() for f in raw.findings if "R17" in f.rule_ids]
    result_r17 = [f.evidence.model_dump() for f in findings if "R17" in f.rule_ids]
    checks = {
        "冻结输入哈希一致": input_valid,
        "原始输出符合项目契约": True,
        "原始24条判据完整且唯一": len(raw.rule_statuses) == 24 and {r.rule_id for r in raw.rule_statuses} == set(library.rule_ids),
        "整理后24条判据及状态保持": len(rules) == 24 and {r.rule_id: r.decision for r in rules} == {r.rule_id: r.decision for r in raw.rule_statuses},
        "候选判据与问题覆盖一致": {r.rule_id for r in rules if r.decision.value == "candidate_issue"} == {rid for f in findings for rid in f.rule_ids},
        "本样本全部具体问题保留": len(findings) == len(raw.findings),
        "每项证据及修改动作保持": all(row["preserved"] for row in mapping),
        "R17各位置完整保留": len(raw_r17) == len(result_r17) and all(e in result_r17 for e in raw_r17),
        "候选判据计数正确": summary.candidate_issues == sum(r.decision.value == "candidate_issue" for r in raw.rule_statuses),
        "严重度按问题计数": sum([summary.critical_count, summary.high_count, summary.medium_count, summary.low_count]) == len(findings),
        "问题编号唯一且连续": [f.id for f in findings] == [f"F{i:03}" for i in range(1, len(findings) + 1)],
        "本次整理无警告": not warnings,
        "最终报告通过项目契约": True,
        "原始运行全部文件保持": all(sha(original / name) == digest for name, digest in original_hashes.items()),
    }
    verification = {
        "sample_id": sample, "phase": args.phase, "status": "passed" if all(checks.values()) else "failed",
        "checks": checks, "checks_passed": sum(checks.values()), "checks_total": len(checks),
        "raw_findings": len(raw.findings), "output_findings": len(findings), "candidate_rules": summary.candidate_issues,
        "r17_findings": len(result_r17), "warnings": warnings, "mapping": mapping,
        "elapsed_ms": elapsed_ms, "new_model_calls": 0, "original_files_sha256": original_hashes,
    }
    save(destination / "验证结果.json", verification)
    return verification


results = [replay(s) for s in ["S03", "S07"]]
save(ROOT / f"outputs/d_s07_fix_20261021/回放结果_{args.phase}.json", results)
print(json.dumps([{k: r[k] for k in ["sample_id", "status", "checks_passed", "checks_total", "output_findings", "candidate_rules", "r17_findings", "warnings", "elapsed_ms"]} for r in results], ensure_ascii=False, indent=2))
sys.exit(0 if all(r["status"] == "passed" for r in results) else 1)
