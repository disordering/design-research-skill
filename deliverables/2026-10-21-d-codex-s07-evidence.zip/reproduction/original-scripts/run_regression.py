"""运行完整离线回归并保存逐项结果和日志。"""
from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
SOURCE = Path(__file__).parent / "source/design-research-skill-main"
OUT = ROOT / "outputs/d_s07_fix_20261021"
env = os.environ.copy()
env["PYTHONIOENCODING"] = "utf-8"
env["REVIEW_CONFIG"] = str(SOURCE / "config/reviewer.example.toml")
env["PYTHONPATH"] = str(SOURCE)
for name in ["DASHSCOPE_API_KEY", "DEEPSEEK_API_KEY", "OPENAI_API_KEY", "QWEN_API_KEY"]:
    env.pop(name, None)
command = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--junitxml", str(OUT / "logs/full-regression.xml")]
started_at = datetime.now().astimezone().isoformat()
started = time.perf_counter()
result = subprocess.run(command, cwd=SOURCE, env=env, text=True, encoding="utf-8", errors="replace", stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.perf_counter() - started
(OUT / "logs/full-regression.log").write_text(result.stdout, encoding="utf-8")
cases = []
for case in ET.parse(OUT / "logs/full-regression.xml").getroot().iter("testcase"):
    status = "failed" if case.find("failure") is not None or case.find("error") is not None else "skipped" if case.find("skipped") is not None else "passed"
    cases.append({"module": case.attrib.get("classname"), "name": case.attrib["name"], "status": status})
counts = {status: sum(c["status"] == status for c in cases) for status in ["passed", "failed", "skipped"]}
report = {
    "scope": "本地完整离线回归", "source": str(SOURCE), "started_at": started_at,
    "ended_at": datetime.now().astimezone().isoformat(), "elapsed_seconds": round(elapsed, 3),
    "python": sys.version, "command": command, "exit_code": result.returncode,
    "config": "示例配置；进程内清除提供商密钥；固定模型回复与程序内接口测试",
    "total": len(cases), **counts,
    "existing_cases": sum(c["module"] != "tests.test_finding_deduplication" for c in cases),
    "new_cases": sum(c["module"] == "tests.test_finding_deduplication" for c in cases),
    "updated_existing_cases": 6, "tests": cases,
}
(OUT / "回归测试结果.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(result.stdout)
print(json.dumps({k: report[k] for k in ["total", "passed", "failed", "skipped", "existing_cases", "new_cases", "elapsed_seconds", "exit_code"]}, ensure_ascii=False))
sys.exit(result.returncode)
