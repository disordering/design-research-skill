"""保存本地代码差异、复测证据，并更新 D 报告。"""
from datetime import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[2]
SOURCE = Path(__file__).parent / "source/design-research-skill-main"
OUT = ROOT / "outputs/d_s07_fix_20261021"
DOC = ROOT / "outputs/d_report_update_20261021"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path, base=DOC):
    return Path(os.path.relpath(path, base)).as_posix()


baseline = read(OUT / "修复基线.json")
base = Path(baseline["source_snapshot"])
for name, digest in baseline["source_files"].items():
    assert sha(base / name) == digest, name
test = read(OUT / "回归测试结果.json")
assert (test["total"], test["passed"], test["failed"], test["skipped"], test["new_cases"]) == (64, 64, 0, 0, 16)
before = read(OUT / "回放结果_before.json")
after = read(OUT / "回放结果_after.json")
assert [r["output_findings"] for r in before] == [2, 4]
assert [r["output_findings"] for r in after] == [2, 5]
assert all(r["checks_passed"] == r["checks_total"] == 14 and not r["warnings"] for r in after)
for r in after:
    original = ROOT / f"outputs/d_codex_pilot_v11_20261021/20261021-192850-{r['sample_id'].lower()}"
    for name, digest in r["original_files_sha256"].items():
        assert sha(original / name) == digest
    report = read(OUT / f"replay-after/{r['sample_id']}/report.json")
    assert report["diagnostics"]["source_service_sha256"] == sha(SOURCE / "engine/service.py")
    assert report["diagnostics"]["source_prompting_sha256"] == sha(SOURCE / "engine/prompting.py")
    lines = [f"# {r['sample_id']} 修复后程序回放", "", f"原始 Codex 输出通过修复程序整理，完整保留 {r['output_findings']} 项问题；{r['candidate_rules']} 条候选判据，14 项检查全部通过。", "", "本次为已保存结果的程序回放。原始视觉评审耗时见 report.json 中的来源记录。", ""]
    for f in report["findings"]:
        lines += [f"## {f['id']} · {f['title']}", "", f"判据：{'、'.join(f['rule_ids'])}。", "", f"**证据：** {f['evidence']['description']}", "", f"**建议：** {f['suggestion']}", ""]
    lines += ["[结构化结果](report.json) · [逐项检查](验证结果.json)", ""]
    (OUT / f"replay-after/{r['sample_id']}/评审结果.md").write_text("\n".join(lines), encoding="utf-8")

modified = []
patch = []
for p in sorted(SOURCE.rglob("*")):
    if not p.is_file() or any(s in p.parts for s in ["__pycache__", ".pytest_cache"]):
        continue
    name = p.relative_to(SOURCE).as_posix()
    old_hash = baseline["source_files"].get(name)
    if sha(p) == old_hash:
        continue
    old_text = (base / name).read_text(encoding="utf-8-sig").splitlines(keepends=True) if old_hash else []
    new_text = p.read_text(encoding="utf-8-sig").splitlines(keepends=True)
    patch.extend(difflib.unified_diff(old_text, new_text, fromfile=f"a/{name}" if old_hash else "/dev/null", tofile=f"b/{name}"))
    modified.append({"path": name, "kind": "修改" if old_hash else "新增", "before_sha256": old_hash, "after_sha256": sha(p)})
assert {m["path"] for m in modified} == {
    "engine/service.py", "engine/prompting.py", "tests/test_normalization_conflicts.py",
    "tests/test_finding_deduplication.py", "fixtures/s07_raw_audit.json", "docs/b-engine.md", "docs/2026-10-21-S07去重修复.md",
}
assert sha(SOURCE / "fixtures/s07_raw_audit.json") == sha(ROOT / "outputs/d_codex_pilot_v11_20261021/20261021-192850-s07/raw-audit.json")
(OUT / "本地修改.diff").write_text("".join(patch), encoding="utf-8")
save(OUT / "修改文件清单.json", {"base_commit": baseline["base_commit"], "working_copy": str(SOURCE), "files": modified, "publish_state": "本地保存"})
summary = {
    "问题": "按判据唯一去重使 S07 的第二处 R17 未进入整理结果。",
    "修复": "按精确证据位置、可见表现和修改动作去重；同判据的独立问题分别保留。",
    "完整回归": {k: test[k] for k in ["total", "passed", "failed", "skipped", "existing_cases", "new_cases", "updated_existing_cases", "elapsed_seconds", "started_at", "ended_at"]},
    "前后回放": [{"样本": a["sample_id"], "修复前问题数": b["output_findings"], "修复后问题数": a["output_findings"], "修复前R17数": b["r17_findings"], "修复后R17数": a["r17_findings"], "候选判据数": a["candidate_rules"], "检查通过": a["checks_passed"], "检查总数": a["checks_total"], "本次回放毫秒": a["elapsed_ms"]} for b, a in zip(before, after)],
    "新增模型调用": 0, "累计Codex视觉评审": 5, "回放样本数": 2,
    "源代码复核": "独立代码复核通过；检查去重键、代表项与判据合并、状态覆盖、计数和两处提示词。",
    "历史证据": "原始视觉评审文件和基线源码哈希全部保持", "本地源代码": str(SOURCE),
}
save(OUT / "修复与复测汇总.json", summary)
note = (SOURCE / "docs/2026-10-21-S07去重修复.md").read_text(encoding="utf-8")
note += "\n## 本地证据入口\n\n"
note += "[S07 修复后结果](replay-after/S07/评审结果.md) · [S03 回放结果](replay-after/S03/评审结果.md) · [修复前回放](回放结果_before.json) · [修复后回放](回放结果_after.json)\n\n"
note += "[64 项测试日志](logs/full-regression.log) · [逐项测试结果](回归测试结果.json) · [JUnit 记录](logs/full-regression.xml) · [代码差异](本地修改.diff) · [修改清单](修改文件清单.json)\n"
(OUT / "S07去重修复与复测.md").write_text(note, encoding="utf-8")

backup = DOC / "history/S07去重修复前"
backup.mkdir(parents=True, exist_ok=True)
for name in ["D-阶段性报告.md", "D-验证证据.json", "报告更新校验.json"]:
    if not (backup / name).exists():
        shutil.copy2(DOC / name, backup / name)
report_path = DOC / "D-阶段性报告.md"
text = (backup / report_path.name).read_text(encoding="utf-8-sig")
text = text.replace("本次新增 S03、S07 两次独立评审、7 个具体修改点和作者候选的开发对照。", "已补入 S03、S07 两次独立评审与 7 个具体修改点；本次完成 S07 去重修复、64 项程序回归和两张图的原始输出回放。")
text = text.replace("| 修复后完整测试集 | 48 通过、0 失败、0 跳过 |", "| 前期四项修复后的完整测试集 | 48 通过、0 失败、0 跳过 |")
text = text.replace("| 10 张合成截图上传 |", "| S07 去重修复后的完整测试集 | **64 通过、0 失败、0 跳过** | 48 项既有测试加 16 项新增去重回归；6 项既有用例更新对应关系 |\n| 10 张合成截图上传 |")
text = text.replace("其执行日志和文件哈希见[D 验证证据](D-验证证据.json)。", "其执行日志和文件哈希见[D 验证证据](D-验证证据.json)。本次 64 项完整回归及前后回放见[S07 去重修复与复测](../d_s07_fix_20261021/S07去重修复与复测.md)。")
old = "**结构检查与完整记录。** S03 为 12/12 通过，S07 为 11/12 通过。S07 的一项重复引用检查定位到两处 R17：项目整理输出 4 项并保留提示，D 报告按 v1.1 完整保留原始 5 项及其位置。原始输出、项目输出与完整清单的关系见[输出对应记录](../d_codex_pilot_v11_20261021/20261021-192850-s07/输出对应记录.json)。前期 48 项程序测试、原图三轮一致性和本批开发评测分别记录。"
new = "**结构检查与修复复测。** 首轮检查记录为 S03 12/12、S07 11/12，定位到按判据唯一去重造成的 R17 丢项。本次已修复去重逻辑，用相同原始输出回放后，S07 完整输出 5 项问题、两处 R17，S03 保持 2 项；两张图各通过 14/14 项回放检查。S07 的 4 条候选判据与 5 个具体问题分别计数。最新结果见[修复后 S07 报告](../d_s07_fix_20261021/replay-after/S07/评审结果.md)，首轮记录保存在[原输出对应表](../d_codex_pilot_v11_20261021/20261021-192850-s07/输出对应记录.json)。程序回归、同图一致性和开发评测分别记录。"
assert old in text
text = text.replace(old, new)
section = """### 5. S07 去重修复与回归

原程序以判据编号作为唯一条件，S07 的两条 R17 因而只保留一条。本次改为按具体问题的证据位置、可见表现和修改动作识别重复。同一判据可以关联多个独立问题；真正重复时合并有效判据，并保留最高置信度候选的完整内容，同分采用输入首条。两处模型提示词同步改为每条候选判据至少关联一个问题。

完整离线回归为 **64 通过、0 失败、0 跳过**：48 项既有测试加 16 项新增回归。其中 6 项既有去重用例更新为具体问题的对应关系，继续检查最高置信度选择、稳定顺序与证据独立性。新增测试覆盖不同位置、不同机制和修改动作、跨判据重复合并、非法引用过滤、缺证据降级，以及公开评审入口的完整返回。

| 保存结果的程序回放 | 修复前 | 修复后 | 修复后检查 |
| --- | --- | --- | --- |
| S03 | 2 项问题，3 条候选判据 | 2 项问题，3 条候选判据 | 14/14 通过 |
| S07 | 4 项问题，R17 保留 1 处 | 5 项问题，R17 保留 2 处；候选判据为 4 条 | 14/14 通过 |

两次回放复用已保存的 Codex 原始输出，程序整理均无警告。本次新增模型调用为 0，累计视觉评审仍为 5 次。原始评审、输入和计时按原编号保存；修复后的程序结果单独归档。

修复在基线 `9cadb40afddd213012a1bfefc41356d275836781` 的本地副本中完成。[修复说明](../d_s07_fix_20261021/S07去重修复与复测.md)、[64 项测试日志](../d_s07_fix_20261021/logs/full-regression.log)、[代码差异](../d_s07_fix_20261021/本地修改.diff)和[前后汇总](../d_s07_fix_20261021/修复与复测汇总.json)已归档。

"""
text = text.replace("## V. Vibe Coding 总结（D 部分）", section + "## V. Vibe Coding 总结（D 部分）")
text = text.replace("本轮形成了三项工作方法：", "针对开发评测发现的 S07 去重问题，进一步把判据覆盖与具体问题去重分开处理，同步修改程序和提示词，再用原始输出回放及完整回归验证。修复后两处状态问题直接进入正式结果清单，形成“真实评审输出—程序复现—修复—复测—报告”的记录链。\n\n本轮形成了三项工作方法：")
text = text.replace("## 附录：证据索引与合稿说明\n\n", "## 附录：证据索引与合稿说明\n\n- 最新的[S07 去重修复与复测](../d_s07_fix_20261021/S07去重修复与复测.md)记录 64 项程序回归、两张图的回放结果及本地代码差异。\n")
report_path.write_text(text, encoding="utf-8")

evidence = read(backup / "D-验证证据.json")
files = [p for p in OUT.rglob("*") if p.is_file() and p.name != "交付校验.json"]
files += [SOURCE / m["path"] for m in modified]
files += [Path(__file__), Path(__file__).parent / "run_regression.py", Path(__file__).parent / "replay_saved_audits.py"]
evidence["S07去重修复与回归"] = {**summary, "原始证据文件": [{"相对路径": relative(p), "sha256": sha(p)} for p in files]}
evidence["v1.1合成开发评测"]["最新程序回放"] = {
    "问题数": {"S03": 2, "S07": 5}, "检查": {"S03": "14/14", "S07": "14/14"},
    "汇总": "../d_s07_fix_20261021/修复与复测汇总.json", "新增模型调用": 0,
}
save(DOC / "D-验证证据.json", evidence)
for group in ["Codex同图三轮对照", "v1.1合成开发评测", "S07去重修复与回归"]:
    for item in evidence[group]["原始证据文件"]:
        assert sha((DOC / item["相对路径"]).resolve()) == item["sha256"]
link_count = 0
for path in [report_path, OUT / "S07去重修复与复测.md", *OUT.glob("replay-after/*/评审结果.md")]:
    for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        target = target.split("#")[0]
        if not target or "://" in target:
            continue
        assert (path.parent / target).resolve().exists(), target
        link_count += 1
check = read(backup / "报告更新校验.json")
check.update({
    "报告sha256": sha(report_path), "证据索引sha256": sha(DOC / "D-验证证据.json"),
    "本次工作": "S07 去重逻辑和提示词修复、64 项离线回归、原始输出回放及本地 D 报告更新",
    "新增评审轮数": 0, "本次新增评审轮数": 0, "累计评审轮数": 5,
    "本次程序回放样本数": 2, "最新程序回归": "64 通过、0 失败、0 跳过",
    "最新程序回放检查": {"S03": "14/14", "S07": "14/14"},
    "S07检查记录": "已修复；项目输出5项，R17两处完整保留，无整理警告。首轮11/12记录作为修复前证据保留。",
    "本地链接已核对数量": link_count, "本次更新前报告": "history/S07去重修复前",
    "本次完成时间": datetime.now().astimezone().isoformat(),
})
save(DOC / "报告更新校验.json", check)
save(OUT / "交付校验.json", {
    "状态": "通过", "修改文件数": len(modified), "完整测试": "64/64", "回放": "S03 14/14；S07 14/14",
    "原始运行文件": "哈希全部匹配", "原代码快照": "哈希全部匹配", "本地链接数量": link_count,
    "报告sha256": sha(report_path), "证据索引sha256": sha(DOC / "D-验证证据.json"),
})
print(json.dumps({"测试": "64/64", "S07": "5 项问题，2 处 R17", "回放": "28/28 项检查通过", "修改文件数": len(modified), "本地链接": link_count, "报告": str(report_path)}, ensure_ascii=False, indent=2))
