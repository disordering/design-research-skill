"""整理 D 交付材料并核对证据；不调用模型、不制造研究结果。"""

from collections import Counter
from datetime import datetime
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

HOME = Path(__file__).resolve().parents[2]
ROOT = HOME / "work/d_completion_20261021/source/design-research-skill-main"
BASE = HOME / "work/d_chinese_notes_20261021/source/design-research-skill-main"
OUT = HOME / "outputs/d_completion_20261021"
PACKAGE = OUT / "D交付材料"
FIRST = HOME / "outputs/d_execution_20261021"
FIXES = HOME / "outputs/d_fixes_20261021"
CASE = ROOT / "deliverables/2026-10-21-character-trial"
ZIP_NAME = "2026-10-21-d-evidence.zip"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    PACKAGE.mkdir(parents=True, exist_ok=True)
    first = read(FIRST / "execution_results.json")
    fixes = read(FIXES / "verification_results.json")
    regression = read(FIRST / "evidence/d_runtime_edges_result.json")
    audit = read(CASE / "audit.json")
    report = read(CASE / "report.json")
    manifest = read(CASE / "manifest.json")
    relevance = read(CASE / "criteria-relevance.json")

    checksums = []
    for line in (CASE / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split(maxsplit=1)
        name = name.lstrip("*")
        assert sha(CASE / name) == expected, name
        checksums.append(name)
    assert len(checksums) == 27
    counts = dict(Counter(x["status"] for x in audit["goal_checks"]))
    assert counts == {"met": 7, "observed_violation": 1, "insufficient_evidence": 1}
    selected = sum(x["selected"] for x in relevance)
    assert len(relevance) == 24 and selected == len(audit["rule_statuses"]) == 8
    elapsed = sum(s.get("elapsed_ms", 0) for s in manifest["stages"].values())
    start = datetime.fromisoformat(manifest["created_at"])
    end = max(datetime.fromisoformat(s["updated_at"]) for s in manifest["stages"].values())
    span = (end - start).total_seconds()
    assert elapsed == 273372 and span == 644
    missing = []
    for stage, data in manifest["stages"].items():
        refs = [(f"stages.{stage}.outputs[{i}]", p) for i, p in enumerate(data.get("outputs", []))]
        if data.get("raw_output"):
            refs.append((f"stages.{stage}.raw_output", data["raw_output"]))
        for field, name in refs:
            if not (CASE / name).exists():
                assert (CASE / "raw" / name).is_file(), (field, name)
                missing.append({"字段": field, "原值": name, "正确位置": "raw/" + name})
    assert len(missing) == 6
    assert fixes["passed"] == fixes["total"] == 48 and fixes["failed"] == fixes["skipped"] == 0
    assert regression["passed"] == 3 and regression["failed"] == 5
    assert len(first["upload_checks"]) == 10 and all(x["passed"] for x in first["upload_checks"])

    evidence = []
    groups = [(FIRST, "first-run", ["execution_results.json"], ["logs", "evidence", "reproduce"]),
              (FIXES, "fixes", ["verification_results.json", "review_result.json"], ["logs"])]
    for folder, label, files, dirs in groups:
        sources = [folder / f for f in files]
        for directory in dirs:
            sources.extend(p for p in (folder / directory).rglob("*") if p.is_file())
        for source in sources:
            relative = Path("evidence") / label / source.relative_to(folder)
            copy(source, PACKAGE / relative)
            evidence.append({"包内路径": relative.as_posix(), "sha256": sha(source)})

    unchanged = []
    for p in ROOT.rglob("*"):
        if p.is_file() and (p.suffix == ".py" or CASE in p.parents):
            relative = p.relative_to(ROOT)
            assert (BASE / relative).read_bytes() == p.read_bytes(), relative
            unchanged.append(relative.as_posix())
    summary = {
        "更新日期": "2026-10-21",
        "仓库基线": "b2d4eda777a2734b112b9620720ccd6389f8de20",
        "性质": "D 阶段材料汇编；本轮不重跑模型、软件测试或真人实验，重新核验了归档计数、引用、哈希及代码未变。",
        "修复版本": ["3abffa841b3bf104833ac3c521625d63ff4c7f79", "02fb2fae82aa5f912e228d6fb6f5e2f94e8048bc"],
        "软件测试": {"原有": 15, "首轮风险用例": 8, "新增边界用例": 25, "修复前风险用例通过": 3, "修复前风险用例失败": 5, "根因数": 4, "修复后通过": 48, "修复后失败": 0, "跳过": 0, "范围": "离线模拟及程序内接口", "既有依赖弃用提示": 1},
        "合成上传": {"通过": 10, "总数": 10, "is_stub": True, "可用于准确性结论": False},
        "确定性指标复算": {"轮数": 3, "全部等于归档": all(r["equals_archived_metrics"] for r in first["metric_replay"]["rounds"]), "真实模型重新运行": False},
        "案例本轮复核": {"run_id": manifest["run_id"], "目标状态": counts, "判据筛选数": 24, "深审数": selected, "未深审数": 16, "阶段合计毫秒": elapsed, "时间戳跨度秒": span, "原始文件哈希匹配数": len(checksums), "原归档未修改": True, "未修正的原始清单引用": missing, "候选问题人工状态": report["findings"][0]["review_status"]},
        "本轮源码与原案例逐字节未变": {"结果": True, "文件数": len(unchanged)},
        "待完成真实研究": {"专家标注": "未完成", "真实模型三轮对照": "未完成", "真人识别与体验": "未完成", "界面人工闭环验收": "未完成", "召回率": None, "误报占比": None, "效率提升": None, "体验得分": None},
        "原始证据文件": evidence,
    }
    write_json(ROOT / "docs/D-验证证据.json", summary)

    # 保留可复现源码及单案例，不重复打包课程 PDF 和第三方参考仓库。
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        relative = p.relative_to(ROOT)
        if relative.parts[0] in {"materials", "reference"} or p.name == ZIP_NAME or "__pycache__" in p.parts:
            continue
        copy(p, PACKAGE / relative)
    prep = HOME / "outputs/d_testing_20261019"
    for name in ["01_测试执行手册.html", "03_D测试记录工作簿.xlsx", "判据索引来源.json", "评审者材料_无预设答案.zip"]:
        copy(prep / name, PACKAGE / "preparation" / name)
    for name in ["samples", "主持人参考"]:
        shutil.copytree(prep / name, PACKAGE / "preparation" / name, dirs_exist_ok=True)
    (PACKAGE / "00_从这里开始.txt").write_text(
        "D 交付材料｜2026-10-21\n\n"
        "1. 当前进度与缺项：docs/D-交付进度.md\n"
        "2. 可放进总报告的阶段稿：docs/D-阶段性报告.md\n"
        "3. 单案例结论采用：docs/D-单案例复核勘误.md。原归档完整保留，未重跑模型。\n"
        "4. 真人实验空白表：docs/D-真人测试记录模板.md。preparation/ 内有既有工作簿与10张合成图。\n"
        "5. 只给盲评者 preparation/评审者材料_无预设答案.zip；主持人参考不作专家答案。\n"
        "6. evidence/first-run/ 是修复前证据，evidence/fixes/ 是修复后48项通过证据。\n"
        "7. docs/D-验证证据.json 含汇总与原文件哈希。机器原日志保留英文，未改写。\n"
        "8. 包内 engine/、tests/、config/ 是本次基线源码；代码未修改。材料PDF和第三方参考库仍见GitHub。\n\n"
        "未完成：真实模型重复对照、两位实际符合要求评审者的独立标注和裁决、6–8人实验、界面闭环、全组实名/初稿/录屏。未测指标不是0。\n"
        "复现：在包根目录安装 requirements-dev.txt 的依赖，PowerShell 设置\n"
        "$env:REVIEW_CONFIG = 'config/reviewer.example.toml'\n"
        "python -m pytest -q -p no:cacheprovider\n"
        "本包不包含API密钥。先读说明再执行；真实模型评估需要另外准备环境。\n",
        encoding="utf-8")
    copy(Path(__file__), PACKAGE / "assembly/build_delivery.py")
    (PACKAGE / "assembly/说明.txt").write_text("此脚本保留材料汇编过程，使用原工作区相对目录；解压包内不直接重建。离线测试复现命令见包根目录说明。\n", encoding="utf-8")

    all_files = sorted(p for p in PACKAGE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt")
    # 原案例的 SHA256SUMS.txt 也纳入总清单；仅排除总清单自身。
    all_files.extend(p for p in PACKAGE.rglob("SHA256SUMS.txt") if p.parent != PACKAGE)
    all_files = sorted(set(all_files))
    (PACKAGE / "SHA256SUMS.txt").write_text("".join(f"{sha(p)}  {p.relative_to(PACKAGE).as_posix()}\n" for p in all_files), encoding="utf-8")
    archive = ROOT / "deliverables" / ZIP_NAME
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(PACKAGE.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(PACKAGE).as_posix())
    copy(archive, OUT / "D阶段报告与证据包_20261021.zip")

    # 检查新文档的仓库内链接与打包字节，排除网页及片段锚点。
    links = []
    for doc in [ROOT / "README.md", *sorted((ROOT / "docs").glob("D-*.md"))]:
        for target in re.findall(r"\]\(([^)]+)\)", doc.read_text(encoding="utf-8")):
            if "://" in target or target.startswith("#"):
                continue
            target = target.split("#", 1)[0]
            if target:
                assert (doc.parent / target).exists(), (doc.name, target)
                links.append((doc.name, target))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for p in PACKAGE.rglob("*"):
            if p.is_file():
                assert z.read(p.relative_to(PACKAGE).as_posix()) == p.read_bytes()
        package_count = len(z.namelist())
    result = {"状态": "通过", "新文档相对链接已核对": len(links), "包内文件数": package_count, "包内文件逐字节核对": True, "包内原始证据文件数": len(evidence), "归档哈希匹配": 27, "源码与原归档未变": True, "zip_sha256": sha(archive), "zip_bytes": archive.stat().st_size}
    write_json(OUT / "交付校验.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
