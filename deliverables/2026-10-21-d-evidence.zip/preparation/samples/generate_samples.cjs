const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/nozomi222333/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = __dirname;
const C = {bg:'#F3F5FA',ink:'#172238',sub:'#64748B',line:'#DFE5EF',blue:'#2858D6',light:'#EEF3FF',red:'#D14242',green:'#187B5A'};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const r=(x,y,w,h,fill='#fff',rx=0,stroke='none')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" stroke="${stroke}"/>`;
const t=(x,y,s,size=20,fill=C.ink,weight=400,anchor='start')=>`<text x="${x}" y="${y}" font-family="Microsoft YaHei, sans-serif" font-size="${size}" font-weight="${weight}" fill="${fill}" text-anchor="${anchor}">${esc(s)}</text>`;
const line=(x1,y1,x2,y2,color=C.line,width=1)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}"/>`;
const circle=(x,y,rad,fill,stroke='none',sw=1)=>`<circle cx="${x}" cy="${y}" r="${rad}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
const btn=(x,y,w,label,fill=C.blue,textColor='#fff',h=46)=>r(x,y,w,h,fill,8,fill==='#fff'?C.line:'none')+t(x+w/2,y+h/2+7,label,18,textColor,500,'middle');
const pill=(x,y,label,fill=C.light,color=C.blue,w=104)=>r(x,y,w,28,fill,14)+t(x+w/2,y+20,label,14,color,500,'middle');
const field=(x,y,w,label,value='',placeholder=false)=>t(x,y,label,19,C.ink,500)+r(x,y+17,w,50,'#fff',7,C.line)+t(x+16,y+50,value,18,placeholder?'#98A3B5':C.ink);
function wrap(x,y,s,max=52,size=18,color=C.sub,gap=30){let out=''; const chars=[...s]; for(let i=0;i<chars.length;i+=max)out+=t(x,y+Math.floor(i/max)*gap,chars.slice(i,i+max).join(''),size,color);return out;}
function base(id,title,body,subtitle=''){return `<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900" viewBox="0 0 1440 900">${r(0,0,1440,900,C.bg)}${r(0,0,1440,78,'#fff')}${r(34,23,32,32,C.blue,9)}${t(50,47,'北',18,'#fff',700,'middle')}${t(82,48,'北辰校园',23,C.ink,700)}${t(1204,46,'帮助中心',16,C.sub)}${circle(1364,38,19,C.light)}${t(1364,44,'林',16,C.blue,500,'middle')}${line(0,78,1440,78)}${t(48,135,title,28,C.ink,700)}${subtitle?t(48,171,subtitle,17,C.sub):''}${body}${r(0,867,1440,33,'#EEF1F7')}${t(28,889,'合成测试素材 '+id,13,'#7C899B')}${t(1414,889,'北辰校园 · 演示界面',13,'#7C899B',400,'end')}</svg>`;}
function shell(id,active,body){let side=r(0,78,224,789,'#fff')+t(32,122,'学习空间',15,C.sub,600);['课程总览','我的课程','学习任务','学习报告','收藏资料'].forEach((s,i)=>{let y=155+i*62;side+=r(18,y,188,46,active===i?C.light:'#fff',8)+circle(42,y+22,7,active===i?C.blue:'#B0BACA')+t(62,y+29,s,17,active===i?C.blue:C.sub,active===i?600:400)});return base(id,'',side+body);}
let images=[];
// S01: a complete course page with absent current navigation and competing controls.
{
let b=t(270,135,'设计研究方法',30,C.ink,700)+t(270,172,'2026 秋季学期  /  共 8 个单元',18,C.sub);
b+=r(270,205,1118,132,'#FFCD60',14)+t(301,247,'秋季学习挑战赛',26,'#70420C',700)+t(301,286,'组队打卡，赢取校园周边与积分奖励',20,'#85551D')+btn(1170,246,178,'立即报名','#963A19');
b+=r(270,369,1118,402,'#fff',14)+pill(304,398,'本周内容')+t(304,465,'第 3 单元 · 访谈与观察',27,C.ink,700)+wrap(304,508,'通过结构化访谈与现场观察，理解用户任务、行为及其发生的环境。',42,19)+line(304,576,1354,576);
b+=t(304,624,'学习资料',16,C.sub)+t(304,664,'视频 3 节  ·  讲义 1 份  ·  建议时长 45 分钟',19,C.ink);
['进入学习','收藏单元','查看目录','分享课程'].forEach((s,i)=>b+=btn(304+i*249,701,224,s,'#fff',C.ink));
images.push({id:'S01',title:'课程单元页面',svg:shell('S01',-1,b)});
}
// S02: full three-stage reservation modal.
{
let b=r(48,212,1344,580,'#fff',14)+t(84,264,'空间预约',25,C.ink,600)+t(84,306,'选择一个适合小组讨论的时段',19,C.sub)+r(84,350,1260,250,'#F7F9FC',10);
b+=r(0,78,1440,789,'#15243C',0).replace('fill="#15243C"','fill="#15243C" fill-opacity="0.40"');
b+=r(354,164,732,626,'#fff',18)+t(396,220,'提交预约',28,C.ink,700)+line(396,246,1044,246);
b+=field(396,293,648,'联系人','林同学')+field(396,400,648,'联系电话','138 0000 1234')+field(396,507,648,'使用人数','4 人');
b+=t(396,630,'预约空间：图书馆 A203 讨论室',18,C.sub)+t(396,665,'预约时段：10 月 22 日 14:00—15:00',18,C.sub)+btn(396,707,648,'下一步');
images.push({id:'S02',title:'讨论室预约向导',svg:base('S02','空间服务',b)});
}
// S03: waiting modal, internal pipeline text, absent cancel.
{
let b=r(48,212,1344,580,'#fff',14)+t(88,268,'课程资料',25,C.ink,600)+btn(1170,236,174,'上传资料');
['访谈提纲.pdf','课堂笔记.docx','小组计划.pdf'].forEach((s,i)=>{b+=line(88,330+i*86,1344,330+i*86)+t(112,379+i*86,s,20)+t(1040,379+i*86,'今天 10:42',17,C.sub)});
b+=r(0,78,1440,789,'#15243C').replace('fill="#15243C"','fill="#15243C" fill-opacity="0.40"')+r(353,247,734,420,'#fff',18);
b+=circle(720,329,29,'none','#DAE4FC',7)+`<path d="M 720 300 A 29 29 0 0 1 749 329" fill="none" stroke="${C.blue}" stroke-width="7" stroke-linecap="round"/>`+t(720,398,'正在处理',28,C.ink,600,'middle');
b+=t(720,447,'worker-03 正在执行 ingest_pipeline',20,C.sub,400,'middle')+t(720,485,'state = PENDING_ACK',18,C.sub,400,'middle')+t(720,583,'请勿关闭此页面',17,C.sub,400,'middle');
images.push({id:'S03',title:'课程资料导入等待',svg:base('S03','资料管理',b)});
}
// S04: completion screen with uncertain outcome and vague next action.
{
let b=t(48,171,'课程服务  /  教材补领',17,C.sub)+t(1344,132,'返回申请',17,C.blue,500,'end');
b+=r(263,221,914,519,'#fff',16)+circle(720,302,34,C.light)+t(720,314,'i',34,C.blue,600,'middle');
b+=t(720,387,'请求已入队',30,C.ink,700,'middle')+t(720,434,'REQUEST_ACCEPTED · txn_ref 6E20A7',19,C.sub,400,'middle')+t(720,474,'当前返回值：202',18,C.sub,400,'middle')+line(313,525,1127,525);
b+=btn(402,577,292,'回到列表','#fff',C.ink)+btn(746,577,292,'处理')+t(720,693,'如果需要其他服务，请访问课程服务中心。',17,C.sub,400,'middle');
images.push({id:'S04',title:'教材补领提交结果',svg:base('S04','教材补领',b)});
}
// S05: member setup form, intentionally sparse guidance.
{
let b=r(223,211,994,587,'#fff',16)+t(263,261,'添加项目成员',26,C.ink,700)+t(263,302,'请填写成员资料，完成后点击保存。',18,C.sub);
b+=field(263,355,434,'名称','')+field(743,355,434,'编号','')+field(263,470,434,'联系电话','')+field(743,470,434,'授权范围表达式','');
b+=t(263,598,'备注',19,C.ink,500)+r(263,616,914,66,'#fff',7,C.line)+btn(997,716,180,'保存')+btn(831,716,142,'取消','#fff',C.ink);
images.push({id:'S05',title:'项目成员资料表单',svg:base('S05','项目管理',b,'成员管理  /  添加成员')});
}
// S06: destructive confirmation without cancel or target details.
{
let b=r(48,212,1344,580,'#fff',14)+t(84,264,'我的项目',25,C.ink,600);
['校园导览研究','课程资源整理','新生服务体验'].forEach((s,i)=>b+=line(84,318+i*104,1350,318+i*104)+t(108,377+i*104,s,21)+t(1042,377+i*104,'成员 4 人',18,C.sub));
b+=r(0,78,1440,789,'#15243C').replace('fill="#15243C"','fill="#15243C" fill-opacity="0.44"')+r(409,266,622,361,'#fff',18)+circle(457,319,18,'#FFF0EF')+t(457,327,'!',24,C.red,700,'middle')+t(491,328,'确认删除',25,C.ink,700);
b+=t(452,393,'删除后无法恢复，请确认是否继续。',20,C.ink)+t(452,433,'此操作将移除相关内容。',18,C.sub)+btn(452,526,536,'确认删除',C.red);
images.push({id:'S06',title:'项目删除确认',svg:base('S06','项目空间',b)});
}
// S07: preferences without grouping and without selection cues.
{
let b=r(222,211,996,585,'#fff',16)+t(263,261,'通知偏好',26,C.ink,700)+t(263,299,'设置课程消息与学习空间的显示方式。',18,C.sub);
b+=t(263,354,'课程提醒',19,C.ink,500)+btn(924,326,102,'开启',C.blue)+btn(1043,326,134,'关闭','#fff',C.ink)+line(263,390,1177,390);
b+=t(263,434,'界面主题',19,C.ink,500)+btn(834,406,158,'浅色','#fff',C.ink)+btn(1010,406,167,'深色','#fff',C.ink)+line(263,470,1177,470);
b+=t(263,514,'作业到期',19,C.ink,500)+r(986,490,191,36,'#F1F4F9',18,C.line)+t(1034,515,'ON',15,C.sub,600,'middle')+t(1129,515,'OFF',15,C.sub,600,'middle')+line(263,550,1177,550);
b+=t(263,594,'文字大小',19,C.ink,500)+btn(924,566,102,'标准','#fff',C.ink)+btn(1043,566,134,'较大','#fff',C.ink)+line(263,630,1177,630);
b+=t(263,674,'消息工具',19,C.ink,500)+r(954,646,62,44,'#fff',7,C.line)+r(1032,646,62,44,'#fff',7,C.line)+r(1110,646,62,44,'#fff',7,C.line);
b+=`<path d="M 973 672 l 10 -15 l 6 10 l 10 -8 M 1050 659 h 25 v 18 h -25 z M 1128 658 l 19 19 M 1147 658 l -19 19" fill="none" stroke="#64748B" stroke-width="2.5"/>`;
b+=btn(1011,722,166,'保存设置');
images.push({id:'S07',title:'通知与显示偏好',svg:base('S07','个人设置',b)});
}
// S08: error summary is not connected to fields and gives no remedy.
{
let b=r(223,211,994,588,'#fff',16)+t(263,262,'设计工作坊报名',26,C.ink,700)+r(263,291,914,78,'#FFF1F0',9,'#F5C6C4')+circle(291,330,12,C.red)+t(291,337,'!',18,'#fff',700,'middle')+t(316,337,'E_VALIDATION_422：payload invalid',19,'#AA3333',500);
b+=field(263,424,434,'姓名','林同学')+field(743,424,434,'学号','2026A0147')+field(263,546,434,'邮箱','lin@campus.example')+field(743,546,434,'参加人数','7')+t(263,664,'活动日期：2026 年 10 月 24 日  /  地点：设计楼 203',17,C.sub)+btn(997,716,180,'提交报名')+btn(831,716,142,'返回','#fff',C.ink);
images.push({id:'S08',title:'工作坊报名错误',svg:base('S08','活动报名',b)});
}
// S09: bounded positive control, not a claim of perfect usability.
{
let b=r(223,204,994,616,'#fff',16)+t(263,253,'创建讨论室预约',26,C.ink,700)+t(263,291,'带 * 的项目为必填项。',17,C.sub);
b+=field(263,341,434,'联系人姓名 *','林同学')+field(743,341,434,'联系电话 *','13800001234')+t(743,428,'请输入 11 位中国大陆手机号码。',15,C.sub);
b+=field(263,475,434,'预约日期 *','2026-10-22')+field(743,475,434,'参与人数 *','4')+t(263,562,'格式：YYYY-MM-DD，例如 2026-10-22。',15,C.sub)+t(743,562,'可预约 1–6 人。',15,C.sub);
b+=field(263,608,914,'用途说明（选填）','小组课程讨论')+t(263,695,'填写本次预约的用途，最多 100 字，请勿填写个人敏感信息。',15,C.sub)+btn(997,740,180,'提交预约')+btn(831,740,142,'取消','#fff',C.ink);
images.push({id:'S09',title:'讨论室预约表单',svg:base('S09','空间服务',b)});
}
// S10: a deliberately cropped source view; a full-frame footer labels provenance only.
{
let b=r(0,78,1440,789,'#A4ADBC')+r(-270,130,1540,850,'#fff',18)+t(-220,221,'订单处理',34,C.ink,700)+line(-220,254,1210,254)+t(35,371,'课程资料包',30,C.ink,600)+t(35,425,'订单号：BC-20261019-0412',23,C.sub)+line(-220,485,1210,485)+t(35,553,'当前内容将被移除。',25,C.ink)+t(35,601,'请确认是否继续。',23,C.sub)+btn(937,812,280,'确认删除',C.red, '#fff',68);
images.push({id:'S10',title:'订单操作局部截图',svg:base('S10','',b)});
}
const manifest=[
{id:'S01',title:'课程单元页面',target_user:'首次使用平台的本科生',task:'找到当前所在栏目，并开始学习第 3 单元。',known_context:['完整截图；左侧五项导航属于同一层级。','页面属于“我的课程”；“进入学习”是当前任务的主操作。','黄色挑战赛广告与本次课程学习无关。'],focus_rules:['R01','R19','R20']},
{id:'S02',title:'讨论室预约向导',target_user:'首次预约的学生',task:'填写预约联系人；必要时返回修改房间和时段，或退出本次预约。',known_context:['完整截图；这是三步预约流程的第 2 步：选择时段→填写信息→确认提交。','上一页已选择房间和时段；此时尚未提交预约。','普通预约窗口允许返回修改和安全退出，没有必须锁定用户的业务约束。'],focus_rules:['R02','R08','R09']},
{id:'S03',title:'课程资料导入等待',target_user:'没有软件工程背景的学生',task:'上传课程资料，了解当前处理状态；需要时取消本次导入。',known_context:['完整截图；系统正在处理用户刚上传的 PDF。','用户可安全取消此步骤；导入尚未写入最终资料库，无必须等待的业务限制。','“worker-03”“ingest_pipeline”“PENDING_ACK”是后台内部实现名称；目标用户未学习过这些术语。','只提供这一张截图；没有实际等待时长或后续状态记录。'],focus_rules:['R03','R05','R08']},
{id:'S04',title:'教材补领提交结果',target_user:'第一次申请教材补领的学生',task:'确认补领申请是否已经提交，以及接下来应做什么。',known_context:['完整截图；用户刚点击“提交补领申请”，申请尚需后续审核。','页面顶部“返回申请”和底部“回到列表”都返回同一个申请列表，属于完全相同的操作。','“txn_ref”“REQUEST_ACCEPTED”“202”是后台信息；目标用户没有技术背景。','蓝色按钮文字是“处理”；未提供该按钮的产品行为说明。'],focus_rules:['R04','R05','R06','R11']},
{id:'S05',title:'项目成员资料表单',target_user:'第一次管理课程项目的学生组长',task:'添加一名成员并填写其访问权限。',known_context:['完整截图；“名称”实际要求成员真实姓名，“编号”实际要求学号，而非项目名称或项目编号。','姓名、学号、联系电话为必填；授权范围表达式和备注为选填。','电话号码只接受 11 位数字，不接受空格或区号前缀。','授权范围表达式使用项目专用语法，例如 course:read；普通学生未接受该语法培训。','所有可见帮助均在截图内；输入框此时未聚焦，也未提交。'],focus_rules:['R07','R13','R14','R24']},
{id:'S06',title:'项目删除确认',target_user:'管理多个项目的课程组长',task:'在确认删除前辨认被删除的项目，并决定继续或取消。',known_context:['完整截图；用户此前点击“校园导览研究”的删除操作，删除不可恢复。','弹窗是正式危险操作确认；后台列表仍有多个项目。','必须为用户提供取消路径；没有强制执行删除的业务约束。','评审对象限可见界面，不提供键盘或点击遮罩的行为记录。'],focus_rules:['R10','R15']},
{id:'S07',title:'通知与显示偏好',target_user:'首次调整个人设置的学生',task:'查看当前主题和提醒状态，并按需要修改通知设置。',known_context:['完整截图；“界面主题”是浅色/深色二选一，已存值为浅色；“作业到期”已存值为开启。','“课程提醒”和“作业到期”均为同类开/关设置；不存在需要两套表现方式的业务原因。','通知设置包括课程提醒、作业到期、消息工具；显示设置包括界面主题、文字大小。','消息工具的三项均为可点击操作图标；无常驻文字标签，未提供悬停或辅助技术信息。'],focus_rules:['R12','R16','R17','R18']},
{id:'S08',title:'工作坊报名错误',target_user:'没有工程背景的学生报名者',task:'修正报名失败的信息并再次提交。',known_context:['完整截图；这是点击提交后的错误状态。','本次实际校验失败项是“参加人数”：一次报名最多 6 人；其余字段合法。','错误条显示的是全部错误提示；没有滚动区域或截图外的帮助信息。','E_VALIDATION_422 和 payload 是内部技术术语，目标用户不知道其含义。'],focus_rules:['R21','R22','R23']},
{id:'S09',title:'讨论室预约表单',target_user:'第一次预约讨论室的学生',task:'填写并提交一次 4 人的讨论室预约。',known_context:['完整截图；姓名、手机号、日期、人数是必填，说明选填。','手机号接受 11 位中国大陆手机号；日期接受 YYYY-MM-DD；人数为 1–6 人。','用途说明为普通文字、最多 100 字，不要求专门语法。','截图处于提交前，未显示错误、等待、成功或危险操作确认状态；不提供交互行为证据。'],focus_rules:['R07','R13','R14','R19','R24']},
{id:'S10',title:'订单操作局部截图',target_user:'课程资料购买者',task:'查看当前订单操作，并判断是否继续。',known_context:['原始截图只保留了窗口的中下部；标题区、左边界和底部按钮区均不完整。','缺少前一步操作、完整窗口和实际交互记录；无法确认这是普通操作窗还是正式删除确认窗。','不提供截图外控件、操作可逆性、取消方式及目标对象的其他信息。'],focus_rules:['R08','R10','R15']}
].map(m=>({...m,png:m.id+'.png',source:'synthetic',role:'development-pilot',synthetic_notice:'原创合成界面，仅用于流程试跑，不是真实产品截图或真人测试证据。'}));
const finding=(id,rule_ids,location,phenomenon,reason)=>({id,rule_ids,location,phenomenon,reason,status:'author_candidate_pending_independent_review'});
const candidateKey={
 metadata:{version:'0.1',created_on:'2026-10-19',purpose:'主持人用候选清单；不得在独立标注前给评审者查看。',source:'作者设计时预设的候选问题，未经两名独立评审者标注或裁决。不是专家标准答案，不是系统结果，不是真人测试数据。',unit:'独立可修复问题；同一现象触发多个判据仅记一条候选。',candidate_count:25,scope:'合成开发试跑；不得与真实评估样本混合汇报性能。'},
 samples:[
 {id:'S01',planned_findings:[finding('S01-F01',['R01'],'左侧导航','“我的课程”与其他导航项没有可见选中差异。','当前页面归属已知，同层导航需要标出当前位置。'),finding('S01-F02',['R19'],'课程卡底部四个按钮','“进入学习”与收藏、目录、分享具有相同视觉权重。','开始学习是已知主任务，缺少主操作突出。'),finding('S01-F03',['R20'],'页面上方黄色活动横幅','无关挑战赛占据显著面积并使用比学习按钮更强的对比。','已知任务为开始学习，该信息与任务无关且抢占注意。')]},
 {id:'S02',planned_findings:[finding('S02-F01',['R02'],'弹窗标题和顶部','三步流程第 2 步没有步骤数、阶段名称或可辨认的进度。','总步数与当前步已知，可用步骤条或文字表示。'),finding('S02-F02',['R09'],'弹窗底部操作区','仅有下一步，没有返回上一步修改时段的可见入口。','已知前一步内容可修改，本步骤不是单步表单。'),finding('S02-F03',['R08'],'完整普通弹窗','没有关闭或取消本次预约的可见入口。','此时允许安全退出；这是取消整个流程，与返回上一步是不同任务。')]},
 {id:'S03',planned_findings:[finding('S03-F01',['R03'],'等待区域','“正在处理”及内部状态无法说明当前面向用户的步骤或合理等待预期。','只据截图判断等待说明缺少有用信息，不能据此推断实际超时或卡死。'),finding('S03-F02',['R05'],'两行处理说明','直接向普通学生显示 worker、pipeline、PENDING_ACK 等内部术语。','术语及用户背景已知，应改为可理解的处理说明。'),finding('S03-F03',['R08'],'完整等待弹窗','可取消的导入过程中没有可见取消或关闭入口。','已知可安全取消，无必须锁定用户的理由；仅判断可见路径。')]},
 {id:'S04',planned_findings:[finding('S04-F01',['R04'],'结果主信息','提交后只显示请求入队，没有说明用户的申请是否已提交及后续审核状态。','当前是提交结果页；不能把请求受理等同业务完成。'),finding('S04-F02',['R05'],'结果状态文字','内部事务标识、枚举与返回码直接出现在普通结果说明中。','用户无工程背景，文字应转为业务语言。'),finding('S04-F03',['R06'],'蓝色“处理”按钮','操作名称没有说明对什么执行什么动作。','仅凭当前上下文无法预期点击后去向或效果。'),finding('S04-F04',['R11'],'右上角与底部次操作','完全相同的返回列表操作分别命名为“返回申请”和“回到列表”。','两处行为相同由上下文明确，不依据名字相似猜测行为。')]},
 {id:'S05',planned_findings:[finding('S05-F01',['R07'],'第一行姓名及学号字段','名称、编号没有明确指向成员姓名和学号。','目标填写内容已知，当前词语也可被理解为项目名称和编号。'),finding('S05-F02',['R13'],'整个表单标签','必填项与选填项没有标记或统一说明。','三项必填、两项选填已知，不能要求用户提交后猜。'),finding('S05-F03',['R14'],'联系电话输入框','未说明只接受 11 位数字的格式限制。','存在已知限制，格式并非由字段名完整表达。'),finding('S05-F04',['R24'],'授权范围表达式字段','专门语法字段缺少解释、示例或可见帮助入口。','目标用户无语法背景；此处是理解复杂语义所需帮助，不再另记同一字段格式问题。')]},
 {id:'S06',planned_findings:[finding('S06-F01',['R10'],'确认弹窗操作区','不可恢复删除只提供确认按钮，没有可见取消路径。','危险确认的用途包括允许放弃；不推断 Esc 或遮罩行为。'),finding('S06-F02',['R15'],'确认弹窗正文','确认内容未说明要删除的具体项目及相关内容的范围。','背景有多个项目；用户需要在确认处核对目标。')]},
 {id:'S07',planned_findings:[finding('S07-F01',['R12'],'课程提醒、作业到期控件','同类开关分别使用中文按钮和英文胶囊两套明显不同的样式。','业务上同类且无差异理由，视觉/语言模式不一致。'),finding('S07-F02',['R16'],'消息工具三个图标','自定义符号无文字说明，操作含义难以确认。','只评可见含义；没有悬停、无障碍信息证据，不断言其完全不存在。'),finding('S07-F03',['R17'],'界面主题与作业到期选项','浅色/深色和 ON/OFF 都没有明确选中状态。','已知设置存在已保存值；合并为同一种选择状态缺失。'),finding('S07-F04',['R18'],'五行设置的顺序和标题','通知选项与显示选项交错排列，未见分组或小标题。','已知属于两组任务，相邻关系与分类不一致。')]},
 {id:'S08',planned_findings:[finding('S08-F01',['R21'],'顶部错误条与参加人数字段','错误条没有指出人数字段，该字段也没有就地错误标识。','实际失败字段已知，需要让用户定位错误。'),finding('S08-F02',['R22','R23'],'错误条文案','仅显示内部校验代码和 payload invalid，既难理解也没有修正方法。','用“人数最多 6 人，请修改后提交”等文字可同时解决术语和修正指引；此处合为同一问题。')]},
 {id:'S09',planned_findings:[],planned_decisions:[{rule_ids:['R07','R13','R14','R19'],decision:'未发现可见问题',reason:'仅对已约定范围：字段名称、必填说明、格式限制、主操作突出均有可见支持。不是整页无问题的结论。'},{rule_ids:['R24'],decision:'不适用',reason:'本场景字段为普通姓名、电话、日期、人数和用途文本；没有专用语法或复杂专业字段。'},{rule_ids:['R03','R04','R10','R21','R22','R23'],decision:'不适用',reason:'当前是提交前普通表单；没有等待、完成、危险确认或错误状态。'}]},
 {id:'S10',planned_findings:[],planned_decisions:[{rule_ids:['R08','R10','R15'],decision:'证据不足',reason:'窗口类型和完整控件区不可见，不能从裁切区域未出现取消/标题推断完整界面缺少它们。'}]}
 ]
};
function galleryHTML(){return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>交互评审 · 合成试跑样本</title><style>body{margin:0;background:#f3f5fa;color:#172238;font:16px/1.7 "Microsoft YaHei",sans-serif}header,main{max-width:1180px;margin:auto;padding:28px}h1{font-size:30px;margin:0 0 10px}header p{max-width:1000px;color:#59677a;margin:8px 0}nav{display:flex;flex-wrap:wrap;gap:8px;margin-top:20px}nav a{color:#2858d6;text-decoration:none;background:white;border:1px solid #dfe5ef;border-radius:7px;padding:5px 14px}article{background:white;border:1px solid #dfe5ef;border-radius:16px;padding:26px;margin-bottom:30px;scroll-margin-top:20px}h2{margin:0 0 10px;font-size:24px}.meta{color:#546176}.context{background:#f7f9fc;padding:16px 20px;border-radius:10px;margin:16px 0}ul{padding-left:24px;margin:8px 0}img{width:100%;display:block;border:1px solid #dfe5ef;border-radius:10px}.hint{font-size:14px;color:#738198}.badge{font-size:13px;background:#eef3ff;color:#2858d6;padding:4px 9px;border-radius:6px;margin-left:10px}footer{padding:24px;text-align:center;color:#738198}@media print{nav{display:none}article{break-before:page;border:0}img{width:100%}header{padding-bottom:0}}</style><header><h1>交互评审 · 合成试跑样本</h1><p>10 张原创合成界面，用于检查评审流程、记录表和判据是否容易操作。它们不是实际产品截图，也不能替代真实样本与独立人工标注。</p><p>请先阅读每张图的用户、任务和已知上下文，再独立记录候选问题、未发现可见问题、证据不足或不适用。只依据提供的可见证据与上下文；同一问题触发多个判据时只计一条问题。此页面不提供预设答案。</p><nav>${manifest.map(m=>`<a href="#${m.id}">${m.id}</a>`).join('')}</nav></header><main>${manifest.map(m=>`<article id="${m.id}"><h2>${m.id} · ${esc(m.title)}<span class="badge">合成 / 开发试跑</span></h2><div class="meta"><b>目标用户：</b>${esc(m.target_user)}<br><b>任务：</b>${esc(m.task)}</div><div class="context"><b>已知上下文</b><ul>${m.known_context.map(c=>`<li>${esc(c)}</li>`).join('')}</ul></div><a href="${m.png}" target="_blank"><img src="${m.png}" alt="${esc(m.id+' '+m.title)}"></a><p class="hint">点击图片可查看 1440 × 900 原图。请不要在独立标注前阅读主持人用候选清单。</p></article>`).join('')}</main><footer>版本 0.1 · 2026-10-19 · 原创合成素材，无真实个人资料</footer></html>`;}
(async()=>{
 fs.mkdirSync(path.join(root,'svg'),{recursive:true});
 for(const im of images){fs.writeFileSync(path.join(root,'svg',im.id+'.svg'),im.svg);await sharp(Buffer.from(im.svg)).png().toFile(path.join(root,im.id+'.png'));}
 fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(manifest,null,2)+'\n','utf8');
 fs.writeFileSync(path.join(root,'candidate_key.json'),JSON.stringify(candidateKey,null,2)+'\n','utf8');
 fs.writeFileSync(path.join(root,'gallery.html'),galleryHTML(),'utf8');
 let thumbs=[];for(let i=0;i<images.length;i++){let buf=await sharp(path.join(root,images[i].id+'.png')).resize(432,270).toBuffer();thumbs.push({input:buf,left:(i%2)*452,top:Math.floor(i/2)*292});}
 await sharp({create:{width:884,height:1438,channels:3,background:'#dfe5ef'}}).composite(thumbs).png().toFile(path.join(root,'contact_sheet.png'));
 const count=candidateKey.samples.reduce((n,s)=>n+s.planned_findings.length,0);if(count!==candidateKey.metadata.candidate_count)throw new Error('candidate count mismatch '+count);
 console.log(JSON.stringify({samples:images.length,candidates:count,root},null,2));
})();
