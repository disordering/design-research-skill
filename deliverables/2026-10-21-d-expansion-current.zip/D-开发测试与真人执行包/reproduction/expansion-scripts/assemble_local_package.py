"""整理本轮 D 本地交付包；保留原始证据，不发布、不改同学源码。"""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import shutil

ROOT = Path(__file__).resolve().parents[2]
BATCH = ROOT / 'outputs/d_expansion_20261021'
BASE = ROOT / 'work/d_s07_publish_20261021/package'
OUT = BATCH / 'package'
NEW = OUT / 'evidence/codex-expansion-20261021'
SOURCE = ROOT / 'work/d_expansion_20261021/latest-source/design-research-skill-main'
ENGINE_HEAD = 'fd36cef42a558104f060f198e74f7cc814fa41dc'
C_HEAD = '9780c03eb9efffb1e26f1acab58685d90a8df05f'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')

def write_json(path, value):
    write(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy_file(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

shutil.copytree(BASE, OUT, dirs_exist_ok=True)
history = OUT / 'docs/history/s07-published-20261021'
for name in ['D-阶段性报告.md', 'D-交付进度.md', 'D-验证证据.json']:
    copy_file(BASE / 'docs' / name, history / name)
copy_file(BASE / 'publication-manifest.json', history / 'publication-manifest.json')
copy_file(BASE / 'README.md', history / 'README.md')

for folder in ['runs', 'qa']:
    shutil.copytree(BATCH / folder, NEW / folder, dirs_exist_ok=True)
for name in ['执行计划.json', '批次校验状态.json', '作者候选开发对照.json', 'GitHub最新核对.json']:
    copy_file(BATCH / name, NEW / name)
copy_file(BATCH / '作者候选开发对照.md', NEW / '作者候选开发对照.original.md')
shutil.copytree(BATCH / 'human-study', OUT / 'human-study', dirs_exist_ok=True)
shutil.copytree(BATCH / 'frontend-qa', OUT / 'frontend-qa', dirs_exist_ok=True)

# 保存当前源码和同学提交原文，便于按版本复核。
current_source = OUT / 'reproduction/source-9780c03'
for folder in ['config', 'engine', 'fixtures', 'frontend', 'tests']:
    shutil.copytree(SOURCE / folder, current_source / folder, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '*.pyc'))
for name in ['.env.example', '判据库_v1.json', 'README.md', 'requirements.txt', 'requirements-dev.txt', 'requirements-perception.txt']:
    copy_file(SOURCE / name, current_source / name)
for name in ['交互界面README要求核对.md', '交互界面复审补充功能已实现与B替换说明.md', '交互界面课程报告初稿.md', '本地联调测试结果.md']:
    copy_file(SOURCE / name, OUT / 'reference/c-delivery-9780c03' / name)
for name in ['prepare.py', 'finalize.py', 'build_human_kit.py', 'test_recognition.cjs', 'check-s07-frontend.mjs', 'assemble_local_package.py']:
    copy_file(ROOT / 'work/d_expansion_20261021' / name, OUT / 'reproduction/expansion-scripts' / name)

# JSON 原路径保留，阅读版链接改成包内相对地址。
prefixes = {
    'outputs/d_expansion_20261021/': 'evidence/codex-expansion-20261021/',
    'outputs/d_codex_pilot_v11_20261021/': 'evidence/codex-pilot-v11-20261021/',
    'outputs/d_s07_fix_20261021/': 'evidence/s07-fix-20261021/',
    'outputs/d_testing_20261019/': 'evidence/development-samples-20261019/',
}

def mapped_path(source_path):
    for old, new in prefixes.items():
        if source_path.startswith(old):
            return new + source_path[len(old):]
    raise ValueError(source_path)

comparison = read_json(BATCH / '作者候选开发对照.json')
path_index = []
for original_path, expected_hash in comparison['source_sha256'].items():
    packaged = mapped_path(original_path)
    assert (OUT / packaged).is_file(), packaged
    assert sha(OUT / packaged) == expected_hash, packaged
    path_index.append({'source_path': original_path, 'package_path': packaged,
                       'sha256': expected_hash, 'byte_identical': True})
write_json(NEW / '原路径与包内路径映射.json', {
    'description': '原始 JSON 中工作区路径及 #/JSON 指针保留原文；读取时将路径按此表转换，指针保持不变。',
    'path_base': '交付包根目录', 'files': path_index,
})
comparison_md = (BATCH / '作者候选开发对照.md').read_text(encoding='utf-8')
for old, new in {
    '../d_codex_pilot_v11_20261021/': '../codex-pilot-v11-20261021/',
    '../d_s07_fix_20261021/': '../s07-fix-20261021/',
    '../d_testing_20261019/': '../development-samples-20261019/',
}.items():
    comparison_md = comparison_md.replace(old, new)
comparison_md += '\n包内原路径解析见[路径映射](原路径与包内路径映射.json)；原始 JSON 的文件路径和 JSON 指针保持原文。\n'
write(NEW / '作者候选开发对照.md', comparison_md)

# 根据实际报告逐项汇总，不用写死的表格作为计算来源。
batch_validations = read_json(BATCH / '批次校验状态.json')
new_rows = []
for validation in sorted(batch_validations, key=lambda item: item['sample_id']):
    run_dir = BATCH / 'runs' / validation['run_id']
    report = read_json(run_dir / 'report.json')
    timing = read_json(run_dir / 'review-timing.json')
    counts = collections.Counter(item['decision'] for item in report['rule_results'])
    assert len(report['rule_results']) == 24
    assert len(report['findings']) == validation['findings']
    new_rows.append({
        'sample_id': validation['sample_id'], 'run_id': validation['run_id'],
        'review_source': '本轮独立 Codex 视觉评审', 'findings': len(report['findings']),
        'rule_statuses': dict(counts), 'checks_passed': validation['checks_passed'],
        'checks_total': validation['checks_total'], 'review_seconds': timing['elapsed_seconds'],
        'local_ms': validation['local_ms'],
        'report': 'evidence/codex-expansion-20261021/runs/' + validation['run_id'] + '/report.json',
        'source_commit': report['diagnostics']['source_commit'],
    })
synthetic_rows = [item for item in new_rows if item['sample_id'].startswith('S')]
for sid in ['S03', 'S07']:
    report = read_json(OUT / f'evidence/s07-fix-20261021/replay-after/{sid}/report.json')
    run_id = f'20261021-192850-{sid.lower()}'
    timing = read_json(OUT / f'evidence/codex-pilot-v11-20261021/{run_id}/review-timing.json')
    synthetic_rows.append({
        'sample_id': sid, 'run_id': run_id, 'review_source': '既有独立 Codex 视觉评审；采用修复后回放报告',
        'findings': len(report['findings']),
        'rule_statuses': dict(collections.Counter(item['decision'] for item in report['rule_results'])),
        'checks_passed': 14, 'checks_total': 14,
        'review_seconds': timing['elapsed_seconds'],
        'report': f'evidence/s07-fix-20261021/replay-after/{sid}/report.json',
        'source_commit': ENGINE_HEAD,
    })
synthetic_rows.sort(key=lambda item: item['sample_id'])
def totals(rows):
    statuses = collections.Counter()
    for row in rows:
        statuses.update(row['rule_statuses'])
    return {'samples': len(rows), 'findings': sum(row['findings'] for row in rows),
            'rule_instances': sum(statuses.values()), 'rule_statuses': dict(statuses),
            'review_seconds': sum(row['review_seconds'] for row in rows)}
goal_review = read_json(BATCH / 'runs/20261021-204528-p01/goal-review.json')
goal_counts = dict(collections.Counter(goal['decision'] for goal in goal_review['goals']))
assert totals(synthetic_rows)['findings'] == 24
assert totals(new_rows)['findings'] == 17
assert sum(row['checks_total'] for row in new_rows) == 167
assert sum(row['checks_passed'] for row in new_rows) == 167
assert len(goal_review['modification_suggestions']) == 2
assert all(item['status'] == 'passed' for item in batch_validations)
frontend = read_json(BATCH / 'frontend-qa/C前端交付验收.json')
browser_qa = read_json(BATCH / 'frontend-qa/浏览器操作验收.json')
instrument = read_json(BATCH / 'qa/实验工具逻辑校验.json')
summary = {
    'date': '2026-10-21', 'execution': '本轮新增 9 次 Codex 会话视觉评审，本地保存',
    'visual_reviews': {'new': 9, 'previous': 5, 'cumulative': 14,
                       'previous_original_protocol': 3, 'v11_synthetic': 10, 'v11_project': 1},
    'source_commits': {'review_normalization': ENGINE_HEAD, 'latest_C_delivery': C_HEAD},
    'new_reviews': totals(new_rows), 'synthetic_cases': totals(synthetic_rows),
    'v11_all_cases': totals(synthetic_rows + [row for row in new_rows if row['sample_id'] == 'P01']),
    'p01': {'generic_findings': 0, 'goal_statuses': goal_counts,
            'unique_goal_suggestions': len(goal_review['modification_suggestions']),
            'g02_subcriteria': {item['id']: item['decision'] for item in goal_review['goals'][1]['subcriteria']},
            'run_count_under_v11': 1},
    'checks': {
        'new_review_structure': {'passed': 167, 'total': 167},
        'previous_engine_regression': {'passed': 64, 'total': 64, 'execution': '前次已发布回归记录，本轮源码未改，不重复计数'},
        'previous_s03_s07_replay': {'passed': 28, 'total': 28, 'execution': '既有保存输出回放'},
        'frontend_unit_tests': frontend['tests'], 's07_adapter': frontend['s07_adapter'],
        'frontend_browser_mock': {'passed': browser_qa['通过'], 'total': browser_qa['总数'],
                                  'scope': '模拟演示 v1—v4 的操作流程与字段保存核对',
                                  'evidence': 'frontend-qa/浏览器操作验收.json',
                                  'next_alignment': browser_qa['后续对齐']},
        'recognition_tool_logic': instrument,
    },
    'author_candidate_comparison': comparison['summary'],
    'human_research': {'independent_reviewer_records': 0, 'consensus_records': 0, 'participant_records': 0,
                       'collection_kit': 'human-study/', 'data_status': '执行材料已备齐，真实记录由参与者完成'},
    'new_run_details': new_rows, 'all_synthetic_cases': synthetic_rows,
}
write_json(NEW / '本轮统计汇总.json', summary)

def row_table(rows, link_prefix='../'):
    lines = ['| 样本 | 候选判据 | 未见问题 | 需补充信息 | 本页不适用 | 具体发现 | 用时 | 结果 |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    for row in rows:
        s = row['rule_statuses']
        lines.append(f"| {row['sample_id']} | {s.get('candidate_issue',0)} | {s.get('no_visible_issue',0)} | {s.get('insufficient_evidence',0)} | {s.get('not_applicable',0)} | {row['findings']} | {row['review_seconds']} 秒 | [报告]({link_prefix}{row['report']}) |")
    s = totals(rows)
    c = s['rule_statuses']
    lines.append(f"| 合计 | {c.get('candidate_issue',0)} | {c.get('no_visible_issue',0)} | {c.get('insufficient_evidence',0)} | {c.get('not_applicable',0)} | {s['findings']} | {s['review_seconds']} 秒 | {s['rule_instances']} 条状态 |")
    return '\n'.join(lines)

overview = '''# D 本轮开发测试总览

2026 年 10 月 21 日。本轮完成 8 张合成图与 P01 的 9 次独立 Codex 视觉评审；连同已有 S03、S07，10 张开发图全部形成评审结果。累计视觉评审为 14 次：原口径同图 3 次、v1.1 合成图 10 次、P01 新口径 1 次。

## 10 张开发图的结果

'''+row_table(synthetic_rows)+'''

10 张图共 240 个判据实例，形成 **24 项具体发现**。S03、S07 沿用各自独立评审的原始输出，采用去重修复后的正式报告；其余 8 张为本轮新运行。候选判据按规则编号计数，发现按具体位置与修改动作计数。

S09 为完整表单，9 条判据未见问题、15 条不适用；S10 为裁切窗口，7 条判据需补充信息。两者均为 0 项具体发现，各自的证据状态完整保留。

## P01 项目案例

P01 使用原截图、原型、4 项原始设计目标和 v1.1 口径。G01 布局分区与 G02 视觉焦点、可读性、留白达到目标；G02 的三个子项分别给出证据。G03、G04 形成 **2 项独立建议**：简化奖励板的点阵、渐变与粗重尖角框；减少开始试用按钮外围的锯齿衬形与重复轮廓。M01 同时关联 G03、G04，仍计为一项建议。

通用判据记录为 0 项候选、6 项未见问题、2 项需补充信息、16 项不适用。该轮用时 286 秒，通过 23 项结构检查。[P01 完整报告](../evidence/codex-expansion-20261021/runs/20261021-204528-p01/评审结果.md) · [设计目标原始输出](../evidence/codex-expansion-20261021/runs/20261021-204528-p01/goal-review.json)。

原口径三轮的 22/24 判据一致、3/4 目标一致保持原统计范围；P01 v1.1 本轮为单次运行。

## 新增 9 次运行与检查

'''+row_table(new_rows)+'''

9 次原始输出经 `fd36cef` 版本引擎整理，**167/167 项结构检查通过**，整理警告为 0。每轮保留截图、上下文、判据、口径、原始评审、计时与文件哈希。独立复核查看了 9 张截图及 P01 原型，并核对目标建议去重、双向引用与汇总计数。[独立复核](../evidence/codex-expansion-20261021/qa/独立复核.md) · [统计 JSON](../evidence/codex-expansion-20261021/本轮统计汇总.json)。

## 25 条作者候选的开发对照

25 条作者候选中，22 条完整对应、1 条范围收敛、1 条部分对应、1 条判定依据不同。24 条已建立映射的候选对应 23 项独立发现；S08 另新增 1 项“人数上限持续提示”，共 24 项发现。S09、S10 的 14 条预设判据状态逐项一致。这里统计开发候选与发现的对应关系，双人共识参考用于下一轮效果指标。[逐项对照](../evidence/codex-expansion-20261021/作者候选开发对照.md)。

## C 交付与界面验收

GitHub 最新提交 `9780c03` 已交付 `frontend/`、界面要求核对、复审补充说明、课程报告初稿及既有联调记录。C 的 III.2、IV.2 和 IV.3 初稿可以进入统稿。前端 9 项离线测试、6 个文件语法检查全部通过；S07 保存结果的前端适配 **8/8 项通过**，5 项发现、24 条判据和两处 R17 均完整保留。

界面浏览器验收采用模拟演示流程，完成 v1—v4 四轮操作与导出，**11/11 项流程及字段保存核对通过**。目标、人工审核、严重度、反馈和逐问题复审记录均有导出证据，刷新后恢复保存状态。操作范围及下一次界面对齐项见[浏览器操作验收](../frontend-qa/浏览器操作验收.md)。源码及离线测试结论见[C 前端交付验收](../frontend-qa/C前端交付验收.md)。代码版本、模拟操作、保存结果适配和后续完整模型联调分别留档。

## 真人执行材料

已整理两位评审者盲评目录、独立标注模板和共识表；P01 五秒识别页面、固定问题与主持人判分卡；四个人工介入节点的操作计时与体验问卷。识别工具的 9 项流程逻辑检查通过，研究记录表保持空白，设备演练单独归档。[执行清单](../human-study/00_执行清单.md) · [主持人执行卡](../human-study/recognition/主持人执行卡.md)。

接续回收两份独立标注与共识、6–8 位真实参与者记录及工具计时问卷，再计算正式效果指标。成员姓名学号、个人贡献与各章节原稿由成员填写后合稿。完整模型联调按前端—引擎—实际模型—人工反馈—导出的链路另存一轮日志。
'''
write(OUT / 'docs/D-本轮开发测试总览.md', overview)

report = (BASE / 'docs/D-阶段性报告.md').read_text(encoding='utf-8')
first_end = report.index('\n\n## I.1')
report = '# D：测试与文档阶段性报告\n\n更新日期：2026 年 10 月 21 日。本报告汇总 D 负责的软件测试、案例评审、结果复核和文档整理。现已完成 10 张开发图评审、P01 新口径评审、25 条作者候选对照与 C 前端验收；累计保存 14 次 Codex 视觉评审。本轮结果和真人执行材料保存在本地交付包。' + report[first_end:]
report = report.replace('新运行按 v1.1 独立编号。已用 S03 检查术语判断、S07 检查可选项分组；接续使用 P01 检查项目案例的目标子项，再扩展其余 8 张合成图。既有三轮作为原口径记录保留。材料位置和工作簿核对结果见[现有材料与下一轮测试](D-现有材料与下一轮测试.md)。',
'''新运行按 v1.1 独立编号。已完成 S03、S07、其余 8 张合成图和 P01 项目案例的评审。10 张合成图形成 24 项具体发现；P01 形成 2 项设计目标修改建议。既有三轮作为原口径记录保留。本轮完整统计见[开发测试总览](D-本轮开发测试总览.md)，样本整理过程保存在[现有材料与下一轮测试](D-现有材料与下一轮测试.md)。''')
start = report.index('### 5. 后续评估安排')
end = report.index('\n## IV.3', start)
report = report[:start] + '''### 5. v1.1 扩展样本与项目案例

本轮使用固定输入，在新上下文中完成 8 张合成图及 P01 的 9 次 Codex 会话视觉评审。每轮先保存原始结果，再核对作者候选，最后使用已发布的 `fd36cef` 引擎完成契约检查与结果整理。9 次新运行共 216 个判据实例、17 项通用发现；结构检查为 **167/167 通过**，整理警告为 0。

连同 S03、S07，10 张合成开发图现已全部形成结果：**240 个判据实例、26 个候选判据实例、24 项具体发现**。各图数量如下，S03、S07 采用已保存评审的修复后回放报告。

''' + row_table(synthetic_rows) + '''

**P01 的新口径结果。** G01“布局与功能分区”和 G02“视觉层级、可读性与留白”达到目标；G02 的三个子项分别达到。G03、G04 对应 2 项独立修改建议：简化奖励底板的点阵、渐变与粗重尖角框；减少开始试用按钮外围的锯齿衬形与重复轮廓。该轮通用候选为 0，目标建议单独计数。[P01 原始目标评审](../evidence/codex-expansion-20261021/runs/20261021-204528-p01/goal-review.json)。

**作者候选对照。** 25 条预设候选中，22 条完整对应、1 条范围收敛、1 条部分对应、1 条判定依据不同。24 条已映射候选对应 23 项独立发现；S08 另增加 1 项人数上限持续提示，合计 24 项发现。此处统计开发候选的对应关系，正式召回率与误报占比采用两位评审者的共识参考计算。[逐条依据](../evidence/codex-expansion-20261021/作者候选开发对照.md)。

本轮各次报告、计时、判定过程和哈希均独立保存。9 张图及 P01 原型经另一轮独立复核，重点检查了 G02 子项汇总、两条目标建议的去重和引用、同一规则的多处发现、S09 完整表单与 S10 裁切窗口的证据状态。[批次总览](D-本轮开发测试总览.md) · [独立复核](../evidence/codex-expansion-20261021/qa/独立复核.md)。累计 14 次视觉评审由原口径同图 3 次、v1.1 合成图 10 次、P01 1 次组成；原口径三轮一致率沿用其原范围。

### 6. C 前端与人工介入流程验收

C 在 `9780c03` 提交了前端界面、复审补充说明和课程报告初稿。D 核对当前源码并执行前端已有测试：**9/9 项离线测试通过**，6 个文件语法检查通过。将 S07 修复后报告送入当前适配器，**8/8 项核对通过**，5 项问题、24 条判据和两处 R17 的独立编号及坐标完整保留。

界面覆盖目标确认、问题确认或驳回、严重度调整、修改稿复审四个人工介入节点。浏览器验收使用模拟演示流程，完成 v1—v4 四轮操作，**11/11 项流程与字段保存核对通过**，刷新后恢复目标和人工记录。详细操作、逐轮导出及下一次界面对齐项见[浏览器操作验收](../frontend-qa/浏览器操作验收.md)。保存的 Codex 报告适配单独记录；完整模型联调另存一轮执行日志。[C 前端交付验收](../frontend-qa/C前端交付验收.md)。

### 7. 真人评估与合稿安排

两位评审者的盲评图集、独立标注模板、共识表，P01 五秒识别页面与主持人判分卡，以及实际工具使用的计时和问卷均已备齐。识别页面的 **9 项流程逻辑检查全部通过**，检查涵盖曝光、遮罩、退出、切窗记录、重复编号和正式／演练分开导出。[真人执行清单](../human-study/00_执行清单.md)。

| 接续工作 | 材料与执行方式 | D 的汇总输出 |
| --- | --- | --- |
| 双人参考评审 | 两位实际评审者独立标注，再形成共识并保留分歧记录 | 参考问题集、发现对应、召回率与误报占比 |
| 真实参与者与工具体验 | 6–8 位符合条件的参与者完成 P01 识别；实际工具使用者填写计时与问卷 | 原话与判分、任务耗时、体验结果 |
| 小组信息与合稿 | 成员姓名学号、个人贡献、各自主责章节、实际对话与演示素材 | 统一版本、章节、术语和证据引用的总稿 |
| 完整模型联调 | 使用前端已有引擎模式贯通实际模型、人工反馈与导出 | 一轮完整请求、反馈及最终导出记录 |

本轮直接可交的报告、统计和执行入口见[D 交付进度](D-交付进度.md)。
''' + report[end:]
report = report.replace('本次新增模型调用为 0，累计视觉评审仍为 5 次。', '该次回放新增模型调用为 0，彼时累计视觉评审为 5 次。本轮扩展后的累计次数为 14 次。')
insert = report.index('\n## V. Vibe Coding')
report = report[:insert] + '''
### 6. 扩展批次与 C 交付版本

本轮 9 次新运行统一使用 `20261021-204528` 前缀，各自记录实际开始、结束及耗时。判定口径为 D v1.1，整理程序绑定 `fd36cef42a558104f060f198e74f7cc814fa41dc`。GitHub 后续的 C 提交为 `9780c03eb9efffb1e26f1acab58685d90a8df05f`，引擎与提示词保持同一文件哈希。

新运行累计评审时间 1808 秒，逐次独立记录；本地结构检查与整理用时另存。该累计值为各次耗时之和。[执行计划](../evidence/codex-expansion-20261021/执行计划.json) · [逐次结果与统计](../evidence/codex-expansion-20261021/本轮统计汇总.json) · [最新仓库核对](../evidence/codex-expansion-20261021/GitHub最新核对.json)。

C 原始提交材料随包保存在 `reference/c-delivery-9780c03/`，当前源码保存在 `reproduction/source-9780c03/`。D 的验收文档按“当前实现、实际检查、统稿引用”整理。C 初稿中的早期测试数字和本机路径按其历史轮次保留，统稿采用 64 项后端回归记录、9 项前端测试与本轮具体适配结果。
''' + report[insert:]
report = report.replace('本轮形成了三项工作方法：', '本轮又将 v1.1 扩展到全部 10 张开发图与 P01，逐项核对作者候选，完成 C 前端离线测试及模拟操作验收，并把真人参考评审、识别实验和工具体验整理为可直接执行的材料。\n\n本轮形成了三项工作方法：')
report = report.replace('后续沿用相同归档方式扩展样本、汇总专家标注与用户实验，由 D 负责数据汇总和统稿。', '接续沿用相同归档方式汇总两位评审者标注与真实参与者记录，由 D 负责效果计算和统稿。')
report = report.replace('- 最新的[S07', '- 本轮新增[开发测试总览](D-本轮开发测试总览.md)、[作者候选对照](../evidence/codex-expansion-20261021/作者候选开发对照.md)、[C 前端验收](../frontend-qa/C前端交付验收.md)和[真人执行材料](../human-study/00_执行清单.md)。\n- 已发布的[S07', 1)
report = report.replace('本次更新的[D 验证证据](D-验证证据.json)汇总前期程序测试、Codex 同图三轮评审及 v1.1 两张合成图评测，并记录原文件哈希。', '更新后的[D 验证证据](D-验证证据.json)汇总累计 14 次视觉评审、10 张开发图结果、P01 目标建议及各类程序检查，原始证据按版本归档。')
write(OUT / 'docs/D-阶段性报告.md', report)

progress = '''# D 交付进度与接续安排

更新：2026 年 10 月 21 日。D 当前已完成测试结果、开发样本评审、问题对照、C 交付验收与本地报告整理，可以直接进入真人记录回收和合稿。

| 已完成内容 | 结果 | 入口 |
| --- | --- | --- |
| 五项程序修复 | 前期四项修复及 S07 去重修复，最新已发布回归为 64/64 | [修复记录](2026-10-21-S07去重修复.md) |
| 同图重复评审 | 原口径三轮；24 条判据有 22 条三轮一致，4 项目标有 3 项一致 | [三轮对照](D-Codex三轮一致性对照.md) |
| v1.1 全样本评审 | 10 张合成图共 24 项发现，P01 另有 2 项目标建议；累计 14 次视觉评审 | [本轮总览](D-本轮开发测试总览.md) |
| 新批次结果检查 | 9 次新运行，167/167 项结构检查通过，原始输出与哈希保留 | [统计汇总](../evidence/codex-expansion-20261021/本轮统计汇总.json) |
| 作者候选对照 | 25 条：22 完整、1 范围收敛、1 部分对应、1 判定不同；另发现 1 项 | [逐项对照](../evidence/codex-expansion-20261021/作者候选开发对照.md) |
| C 前端交付验收 | 9/9 前端测试、8/8 S07 适配检查、11/11 模拟操作与字段保存核对；四轮导出已留存 | [前端验收](../frontend-qa/C前端交付验收.md) · [浏览器记录](../frontend-qa/浏览器操作验收.md) |
| 真人实验准备 | 双人盲评、共识表、P01 五秒识别及工具体验材料，工具逻辑 9/9 通过 | [执行清单](../human-study/00_执行清单.md) |
| 报告与统稿材料 | D 正文已更新，C 前端及三份说明原稿已收录 | [D 阶段性报告](D-阶段性报告.md) |

## 接下来要收回的三组材料

1. **两位评审者的记录。** 分别发送 `human-study/blind-review/`，回收两份独立标注与相关经验说明，再按具体问题形成共识。D 依此计算正式召回率、误报占比及证据质量。
2. **6–8 人实验与工具使用记录。** 按主持人执行卡完成 P01 五秒识别并导出真实答案；实际工具使用者完成四个人工介入节点，留下计时与体验评分。
3. **成员信息与合稿材料。** 各成员填姓名学号、实际贡献，提供主责章节、关键对话与演示素材。C 的课程报告初稿已有 III.2、IV.2、IV.3 正文，按本轮版本与测试结果对齐后纳入总稿。

完整模型联调单独安排一轮：现有前端已提供引擎入口，沿“上传—实际模型评审—人工审核—反馈重评—导出”保存完整日志。当前已有 Codex 视觉评审、保存结果适配和模拟界面操作证据，可先用于 D 本轮报告。

## 现在怎样开始

先使用[真人执行清单](../human-study/00_执行清单.md)分发材料。盲评图集只含截图、上下文与判据；主持人候选和 Codex 结果保留在 D 的证据目录。识别实验先做设备演练，再收正式记录。参与者完成后把原始导出交回 D，按编号匹配和汇总。

本轮新增内容保存在本地，之前 GitHub 提交按原历史保留。最新仓库版本为 `9780c03`；视觉结果整理代码为 `fd36cef`。详细文件与统计见[D 验证证据](D-验证证据.json)。
'''
write(OUT / 'docs/D-交付进度.md', progress)

# 阅读入口标明当前进度，原始冻结口径和执行输入仍在 evidence 中保留。
index_path = OUT / 'docs/D-Codex证据索引.md'
index_text = index_path.read_text(encoding='utf-8')
index_text = index_text.replace('归档日期：2026-10-21。累计完成 5 次 Codex 视觉评审；',
    '历史归档日期：2026-10-21。本页以下 E 编号为前次发布的 5 次 Codex 视觉评审及修复证据；')
index_text = index_text.replace('\n\n历史归档日期',
    '\n\n本轮累计完成 **14 次视觉评审**。新增的 9 次运行、10 张开发图汇总、P01 目标建议、C 验收与真人执行材料见[本轮总览](D-本轮开发测试总览.md)和[交付进度](D-交付进度.md)。\n\n历史归档日期', 1)
write(index_path, index_text)
materials_path = OUT / 'docs/D-现有材料与下一轮测试.md'
materials_text = materials_path.read_text(encoding='utf-8')
materials_text = materials_text.replace('现有材料可以直接支持后续开发测试。',
    '本轮已按下述顺序完成全部 10 张合成图和 P01 评审；本页保留材料来源与执行规划，实际结果见[本轮总览](D-本轮开发测试总览.md)。')
materials_text = materials_text.replace('S03、S07 的 v1.1 独立评审与后续 S07 去重修复现已完成，见[S03 与 S07 汇总](D-S03与S07评审汇总.md)。上表保留材料盘点时的执行顺序。',
    'S03、S07 的 v1.1 独立评审、S07 去重修复、其余 8 张开发图与 P01 新口径评审现已完成。上表保留材料盘点时的执行顺序；最新结果见[开发测试总览](D-本轮开发测试总览.md)。')
write(materials_path, materials_text)

# 新增历史阅读副本修正链接；历史 JSON 保留原路径语义。
for name in ['D-阶段性报告.md', 'D-交付进度.md', 'README.md']:
    old_parent = BASE if name == 'README.md' else BASE / 'docs'
    target = history / name
    text = target.read_text(encoding='utf-8')
    def remap_history_link(match):
        original = match.group(1).strip('<>')
        if original.startswith(('https:', 'http:', '#', 'mailto:')):
            return match.group(0)
        path, marker, fragment = original.partition('#')
        source_target = (old_parent / path).resolve()
        try:
            package_target = OUT / source_target.relative_to(BASE.resolve())
        except ValueError:
            return match.group(0)
        if not package_target.exists():
            return match.group(0)
        relative = os.path.relpath(package_target, target.parent).replace('\\', '/')
        return '](' + relative + (marker + fragment if marker else '') + ')'
    text = re.sub(r'\]\(([^)]+)\)', remap_history_link, text)
    text = '> 前次发布内容的阅读副本，正文保留当时统计；本地链接按本包位置调整。最新结果见[当前报告](../../D-阶段性报告.md)。\n\n' + text
    write(target, text)
write(history / '路径说明.md', '本目录保留前次发布报告及统计。Markdown 阅读副本已调整到本包路径；历史 JSON 的相对路径仍以包根的 docs/ 为原基准，原始执行记录中的绝对路径保留当时环境。最新统计见[当前验证证据](../../D-验证证据.json)。\n')

# 真人执行清单同步当前 C 已交付的事实。
human_checklist = (OUT / 'human-study/00_执行清单.md').read_text(encoding='utf-8')
human_checklist = human_checklist.replace('拿到可运行界面后，按', 'C 的可运行界面已经交付。按')
human_checklist += '\nD 已完成的 C 界面模拟操作记录见[浏览器操作验收](../frontend-qa/浏览器操作验收.md)，离线验证见[前端验收](../frontend-qa/C前端交付验收.md)。真实工具使用者按同一任务另行填写计时与问卷。\n'
write(OUT / 'human-study/00_执行清单.md', human_checklist)

evidence = read_json(BASE / 'docs/D-验证证据.json')
evidence['schema'] = 'D 本地累计验证证据 v2'
evidence['source_baseline'] = ENGINE_HEAD
evidence['latest_repository_head'] = C_HEAD
evidence['publication'] = '本轮本地保存；既有 GitHub 发布记录按历史版本保留'
evidence['index'] = 'D-本轮开发测试总览.md'
evidence['previous_summary'] = evidence.pop('summary')
evidence['summary'] = summary
evidence['previous_evidence_index'] = 'history/s07-published-20261021/D-验证证据.json'
evidence['current_evidence_index'] = '../evidence/codex-expansion-20261021/本轮统计汇总.json'
evidence['original_path_mapping'] = '../evidence/codex-expansion-20261021/原路径与包内路径映射.json'
evidence['historical_file_manifest_semantics'] = 'files 为既有发布包证据文件的原清单；当前包新增文件另见本轮归档清单。'
evidence['new_evidence_files'] = []
for folder in [NEW, OUT / 'human-study', OUT / 'frontend-qa', OUT / 'reference/c-delivery-9780c03', current_source]:
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            evidence['new_evidence_files'].append({'package_path': path.relative_to(OUT).as_posix(), 'sha256': sha(path)})
write_json(OUT / 'docs/D-验证证据.json', evidence)

write(OUT / 'README.md', '''# D 本地交付包

2026 年 10 月 21 日。本轮已完成 10 张开发图评审、P01 新口径评审、作者候选对照和 C 交付验收，并备齐真人执行材料。

1. [读 D 阶段性报告](docs/D-阶段性报告.md)：正文、结果与证据入口。
2. [看当前交付进度](docs/D-交付进度.md)：已经完成的内容与接下来回收的三组材料。
3. [开始真人执行](human-study/00_执行清单.md)：双人盲评、6–8 人五秒识别、工具计时与问卷。

[本轮开发测试总览](docs/D-本轮开发测试总览.md) · [C 浏览器操作记录](frontend-qa/浏览器操作验收.md) · [完整验证证据](docs/D-验证证据.json)。

## 文件结构

- `docs/`：最新 D 正文、进度和既有专题报告。
- `evidence/`：原始评审、计时、检查日志；本轮在 `codex-expansion-20261021/`。
- `frontend-qa/`：C 离线测试、S07 结果适配和模拟浏览器操作证据。
- `human-study/`：给评审者和参与者使用的执行材料。
- `reference/c-delivery-9780c03/`：C 本次提交原文。
- `reproduction/source-9780c03/`：最新引擎及前端源码快照；`expansion-scripts/` 保存本轮整理脚本。

累计 14 次 Codex 视觉评审，10 张开发图共 24 项发现，P01 单独保存 2 项目标建议。原口径三轮、v1.1 单次评审、程序回归和真人研究分别留档。文件可在本地打开；原始 JSON 的旧工作区路径通过[路径映射](evidence/codex-expansion-20261021/原路径与包内路径映射.json)定位到包内文件。

本轮新增内容保存在本地。前次 GitHub 发布材料保存在历史目录，源代码及原始数据按版本保留。
''')
write_json(OUT / 'publication-manifest.json', {
    'date': '2026-10-21', 'scope': '本地交付，不代表本轮已发布 GitHub',
    'source_commits': summary['source_commits'], 'summary': summary,
    'previous_published_manifest': 'docs/history/s07-published-20261021/publication-manifest.json',
    'current_evidence': 'docs/D-验证证据.json',
    'final_manifest_note': '浏览器验收证据同步后，由最终打包步骤重新计算全包文件清单与 SHA-256。',
})

# 对本轮实际使用的全部原始 JSON 指针做可移植解析。
pointer_checks = []
def walk(value):
    if isinstance(value, dict):
        for item in value.values(): walk(item)
    elif isinstance(value, list):
        for item in value: walk(item)
    elif isinstance(value, str) and value.startswith('outputs/') and '#/' in value:
        old_path, pointer = value.split('#', 1)
        new_path = mapped_path(old_path)
        node = read_json(OUT / new_path)
        for piece in pointer.lstrip('/').split('/'):
            piece = piece.replace('~1', '/').replace('~0', '~')
            node = node[int(piece)] if isinstance(node, list) else node[piece]
        pointer_checks.append(value)
walk(comparison)
portable_links = re.findall(r'\]\(<?([^)>]+)>?\)', comparison_md)
for target in portable_links:
    if not target.startswith(('http:', 'https:', '#')):
        assert (NEW / target.split('#')[0]).exists(), target
write_json(NEW / '便携对应关系校验.json', {
    'source_files': len(path_index), 'source_hashes_match': True,
    'json_pointer_occurrences': len(pointer_checks), 'all_pointers_resolve': True,
    'comparison_links': len(portable_links), 'all_comparison_links_resolve': True,
    'checks': {'new_structure': '167/167', 'synthetic_findings': 24,
               'synthetic_rule_instances': 240, 'cumulative_visual_reviews': 14,
               'p01_unique_goal_suggestions': 2},
})
print(json.dumps({'package': str(OUT), 'new_summary': summary['new_reviews'],
                  'synthetic_summary': summary['synthetic_cases'],
                  'pointer_count': len(pointer_checks), 'source_hash_count': len(path_index)}, ensure_ascii=False))
