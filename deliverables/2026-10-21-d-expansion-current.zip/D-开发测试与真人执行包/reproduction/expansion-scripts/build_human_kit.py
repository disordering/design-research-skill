"""生成可直接交接的独立评审与真人短时识别材料，保留空白研究记录。"""
from pathlib import Path
import hashlib
import html
import json
import shutil

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/"outputs/d_expansion_20261021/human-study"
BLIND=OUT/"blind-review"
STUDY=OUT/"recognition"
for folder in [BLIND/"images",STUDY/"assets"]:
    folder.mkdir(parents=True,exist_ok=True)

def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

catalog=json.loads((ROOT/"outputs/d_protocol_20261021/下一轮样本清单.json").read_text(encoding="utf-8"))
criteria=json.loads(Path(catalog["criteria_path"]).read_text(encoding="utf-8"))
shutil.copyfile(catalog["criteria_path"],BLIND/"criteria.json")
protocol=(ROOT/"outputs/d_protocol_20261021/D-测试判定说明.md").read_text(encoding="utf-8")
# 独立评审材料仅保留判定规则，排除既有模型结果及其一致率。
protocol="# 独立评审执行口径 D v1.1\n\n以下为冻结口径的第 2—5 节；完整 24 条规则见 criteria.json。\n\n"+protocol[protocol.index("## 2. R05"):]
(BLIND/"D-v1.1判定口径.md").write_text(protocol,encoding="utf-8")
cards=[]
for sample in catalog["records"]:
    sid=sample["id"]
    shutil.copyfile(sample["screenshot"],BLIND/f"images/{sid}.png")
    facts=sample["known_context"]
    facts=facts if isinstance(facts,list) else [facts["design_goal"]]
    extra=""
    if sid=="P01":
        shutil.copyfile(sample["prototype"],BLIND/"images/P01-prototype.png")
        extra='<details><summary>查看原型</summary><img src="images/P01-prototype.png" alt="P01 原型"></details>'
    cards.append(f'<section id="{sid}"><h2>{sid} · {html.escape(sample["title"])}</h2><p><b>目标用户：</b>{html.escape(sample["target_user"])}</p><p><b>任务：</b>{html.escape(sample["task"])}</p><ul>'+''.join('<li>'+html.escape(x)+'</li>' for x in facts)+f'</ul><a href="images/{sid}.png" target="_blank"><img src="images/{sid}.png" alt="{sid} 界面"></a>{extra}</section>')
style='body{max-width:1120px;margin:40px auto;padding:0 24px;font:17px/1.75 system-ui;color:#17233c;background:#f4f6fa}section{background:white;padding:28px;margin:28px 0;border:1px solid #dde3ed;border-radius:16px}img{width:100%;height:auto}nav{position:sticky;top:0;background:#17233c;padding:14px;border-radius:10px}nav a{color:white;margin:0 12px}h1{font-size:32px}a{color:#2454bb}'
(BLIND/"gallery.html").write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>D 独立评审材料</title><style>'+style+'</style><h1>界面评审 · 独立记录</h1><p>依次查看截图、任务与已知上下文，按 24 条规则独立记录判断。点击图片可查看原尺寸。填写后保存原稿，再进入共识讨论。</p><p><a href="criteria.json">完整判据</a> · <a href="D-v1.1判定口径.md">v1.1 判定口径</a> · <a href="独立标注模板.txt">记录模板</a></p><nav>'+''.join(f'<a href="#{s["id"]}">{s["id"]}</a>' for s in catalog["records"] )+'</nav>'+''.join(cards)+'</html>',encoding="utf-8")
annotation='''D 独立评审记录 · v1.1

评审者代号：
相关设计评审经验：
是否参与样本或判据设计：
日期与起止时间：

请独立查看 gallery.html、criteria.json 与 D-v1.1判定口径.md。
对 S01—S10 逐条检查 R01—R24；P01 另检查四项设计目标。
每张图保留24条状态记录。存在问题时，按具体位置、表现和修改动作记录修改项；同一判据可关联多个独立问题。

【逐条判断：按需复制】
样本编号：
判据编号：
状态：候选问题 / 未见问题 / 需补充信息 / 本页不适用
截图中的位置与可见证据：
任务及上下文依据：
判定理由：
关联修改项编号（存在候选问题时填写）：

【具体修改：按需复制】
修改项编号：
样本编号：
关联判据或目标：
位置或元素：
具体表现：
任务影响与严重度（高/中/低/未知）：
修改建议：

【完成记录】
已完成样本：
需要补充的具体材料：

文件以“评审者代号_独立标注_日期.txt”保存。提交独立记录后再对照讨论，共识记录另存。
'''
(BLIND/"独立标注模板.txt").write_text(annotation,encoding="utf-8")
save(BLIND/"共识参考_空白.json",{"protocol_version":"D v1.1","reviewers":[],"independent_files":[],"records":[],"record_fields":["reference_id","sample_id","rule_ids","location","phenomenon","evidence","decision","severity","reviewer_1_annotation_id","reviewer_2_annotation_id","resolution_reason","finalized_by","finalized_at"]})
p01=next(x for x in catalog["records"] if x["id"]=="P01")
shutil.copyfile(p01["screenshot"],STUDY/"assets/P01.png")
image_sha=hashlib.sha256((STUDY/"assets/P01.png").read_bytes()).hexdigest()
plan={"study_id":"D-P01-5s-v1","version":"1.0","image":"assets/P01.png","image_sha256":image_sha,"population":"此前未看过本项目界面的中轻度手游玩家","planned_participants":"6–8人","planned_exposure_ms":5000,"design":"单版本首次观看；每位参与者一次正式曝光","primary_question":"页面主要能做什么","questions":["你刚看到的页面主要能做什么？","如果要开始主要操作，你会找哪个位置？","你记得哪个按钮或入口的文字？"],"timing_basis":"performance.now 与 requestAnimationFrame 记录浏览器显示至遮罩的间隔","exclusions":"设备演练、主动退出、切换标签页/窗口、曝光中改变尺寸，均单列；空白回答记缺失；不得重复曝光后当作首次观看","records":[]}
save(STUDY/"执行方案.json",plan)
save(STUDY/"主持人判分表.json",{"study_id":plan["study_id"],"primary_measure":"Q1 正确人数 / Q1 有效回答人数，人数及缺失单列","scoring":[{"question":"Q1","correct":"试用/体验角色，或查看角色后开始试用","accept":["角色试用","试玩这个角色","体验角色能力"],"not_enough":["游戏页面","看人物","领礼包"]},{"question":"Q2","correct":"右下角或右下方"},{"question":"Q3","correct":"开始试用；表达一致的开始试玩或试用按钮可接受"}],"allowed_labels":["正确","错误","缺失","中止","设备异常"],"scored_records":[],"record_fields":["session_id","participant_id","question_id","original_answer","label","scorer","reason"]})
(STUDY/"主持人执行卡.md").write_text('''# P01 五秒识别 · 主持人执行卡

目标：记录首次观看者能否识别“角色试用”任务、主操作位置和入口文字。计划邀请 6–8 位此前未看过本项目界面的中轻度手游玩家。

1. 先用“设备演练”检查浏览器。正式测试统一使用同一设备、浏览器尺寸和缩放，记录设备信息。
2. 打开 `index.html`，选择“正式参与者”，使用匿名编号 U01、U02……；记录玩家背景与是否看过本图。
3. 告知参与自愿、可随时退出、记录用于课程研究。参与者勾选后开始。不要提前透露问题答案或展示评审报告。
4. 图片显示 5 秒后自动遮罩；参与者按首次印象回答三题。主持人不追加提示、不重复曝光。
5. 保存记录；退出、窗口切换、尺寸变化等事件也会记录。每人结束后导出正式记录 JSON。
6. 所有人完成后，使用 `主持人判分表.json` 判分，保留原话。分题列出正确、错误、缺失、中止和设备异常；有效回答为正确与错误之和。每个百分比同时写分子、分母。

本任务的计时是浏览器显示间隔。参与者识别结果、工具使用耗时和问卷分别汇总。若变更图片、题目或曝光时长，另建方案版本。

页面可离线运行。记录保存在当前浏览器和导出的 JSON 中；研究记录以导出文件归档。设备演练与正式记录分开导出。
''',encoding="utf-8")
(OUT/"工具体验与界面验收.txt").write_text('''D 工具操作验收与体验记录

开始前填写：界面链接/启动方式、前端版本、后端版本、操作者代号、样本、任务、开始时间。
统一任务：上传指定截图，确认任务目标，检查问题及证据，选择一项确认、一项驳回，调整一项严重度，触发复审并保存导出。
若样本没有对应操作对象，记录“不适用”并说明，不凑造发现。

逐个检查并记录操作前、操作后、复审后、导出文件中的实际值：
1. 目标修改是否进入后续评审请求和结果。
2. 确认/驳回是否在复审和导出中保留。
3. 严重度修改是否更新统计与导出。
4. 复审是否生成新运行记录、关联修改并更新结果。

计时从收到任务和材料到核查并保存导出，包含等待、重试与修订。记录结束时间、耗时、完成/中止和原因。
若比较纯人工与工具辅助：用难度相当但不同内容的任务，提前固定 AB/BA 顺序；分开保存两种条件原始记录。

实际使用工具后回答（1=完全不同意，5=完全同意，也可写不适用）：
能理解系统给出的意见：
能根据意见找到截图证据：
能完成修订并确认保存：
最困难的一步（原话）：
建议（原话）：

每位操作者单独保存文件。玩家五秒识别与工具使用体验分开记录。
''',encoding="utf-8")
(OUT/"00_执行清单.md").write_text('''# D 真人材料执行清单

## 两位独立评审者

将 `blind-review` 整个目录分别交给两位评审者。请对方先填相关经验，再查看 `gallery.html`、完整判据和 v1.1 口径，独立填写记录模板。两份独立记录完成后，按具体位置、表现和修改动作讨论分歧，填入共识参考；保留原稿。

该目录含 10 张合成开发图和 1 个项目案例。正式参考集由实际评审者选择并冻结样本范围，在共识表中记录来源及对应版本。

## 6–8 位参与者

使用 `recognition/index.html` 和主持人执行卡，开展 P01 五秒识别。页面负责曝光、遮罩、原话记录和 JSON 导出；主持人按固定判分表处理回答。

## 工具使用者与 C 的操作界面

拿到可运行界面后，按 `工具体验与界面验收.txt` 检查四个人工干预节点，再记录实际工具使用耗时和三项体验评分。

## 给 D 汇总的文件

- 两份独立标注原稿、评审者经验说明及共识参考。
- 6–8 位参与者的正式 JSON 导出和主持人判分记录。
- 操作界面版本、四节点操作前后与导出证据、工具计时和问卷。
- 各成员姓名学号、主责章节、实际对话和提示词、演示录屏。

文件准备完成后即可按编号汇总。此包的研究数据表保持空白，设备演练单独归档。
''',encoding="utf-8")
print(OUT)
