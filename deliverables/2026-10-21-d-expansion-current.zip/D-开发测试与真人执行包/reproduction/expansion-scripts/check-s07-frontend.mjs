import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {adaptReport} from './latest-source/design-research-skill-main/frontend/dist/engine-adapter.js';

// 直接适配已归档的 Codex 结果，检查交付字段；全程不发网络请求。
const source=new URL('../../outputs/d_s07_fix_20261021/replay-after/S07/report.json',import.meta.url);
const bytes=await readFile(source);
const raw=JSON.parse(bytes.toString('utf8'));
const adapted=adaptReport(raw,{image:'S07-本地已归档截图',context:raw.context});
const r17=adapted.issues.filter(i=>i.rule_ids.includes('R17'));
const checks=[
 ['5 项具体问题完整保留',()=>assert.equal(adapted.issues.length,5)],
 ['两处 R17 问题分别保留',()=>assert.equal(r17.length,2)],
 ['两处 R17 保留独立 ID',()=>assert.equal(new Set(r17.map(i=>i.id)).size,2)],
 ['两处 R17 保留不同证据坐标',()=>assert.notDeepEqual(r17[0].position,r17[1].position)],
 ['所有证据坐标与原始报告一致',()=>adapted.issues.forEach((i,n)=>assert.deepEqual(i.position,raw.findings[n].evidence))],
 ['24 条判据检查完整保留',()=>assert.equal(adapted.ruleResults.length,24)],
 ['全部新问题进入待人工审核状态',()=>assert.ok(adapted.issues.every(i=>i.reviewStatus==='pending'))],
 ['原始模型来源完整保留',()=>assert.deepEqual(adapted.rawReport.model,raw.model)]
];
const result={
 source_report:'outputs/d_s07_fix_20261021/replay-after/S07/report.json',
 source_sha256:createHash('sha256').update(bytes).digest('hex'),
 execution:'直接调用前端 adaptReport；离线适配已保存结果',
 model_calls:0,network_requests:0,
 findings:adapted.issues.length,rule_results:adapted.ruleResults.length,
 mode:adapted.mode,model:adapted.rawReport.model,
 r17:r17.map(i=>({id:i.id,title:i.title,rule_ids:i.rule_ids,evidence:i.position})),
 checks:checks.map(([name,run])=>{run();return {name,passed:true};})
};
result.passed=result.checks.filter(c=>c.passed).length;
result.total=result.checks.length;
await writeFile(new URL('../../outputs/d_expansion_20261021/frontend-qa/S07前端适配核对.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
