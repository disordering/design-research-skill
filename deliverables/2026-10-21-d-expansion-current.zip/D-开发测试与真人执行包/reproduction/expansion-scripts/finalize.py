"""校验新视觉评审并调用已发布引擎整理结果，保存逐项检查。"""
from datetime import datetime
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/d_expansion_20261021"
SOURCE = ROOT / "outputs/d_s07_publish_20261021/downloaded_repository/design-research-skill-main"
sys.path.insert(0, str(SOURCE))
from engine.contracts import EvidenceAnchor, RawAuditResult, ReviewReport, ReviewContext, ModelInfo
from engine.criteria import CriteriaLibrary
from engine.imaging import prepare_image
from engine.service import ReviewEngine, _build_summary, _image_info, _finding_key

def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

class NoModelCall:
    async def complete(self, *args, **kwargs):
        raise RuntimeError("整理步骤只读取本轮已保存的视觉评审结果。")

def raw_ref(value, raw):
    match = re.fullmatch(r"raw\.findings\[(\d+)\]", value)
    assert match, value
    i = int(match.group(1))
    assert 0 <= i < len(raw.findings), value
    return i

def finalize(item):
    run = Path(item["path"])
    manifest = read(run / "run-manifest.json")
    if manifest["status"] == "completed":
        return read(run / "验证结果.json")
    needed = ["raw-audit.json", "protocol-trace.json", "review-timing.json"] + (["goal-review.json"] if item["sample_id"] == "P01" else [])
    if not all((run / n).exists() for n in needed):
        return {"sample_id":item["sample_id"], "status":"waiting"}
    started = time.perf_counter()
    raw_hashes = {n:sha(run / n) for n in needed}
    checks = {}
    def check(label, condition):
        checks[label] = bool(condition)
        assert condition, label
    check("冻结输入哈希一致", all(sha(run / n) == h for n,h in manifest["input_files"].items()))
    raw = RawAuditResult.model_validate(read(run / "raw-audit.json"))
    check("原始输出通过项目契约", raw.screen_analysis is not None)
    library = CriteriaLibrary.load(run / "criteria.json")
    statuses = {r.rule_id:r for r in raw.rule_statuses}
    check("24条判据完整唯一且有理由", len(raw.rule_statuses) == len(statuses) == 24 and set(statuses) == set(library.rule_ids) and all(r.reason.strip() for r in raw.rule_statuses))
    check("原始候选判据与问题对应", {r.rule_id for r in raw.rule_statuses if r.decision.value == "candidate_issue"} == {rid for f in raw.findings for rid in f.rule_ids})
    trace = read(run / "protocol-trace.json")
    common = {"id", "protocol_version", "evidence_source", "visible_evidence", "known_context", "missing_evidence", "decision", "reason", "finding_id"}
    check("R05及R18记录字段完整", trace["protocol_version"] == "D v1.1" and trace["sample_id"] == item["sample_id"] and len(trace["rules"]) == 2 and {r["id"] for r in trace["rules"]} == {"R05","R18"} and all(common <= r.keys() for r in trace["rules"]))
    by_id = {r["id"]:r for r in trace["rules"]}
    term_fields = {"term", "location", "target_user", "expertise_evidence", "term_meaning_source", "familiarity", "familiarity_evidence", "primary_task", "task_source", "required_for_task", "necessity_evidence", "visible_explanation"}
    check("R05术语及任务必要性字段完整", isinstance(by_id["R05"]["terms"], list) and all(term_fields <= t.keys() and t["familiarity"] in {"熟悉","不熟悉","未知"} and t["required_for_task"] in {"必需","非必需","未知"} for t in by_id["R05"]["terms"]))
    check("R18交互与分组证据字段完整", {"items","interaction_evidence","group_relation","relation_source","group_cues","mixing_evidence"} <= by_id["R18"].keys() and all({"name","interaction_role"} <= x.keys() for x in by_id["R18"]["items"]))
    trace_ok = True
    for r in trace["rules"]:
        trace_ok &= r["decision"] == statuses[r["id"]].decision.value and r["protocol_version"] == "D v1.1" and bool(r["reason"] and r["evidence_source"])
        trace_ok &= r["id"] in raw.findings[raw_ref(r["finding_id"], raw)].rule_ids if r["decision"] == "candidate_issue" else r["finding_id"] == ""
    check("详细判定与原始状态及引用一致", trace_ok)
    refs = []
    for s in trace["suggestions"]:
        assert {"finding_id","location","phenomenon","evidence","related_ids","suggestion"} <= s.keys()
        i = raw_ref(s["finding_id"], raw)
        assert set(s["related_ids"]) == set(raw.findings[i].rule_ids)
        refs.append(i)
    check("建议与原始问题逐项对应", sorted(refs) == list(range(len(raw.findings))))
    check("设计目标范围与输入一致", trace["goal_scope"]["status"] == ("provided" if item["sample_id"] == "P01" else "not_provided"))
    timing = read(run / "review-timing.json")
    start, end = (datetime.fromisoformat(timing[k]) for k in ["started_at","ended_at"])
    elapsed = (end-start).total_seconds()
    check("实际起止时间与耗时一致", start.tzinfo and end.tzinfo and elapsed > 0 and abs(elapsed-timing["elapsed_seconds"]) < 1 and timing["timezone"] == "Asia/Taipei")
    engine = ReviewEngine(library, NoModelCall(), provider="codex-session", model_name="Codex 会话", is_stub=False)
    findings,rules,warnings = engine._normalize(raw)
    check("已发布引擎整理无警告", not warnings)
    check("整理后全部判据状态保持", {r.rule_id:r.decision for r in rules} == {r.rule_id:r.decision for r in raw.rule_statuses})
    check("每个具体问题及证据保留", all(any(_finding_key(f) == _finding_key(g) and set(f.rule_ids) <= set(g.rule_ids) for g in findings) for f in raw.findings))
    summary = _build_summary(rules,findings)
    check("判据与问题分别计数正确", summary.candidate_issues == sum(r.decision.value == "candidate_issue" for r in rules) and sum([summary.critical_count,summary.high_count,summary.medium_count,summary.low_count]) == len(findings) and sum([summary.candidate_issues,summary.no_visible_issue,summary.insufficient_evidence,summary.not_applicable]) == 24)
    goals = None
    if item["sample_id"] == "P01":
        goals = read(run / "goal-review.json")
        goalmap = {g["id"]:g for g in goals["goals"]}
        allowed = {"met","observed_violation","insufficient_evidence"}
        check("四项目标完整且状态合法", len(goals["goals"]) == len(goalmap) == 4 and set(goalmap) == {"G01","G02","G03","G04"} and all(g["decision"] in allowed and g["observation"] for g in goals["goals"]))
        for g in goals["goals"]:
            EvidenceAnchor.model_validate(g["evidence"])
        check("目标证据坐标合法", True)
        sub = {g["id"]:g for g in goalmap["G02"]["subcriteria"]}
        extras = {"G02.1":{"focal_elements","competing_elements","hierarchy_evidence"}, "G02.2":{"key_information","readable_text","readability_evidence","viewing_basis"}, "G02.3":{"regions","spacing_evidence","density_evidence"}}
        check("G02三个子项及专项证据完整", len(goalmap["G02"]["subcriteria"]) == 3 and set(sub) == set(extras) and all(common <= g.keys() and extras[k] <= g.keys() and g["decision"] in allowed for k,g in sub.items()))
        decisions = [g["decision"] for g in sub.values()]
        overall = "observed_violation" if "observed_violation" in decisions else "insufficient_evidence" if "insufficient_evidence" in decisions else "met"
        check("G02按三个子项正确汇总", goalmap["G02"]["overall_decision"] == goalmap["G02"]["decision"] == overall)
        mods = {m["finding_id"]:m for m in goals["modification_suggestions"]}
        check("目标建议编号唯一且引用有效", len(mods) == len(goals["modification_suggestions"]) and all(set(g["related_finding_ids"]) <= set(mods) for g in goals["goals"]) and all({"finding_id","location","phenomenon","evidence","related_ids","suggestion"} <= m.keys() for m in mods.values()))
    prepared_image = prepare_image((run / "screenshot.png").read_bytes(),filename="screenshot.png")
    local_ms = max(1,round((time.perf_counter()-started)*1000))
    report = ReviewReport(review_id=run.name,status="completed",model=ModelInfo(provider="codex-session",model="Codex 会话",analysis_mode="single_pass",is_stub=False),context=ReviewContext.model_validate(read(run/"context.json")),image=_image_info(prepared_image),screen_analysis=raw.screen_analysis,criteria_version=library.version,criteria_source=library.source,summary=summary,findings=findings,rule_results=rules,warnings=warnings,timings_ms={"codex_session_review_wall":round(elapsed*1000),"local_contract_and_normalization":local_ms},diagnostics={"sample_id":item["sample_id"],"sample_source":manifest["sample_source"],"protocol_version":"D v1.1","source_commit":manifest["source_commit"],"context_mode":manifest["context_mode"],"execution":"本轮独立Codex视觉评审；已发布引擎本地整理", "service_sha256":sha(SOURCE/"engine/service.py"),"prompting_sha256":sha(SOURCE/"engine/prompting.py")},goal_checks=goals["goals"] if goals else [],artifacts={"screenshot":"screenshot.png","raw_audit":"raw-audit.json","protocol_trace":"protocol-trace.json","validation":"验证结果.json"})
    ReviewReport.model_validate(report.model_dump(mode="json"))
    check("最终报告通过项目契约",True)
    check("问题编号唯一且连续",[f.id for f in findings] == [f"F{i:03}" for i in range(1,len(findings)+1)])
    check("整理过程中原始输出未变",all(sha(run/n)==h for n,h in raw_hashes.items()))
    validation={"sample_id":item["sample_id"],"run_id":run.name,"status":"passed","checks":checks,"checks_passed":sum(checks.values()),"checks_total":len(checks),"findings":len(findings),"candidate_rules":summary.candidate_issues,"warnings":warnings,"review_seconds":elapsed,"local_ms":local_ms,"raw_sha256":raw_hashes,"source_commit":manifest["source_commit"]}
    save(run/"report.json",report.model_dump(mode="json"))
    save(run/"验证结果.json",validation)
    labels={"candidate_issue":"候选问题","no_visible_issue":"未见问题","insufficient_evidence":"需补充信息","not_applicable":"本页不适用","met":"达到目标","observed_violation":"需要调整"}
    sample=read(run/"sample-context.json")
    lines=[f"# {sample['id']} · {sample['title']}","",f"D v1.1；Codex 单次视觉评审；{sample['test_group']}。运行编号 `{run.name}`。","",f"检查 24 条判据，得到 {summary.candidate_issues} 条候选判据、{len(findings)} 个具体修改点。评审 {elapsed:g} 秒；程序整理 {local_ms} 毫秒。","",f"任务：{sample['task']}","",f"目标用户：{sample['target_user']}","","## 具体修改",""]
    for f in findings:
        lines += [f"### {f.id} · {f.title}","",f"判据：{'、'.join(f.rule_ids)}。","",f"- 原则：{f.principle}",f"- 检测：{f.detection}",f"- 描述：{f.description}",f"- 建议：{f.suggestion}",f"- 证据：{f.evidence.description}",""]
    if not findings:
        lines += ["本轮通用判据未形成具体修改项。逐条检查范围及依据见下表。",""]
    if goals:
        lines += ["## 设计目标", "", "| 目标 | 判断 | 依据 |", "| --- | --- | --- |"]
        lines += [f"| {g['id']} | {labels[g['decision']]} | {g['observation'].replace('|','／')} |" for g in goals["goals"]]
        lines += ["", "### G02 子项", "", "| 子项 | 判断 | 依据 |", "| --- | --- | --- |"]
        lines += [f"| {g['id']} | {labels[g['decision']]} | {g['reason'].replace('|','／')} |" for g in goals["goals"][1]["subcriteria"]]
        lines += ["", "### 按具体动作合并后的建议", ""]
        lines += [f"- **{m['finding_id']}（{'、'.join(m['related_ids'])}）：** {m['location']}；{m['suggestion']}" for m in goals["modification_suggestions"]]
    lines += ["", "## 24 条判据", "", "| 判据 | 判断 | 依据 |", "| --- | --- | --- |"]
    lines += [f"| {r.rule_id} {r.title} | {labels[r.decision.value]} | {r.reason.replace('|','／')} |" for r in rules]
    lines += ["",f"结构检查：{len(checks)}/{len(checks)} 通过。", "", "[截图](screenshot.png) · [原始输出](raw-audit.json) · [v1.1记录](protocol-trace.json) · [结构化报告](report.json) · [计时](review-timing.json) · [验证结果](验证结果.json)", ""]
    (run/"评审结果.md").write_text("\n".join(lines),encoding="utf-8")
    manifest.update({"status":"completed","completed_at":datetime.now().astimezone().isoformat(),"review_count":1,"timing":timing,"raw_output_sha256":raw_hashes,"report":"report.json","validation":"验证结果.json"})
    save(run/"run-manifest.json",manifest)
    save(run/"文件校验.json",{p.name:sha(p) for p in sorted(run.iterdir()) if p.is_file() and p.name != "文件校验.json"})
    return validation

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("sample",nargs="*")
    args=parser.parse_args()
    results=[]
    for item in read(OUT/"执行计划.json")["runs"]:
        if args.sample and item["sample_id"] not in args.sample:
            continue
        try:
            r=finalize(item)
        except Exception as exc:
            r={"sample_id":item["sample_id"],"status":"needs_review","error":str(exc),"error_type":type(exc).__name__}
        results.append(r)
    save(OUT/"批次校验状态.json",results)
    print(json.dumps(results,ensure_ascii=False,indent=2))
    sys.exit(1 if any(r["status"]=="needs_review" for r in results) else 0)
