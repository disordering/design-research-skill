"""核查阅读入口并输出独立发放包、全量证据包和校验清单。"""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BATCH = ROOT / 'outputs/d_expansion_20261021'
PACKAGE = BATCH / 'package'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

# 当前阅读副本与本轮工具说明的链接都应在移动目录后仍可使用。
md_files = [PACKAGE / 'README.md']
md_files += list((PACKAGE / 'docs').glob('*.md'))
for name in ['frontend-qa', 'human-study', 'evidence/codex-expansion-20261021']:
    md_files += [p for p in (PACKAGE / name).rglob('*.md') if not p.name.endswith('.original.md')]
checked = []
missing = []
for doc in md_files:
    content = doc.read_text(encoding='utf-8-sig')
    for target in re.findall(r'\]\(<?([^)>]+)>?\)', content):
        if target.startswith(('https:', 'http:', '#', 'mailto:', 'data:')):
            continue
        path = unquote(target.split('#')[0])
        if not path:
            continue
        resolved = (doc.parent / path).resolve()
        if not resolved.exists():
            missing.append({'file': str(doc.relative_to(PACKAGE)), 'target': target})
        checked.append({'file': str(doc.relative_to(PACKAGE)), 'target': target})
assert not missing, missing

# 固定原始视觉输出逐字节保留，避免归档过程改变研究记录。
originals = []
for run in sorted((BATCH / 'runs').iterdir()):
    for name in ['raw-audit.json', 'protocol-trace.json', 'review-timing.json', 'goal-review.json']:
        src = run / name
        if src.exists():
            dst = PACKAGE / 'evidence/codex-expansion-20261021/runs' / run.name / name
            assert sha(src) == sha(dst), dst
            originals.append({'path': dst.relative_to(PACKAGE).as_posix(), 'sha256': sha(dst)})
checks = json.loads((BATCH / '批次校验状态.json').read_text(encoding='utf-8'))
assert len(checks) == 9
assert sum(r['checks_passed'] for r in checks) == 167
assert sum(r['findings'] for r in checks) == 17
assert json.loads((PACKAGE / 'frontend-qa/浏览器操作验收.json').read_text(encoding='utf-8'))['通过'] == 11

# 共识表应保持待真实评审者填写的初始状态。
consensus = json.loads((PACKAGE / 'human-study/blind-review/共识参考_空白.json').read_text(encoding='utf-8'))
assert consensus['records'] == []

write_json(PACKAGE / '最终归档核查.json', {
    '当前阅读文件数': len(md_files), '本地链接核对数': len(checked),
    '无失效本地链接': True, '原始评审文件': originals,
    '原始评审字节保持': True, '9次新运行结构检查': '167/167',
    '模拟浏览器保存字段核对': '11/11', '真人共识记录数': 0,
    '最终报告审阅': '独立复核通过：统计范围、模拟流程、真人记录与当前C交付状态一致',
    '发布范围': '本地归档',
})

# 最后新增的归档脚本也收录，供以后按当前材料重新生成校验。
shutil.copy2(Path(__file__), PACKAGE / 'reproduction/expansion-scripts/finalize_package.py')

# 更新当前证据清单，保留既有已发布原清单。
evidence_path = PACKAGE / 'docs/D-验证证据.json'
evidence = json.loads(evidence_path.read_text(encoding='utf-8'))
new_files = []
for name in ['evidence/codex-expansion-20261021', 'human-study', 'frontend-qa', 'reference/c-delivery-9780c03', 'reproduction/source-9780c03']:
    for p in sorted((PACKAGE / name).rglob('*')):
        if p.is_file():
            new_files.append({'package_path': p.relative_to(PACKAGE).as_posix(), 'sha256': sha(p)})
evidence['new_evidence_files'] = new_files
evidence['final_archive_verification'] = '../最终归档核查.json'
write_json(evidence_path, evidence)

manifest_path = PACKAGE / '全包文件校验.json'
manifest = [{'path': p.relative_to(PACKAGE).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(PACKAGE.rglob('*')) if p.is_file() and p != manifest_path]
write_json(manifest_path, {'校验算法': 'SHA-256', '清单自身不计入': True, '文件数': len(manifest), 'files': manifest})

def zip_dir(source, archive, prefix):
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(source.rglob('*')):
            if p.is_file():
                z.write(p, f'{prefix}/{p.relative_to(source).as_posix()}')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        count = len(z.namelist())
    return {'文件名': archive.name, '文件数': count, '字节': archive.stat().st_size, 'sha256': sha(archive), 'ZIP完整性': '通过'}

archives = [
    zip_dir(PACKAGE / 'human-study/blind-review', BATCH / '两位评审者独立标注材料.zip', '独立评审材料'),
    zip_dir(PACKAGE / 'human-study/recognition', BATCH / 'P01五秒识别主持人材料.zip', '五秒识别主持人材料'),
    zip_dir(PACKAGE, BATCH / 'D-开发测试与真人执行包_20261021.zip', 'D-开发测试与真人执行包'),
]
write_json(BATCH / '交付文件校验.json', {'archives': archives, '当前本地链接': len(checked), '完整性': '全部通过'})
print(json.dumps({'archives': archives, 'local_links_checked': len(checked), 'raw_files_unchanged': len(originals)}, ensure_ascii=False))
