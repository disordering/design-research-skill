"""冻结下一批 Codex 视觉评审输入；与既有运行分别归档。"""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/d_expansion_20261021"
SOURCE = ROOT / "outputs/d_s07_publish_20261021/downloaded_repository/design-research-skill-main"
sys.path.insert(0, str(SOURCE))
from engine.contracts import RawAuditResult, ReviewContext

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

OUT.mkdir(parents=True, exist_ok=True)
if (OUT / "执行计划.json").exists():
    raise SystemExit("本批执行计划已存在，保留既有冻结输入。")
catalog = json.loads((ROOT / "outputs/d_protocol_20261021/下一轮样本清单.json").read_text(encoding="utf-8"))
by_id = {r["id"]: r for r in catalog["records"]}
base_prompt = (ROOT / "outputs/d_codex_pilot_v11_20261021/20261021-192850-s03/prompt.txt").read_text(encoding="utf-8")
base_prompt = base_prompt.replace("按同一现象合并，保留所有相关判据。", "按同一位置、同一具体表现和同一修改动作合并，保留所有相关判据。同一判据可以关联多个独立问题；不同位置或修改动作的问题分别保留。")
stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
runs = []
for sample_id in ["P01", "S01", "S02", "S04", "S05", "S06", "S08", "S09", "S10"]:
    sample = dict(by_id[sample_id])
    # 评审输入只包含任务事实，不提供重点规则、参考答案或预设问题数量。
    sample = {k:v for k,v in sample.items() if k not in {"focus_rules", "focus_goals", "human_reference_records"}}
    run = OUT / "runs" / f"{stamp}-{sample_id.lower()}"
    run.mkdir(parents=True)
    shutil.copyfile(sample["screenshot"], run / "screenshot.png")
    sample["screenshot"] = "screenshot.png"
    if sample_id == "P01":
        shutil.copyfile(sample["prototype"], run / "prototype.png")
        shutil.copyfile(sample["design_goal"], run / "design-goal.txt")
        sample["prototype"] = "prototype.png"
        sample["design_goal"] = "design-goal.txt"
        context = ReviewContext(design_goal=(run / "design-goal.txt").read_text(encoding="utf-8"), scenario=sample["title"] + "；任务：" + sample["task"], platform="game", target_user=sample["target_user"])
    else:
        context = ReviewContext(scenario=sample["title"] + "；任务：" + sample["task"] + "\n已知上下文：\n" + "\n".join(sample["known_context"]), platform="web", target_user=sample["target_user"])
    save(run / "context.json", context.model_dump(mode="json"))
    save(run / "sample-context.json", sample)
    shutil.copyfile(catalog["criteria_path"], run / "criteria.json")
    shutil.copyfile(ROOT / "outputs/d_protocol_20261021/D-测试判定说明.md", run / "D-测试判定说明.md")
    save(run / "raw-audit.schema.json", RawAuditResult.model_json_schema())
    prompt = base_prompt
    if sample_id == "P01":
        prompt = prompt.replace("本次材料没有另附原型和角色展示类设计目标，任务说明用于通用交互判据判断。不要套用角色试用页的 G01—G04。", "本次另附 prototype.png 原型和 design-goal.txt 的四项目标。实际查看两张图片，并另行对 G01—G04 做设计目标判断。通用判据与设计目标分别记录。")
        prompt = prompt.replace("只创建三个输出文件：", "创建四个输出文件：")
        prompt = prompt.replace('"goal_scope":{"status":"not_provided","reason":"说明本样本采用用户任务与通用判据"}', '"goal_scope":{"status":"provided","reason":"四项设计目标及原型已提供，结果见 goal-review.json"}')
        prompt += '''\n4. goal-review.json：包含 goals 数组（恰好 G01、G02、G03、G04 各一项）和 summary。每项目标包含 id、goal（目标原文）、decision（met/observed_violation/insufficient_evidence）、observation、suggestion、evidence（有 description、visible_text 和归一化 x/y/width/height）、related_finding_ids（引用下述修改建议编号，未见问题为空数组）。G02 额外包含 subcriteria 数组（恰好 G02.1/G02.2/G02.3）、overall_decision。各子项包含 D 说明中的共同证据字段以及其要求的专项证据字段。G02 decision 与 overall_decision 必须按子项汇总一致。\n同时在 goal-review.json 中添加 modification_suggestions 数组，按具体位置、表现、修改动作去重。每项含 finding_id（M01等）、location、phenomenon、evidence（具体可见依据）、related_ids（G01—G04、G02.1—G02.3 或 R01—R24）、suggestion。不同目标关联同一现象时共用一个 M 编号；同一规则下不同位置保留。通用 raw.findings 如果与目标建议指向同一具体修改，在该表里合并，写 raw_refs 关联 raw.findings[0] 等引用。不能以建议条数代替目标判断。目标原文中的操作反馈按静态截图实际可见范围记录。\n'''
    (run / "prompt.txt").write_text(prompt, encoding="utf-8")
    manifest = {"run_id":run.name, "sample_id":sample_id, "prepared_at":datetime.now().astimezone().isoformat(), "provider":"codex-session", "model_identification":"Codex 会话", "source_commit":"fd36cef42a558104f060f198e74f7cc814fa41dc", "protocol_version":"D v1.1", "sample_source":sample["source"], "context_mode":"新上下文单样本独立评审；输入不含主持人候选、重点规则及其他运行输出", "status":"prepared", "review_count":0, "input_files":{p.name:sha(p) for p in sorted(run.iterdir()) if p.is_file()}}
    save(run / "run-manifest.json", manifest)
    runs.append({"sample_id":sample_id, "run_id":run.name, "path":str(run)})
plan = {"created_at":datetime.now().astimezone().isoformat(), "protocol_version":"D v1.1", "source_commit":"fd36cef42a558104f060f198e74f7cc814fa41dc", "purpose":"补齐8张合成图与P01项目案例的单次Codex开发评审", "new_visual_reviews_planned":9, "existing_visual_reviews":5, "runs":runs, "comparison_policy":"评审原始输出冻结后再读取作者预设候选并逐条对照；作者候选与真人共识分别统计", "delivery":"本地报告、运行证据、评审者与实验执行材料"}
save(OUT / "执行计划.json", plan)
print(json.dumps(runs, ensure_ascii=False, indent=2))
