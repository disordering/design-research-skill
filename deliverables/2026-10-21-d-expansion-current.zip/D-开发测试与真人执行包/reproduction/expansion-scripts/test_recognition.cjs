// 在内存中的 DOM 与时钟环境检查实验记录流程；不创建真人研究记录。
const fs=require('fs'), path=require('path'), vm=require('vm'), assert=require('assert');
const root=path.resolve(__dirname,'../..');
const html=fs.readFileSync(path.join(root,'outputs/d_expansion_20261021/human-study/recognition/index.html'),'utf8');
const code=html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(code);
function setup(){
 const nodes=new Map(), store=new Map(), docEvents={}, winEvents={}, intervals=new Map(), frames=new Map(), downloads=[], blobs=new Map();let clock=0,seq=0;
 function node(id){if(!nodes.has(id))nodes.set(id,{id,value:id==='mode'?'practice':'',checked:false,hidden:false,disabled:false,textContent:'',naturalWidth:1912,complete:true,handlers:{},classList:{toggle(){}},addEventListener(n,f){this.handlers[n]=f},focus(){},getBoundingClientRect(){return{x:0,y:0,width:1200,height:678}},click(){if(this.handlers.click)this.handlers.click();else if(this.href)downloads.push(this)}});return nodes.get(id);}
 const doc={hidden:false,getElementById:node,addEventListener:(n,f)=>docEvents[n]=f,createElement:()=>({click(){downloads.push(this)}})};
 const win={visualViewport:{scale:1},addEventListener:(n,f)=>winEvents[n]=f};
 const context=vm.createContext({document:doc,window:win,visualViewport:win.visualViewport,screen:{width:1920,height:1080},innerWidth:1200,innerHeight:800,devicePixelRatio:1,Date,JSON,Object,Array,Blob,console,performance:{now:()=>clock},localStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v)},URL:{createObjectURL:b=>{const key='blob:'+ ++seq;blobs.set(key,b);return key;},revokeObjectURL(){}},setTimeout:f=>0,setInterval:f=>{const id=++seq;intervals.set(id,f);return id},clearInterval:id=>intervals.delete(id),requestAnimationFrame:f=>{const id=++seq;frames.set(id,f);return id},cancelAnimationFrame:id=>frames.delete(id)});
 vm.runInContext(code,context);
 return {node,doc,docEvents,winEvents,downloads,blobs,records:()=>JSON.parse(store.get('d-p01-5s-v1-records')||'[]'),click:id=>node(id).click(),fill(mode='practice',id='QA01'){node('mode').value=mode;node('participant').value=id;node('experience').value='中轻度手游玩家';node('prior').value='no';node('consent').checked=true;},countdown(){for(let i=0;i<3;i++)for(const fn of [...intervals.values()])fn();},frame(t){clock=t;const pending=[...frames.values()];frames.clear();pending.forEach(f=>f(t));}};
}
const results=[];
async function test(name,fn){try{await fn();results.push({name,status:'passed'})}catch(e){results.push({name,status:'failed',error:e.message})}}
(async()=>{
 await test('必填信息与同意校验',()=>{const x=setup();x.click('begin');assert.match(x.node('notice').textContent,/请填写/);assert.equal(x.records().length,0)});
 await test('曝光达到5000毫秒后遮罩与答题',()=>{const x=setup();x.fill();x.click('begin');x.countdown();x.frame(0);x.frame(4999);assert.equal(x.node('stimulus').hidden,false);x.frame(5001);assert.equal(x.node('stimulus').hidden,true);assert.equal(x.node('answer').hidden,false);x.node('q1').value='设备演练回答';x.click('save');assert.equal(x.records()[0].browser_exposure_ms,5001);assert.equal(x.records()[0].mode,'practice')});
 await test('空白回答记录为缺失',()=>{const x=setup();x.fill();x.click('begin');x.countdown();x.frame(0);x.frame(5000);x.click('save');assert.equal(x.records()[0].answers.q1.response_status,'missing')});
 await test('曝光切换窗口会保留事件',()=>{const x=setup();x.fill();x.click('begin');x.countdown();x.frame(0);x.winEvents.blur();x.frame(5000);x.click('save');assert.equal(x.records()[0].exposure_quality,'需复核');assert.equal(x.records()[0].events[0].type,'blur')});
 await test('Esc退出保存中止记录',()=>{const x=setup();x.fill();x.click('begin');x.docEvents.keydown({key:'Escape'});assert.equal(x.records()[0].status,'aborted');assert.equal(x.node('stage').hidden,true)});
 await test('已看图参与者采用演练',()=>{const x=setup();x.fill('participant');x.node('prior').value='yes';x.click('begin');assert.match(x.node('notice').textContent,/首次看图/);assert.equal(x.records().length,0)});
 await test('同一编号正式记录不重复曝光',()=>{const x=setup();x.fill('participant');x.click('begin');x.countdown();x.frame(0);x.frame(5000);x.click('save');x.click('next');x.fill('participant');x.click('begin');assert.match(x.node('notice').textContent,/已有正式记录/);assert.equal(x.records().length,1)});
 await test('正式与演练导出分开',async()=>{const x=setup();x.fill();x.click('begin');x.docEvents.keydown({key:'Escape'});x.click('export-real');x.click('export-practice');const real=JSON.parse(await x.blobs.get(x.downloads[0].href).text()),demo=JSON.parse(await x.blobs.get(x.downloads[1].href).text());assert.equal(real.record_count,0);assert.equal(demo.record_count,1);assert.equal(demo.record_type,'practice')});
 await test('关闭页面保留中止记录',()=>{const x=setup();x.fill();x.click('begin');x.winEvents.pagehide();assert.equal(x.records()[0].status,'aborted')});
 const out=path.join(root,'outputs/d_expansion_20261021/qa');fs.mkdirSync(out,{recursive:true});const report={method:'Node 隔离环境中的 DOM 与时钟模拟；验证记录流程，不产生研究数据',passed:results.filter(r=>r.status==='passed').length,total:results.length,tests:results};fs.writeFileSync(path.join(out,'实验工具逻辑校验.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));process.exitCode=results.some(r=>r.status==='failed')?1:0;
})();
