"""汇总五秒识别导出与主持人判分；自由文本始终由主持人判分。"""

from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math


STUDY_ID = "D-P01-5s-v1"
IMAGE_SHA256 = "f1201f54c66f3210ed14bd8785f0a3c532ee0e89cd6d3992cfaeb9970b7db1ed"
QUESTIONS = ("Q1", "Q2", "Q3")
LABELS = {
    "correct": "正确", "incorrect": "错误", "missing": "缺失", "unscored": "未判分",
    "aborted": "中止", "device_anomaly": "设备异常", "incomplete": "记录待补",
    "participant_duplicate": "编号重复待确认", "record_conflict": "记录内容矛盾待确认",
    "score_conflict": "判分矛盾待确认", "score_invalid": "判分内容待确认",
}
SCORE_LABELS = {"正确": "correct", "错误": "incorrect", "缺失": "missing",
                "中止": "aborted", "设备异常": "device_anomaly", "未判分": "unscored", "": "unscored"}


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _digest(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _issue(kind, message, **details):
    return {"type": kind, "message": message, **details}


def _score_index(scores_path, issues):
    """判分使用既有主持人判分表的 scored_records，不接受数值代替标签。"""
    index = defaultdict(list)
    if scores_path is None:
        return index
    path = Path(scores_path).resolve()
    try:
        data = _read_json(path)
    except (OSError, ValueError) as exc:
        issues.append(_issue("score_file", "判分文件未读入。", source=str(path), detail=str(exc)))
        return index
    if not isinstance(data, dict) or data.get("study_id") != STUDY_ID or not isinstance(data.get("scored_records"), list):
        issues.append(_issue("score_schema", "判分表应包含本轮 study_id 和 scored_records 列表。", source=str(path)))
        return index
    for row_number, row in enumerate(data["scored_records"], 1):
        source = {"path": str(path), "row": row_number}
        if not isinstance(row, dict):
            issues.append(_issue("score_row", "判分条目应为对象。", source=source))
            continue
        session_id = row.get("session_id")
        question_id = row.get("question_id")
        if not isinstance(session_id, str) or not session_id.strip() or question_id not in QUESTIONS:
            # 空白模板可以原样存在，不产生真实记录。
            if all(not row.get(key) for key in ("session_id", "participant_id", "question_id", "original_answer", "label", "scorer", "reason")):
                continue
            issues.append(_issue("score_identity", "判分需填写 session_id 和 Q1、Q2 或 Q3。", source=source))
            continue
        index[(session_id, question_id)].append({"value": row, "source": source})
    return index


def _record_problems(record):
    """核对方案身份与实际页面会导出的字段。"""
    problems = []
    checks = (
        (record.get("schema_version") == "1.0", "记录版本应为 1.0"),
        (record.get("study_id") == STUDY_ID, "记录方案应为 D-P01-5s-v1"),
        (record.get("mode") in ("participant", "practice"), "记录类型应为正式或演练"),
        (isinstance(record.get("participant_id"), str) and bool(record["participant_id"].strip()), "匿名编号待填写"),
        (record.get("image") == "P01" and record.get("image_sha256") == IMAGE_SHA256, "图片版本需与方案一致"),
        (record.get("planned_exposure_ms") == 5000, "计划曝光应为 5000 毫秒"),
        (record.get("consent") is True, "参与确认待记录"),
        (record.get("status") in ("completed", "aborted", "in_progress"), "完成状态待确认"),
        (isinstance(record.get("events"), list), "窗口事件列表待补"),
    )
    for valid, message in checks:
        if not valid:
            problems.append(message)
    if isinstance(record.get("events"), list) and any(
            not isinstance(event, dict) or not isinstance(event.get("type"), str)
            or event.get("phase") not in ("countdown", "exposure", "answer") for event in record["events"]):
        problems.append("窗口事件条目格式待核对")
    if record.get("mode") == "participant":
        if record.get("prior_exposure") != "no":
            problems.append("正式记录需为首次看图")
        if record.get("experience") != "中轻度手游玩家":
            problems.append("正式记录需符合本轮玩家背景")
    return problems


def _record_category(record):
    problems = _record_problems(record)
    if problems:
        return "incomplete", problems
    if record["status"] == "aborted":
        return "aborted", ["原记录标记主动退出或中止"]
    if record["status"] != "completed":
        return "incomplete", ["本条尚未完成作答与保存"]
    exposure_events = [event for event in record["events"] if isinstance(event, dict)
                       and event.get("phase") == "exposure" and event.get("type") in ("hidden", "blur", "resize")]
    if exposure_events or record.get("exposure_quality") == "需复核":
        return "device_anomaly", ["曝光期间存在窗口切换、失焦、尺寸变化或需复核标记"]
    exposure = record.get("browser_exposure_ms")
    if isinstance(exposure, bool) or not isinstance(exposure, (int, float)) or not math.isfinite(exposure) or exposure <= 0:
        return "incomplete", ["浏览器曝光间隔待补"]
    if exposure < record["planned_exposure_ms"]:
        return "device_anomaly", ["实际曝光短于计划的 5000 毫秒"]
    if record.get("exposure_quality") != "按计划完成":
        return "incomplete", ["曝光完成标记待确认"]
    return "eligible", []


def _judge_question(record, question_id, score_rows, base_category):
    answers = record.get("answers")
    answer = answers.get(question_id.lower()) if isinstance(answers, dict) else None
    text = answer.get("text") if isinstance(answer, dict) else None
    result = {"question_id": question_id, "original_answer": text,
              "score_sources": [row["source"] for row in score_rows], "reason": ""}
    if base_category != "eligible":
        result.update(category=base_category, reason="依本条记录状态单列")
        return result
    if not isinstance(answer, dict) or not isinstance(text, str):
        result.update(category="incomplete", reason="该题答案字段待补；已导出的空白回答按缺失统计")
        return result
    is_blank = not text.strip()
    if answer.get("response_status") != ("missing" if is_blank else "answered"):
        result.update(category="incomplete", reason="答案原话与作答状态需核对")
        return result
    distinct = {_canonical(row["value"]): row for row in score_rows}
    if len(distinct) > 1:
        result.update(category="score_conflict", reason="同一题存在不同判分条目，请保留确认后的单条判分")
        return result
    if not distinct:
        result.update(category="missing" if is_blank else "unscored",
                      reason="原回答为空白" if is_blank else "已有原话，等待主持人判分")
        return result
    score = next(iter(distinct.values()))["value"]
    label = score.get("label", "")
    if not isinstance(label, str) or label not in SCORE_LABELS:
        result.update(category="score_invalid", reason="判分标签应填写中文状态；数值 0 不代表空白")
        return result
    if score.get("participant_id") != record.get("participant_id") or score.get("original_answer") != text:
        result.update(category="score_invalid", reason="判分编号及原话需与对应导出记录完全一致")
        return result
    if label in ("", "未判分"):
        result.update(category="missing" if is_blank else "unscored", reason="原回答为空白" if is_blank else "主持人尚未判分")
        return result
    if (is_blank and label in ("正确", "错误")) or (not is_blank and label == "缺失"):
        result.update(category="score_invalid", reason="判分状态与回答是否为空需核对")
        return result
    if not all(isinstance(score.get(key), str) and score[key].strip() for key in ("scorer", "reason")):
        result.update(category="score_invalid", reason="已判分条目需补齐主持人和判分理由")
        return result
    result.update(category=SCORE_LABELS[label], reason=score["reason"], scorer=score["scorer"])
    return result


def aggregate_recognition(input_dir: Path, scores_path: Path | None = None) -> dict:
    """读取真实页面导出。空目录显示尚待记录；比例分母仅为正确与错误。"""
    input_dir = Path(input_dir).resolve()
    issues = []
    grouped = defaultdict(list)
    files = []
    rejected_records = []
    scores = _score_index(scores_path, issues)
    score_file = Path(scores_path).resolve() if scores_path is not None else None
    if not input_dir.exists():
        paths = []
        issues.append(_issue("input_directory", "输入目录尚未建立。", source=str(input_dir)))
    elif not input_dir.is_dir():
        paths = []
        issues.append(_issue("input_directory", "输入路径应为收取识别 JSON 的目录。", source=str(input_dir)))
    else:
        paths = sorted(path for path in input_dir.rglob("*.json") if path.resolve() != score_file)
    for path in paths:
        source = str(path.resolve())
        try:
            data = _read_json(path)
        except (OSError, ValueError) as exc:
            issues.append(_issue("input_file", "文件未读入。", source=source, detail=str(exc)))
            continue
        if (not isinstance(data, dict) or data.get("study_id") != STUDY_ID
                or data.get("record_type") not in ("participant", "practice")
                or not isinstance(data.get("records"), list)):
            issues.append(_issue("export_schema", "文件应为本轮页面导出的正式或演练 JSON。", source=source))
            continue
        if data.get("record_count") != len(data["records"]):
            issues.append(_issue("record_count", "外层记录数与 records 实际长度不同，按逐条记录核对。", source=source))
        files.append({"path": source, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "record_type": data["record_type"], "exported_at": data.get("exported_at"),
                      "record_count": len(data["records"])})
        for position, record in enumerate(data["records"], 1):
            location = {"path": source, "record_number": position}
            if not isinstance(record, dict) or not isinstance(record.get("session_id"), str) or not record["session_id"].strip():
                rejected_records.append({"source": location, "reason": "记录对象及 session_id 待补"})
                continue
            item = {"value": record, "source": location, "fingerprint": _digest(record),
                    "container_mismatch": record.get("mode") != data["record_type"]}
            if item["container_mismatch"]:
                issues.append(_issue("record_type", "外层导出类型与记录类型不同，本条待确认。", source=location,
                                     session_id=record["session_id"]))
            grouped[record["session_id"]].append(item)

    # 相同会话的同一份内容被重复导出时只计算一次，保留全部来源。
    records = []
    duplicate_exports = []
    conflict_sessions = []
    for session_id, versions in sorted(grouped.items()):
        by_fingerprint = defaultdict(list)
        for version in versions:
            by_fingerprint[version["fingerprint"]].append(version)
        if len(versions) > len(by_fingerprint):
            duplicate_exports.append({"session_id": session_id, "copies": len(versions),
                                      "distinct_versions": len(by_fingerprint),
                                      "duplicate_copies_removed": len(versions) - len(by_fingerprint),
                                      "sources": [row["source"] for row in versions]})
        first = versions[0]["value"]
        distinct_modes = {row["value"].get("mode") if isinstance(row["value"].get("mode"), str) else None
                          for row in versions}
        mode = next(iter(distinct_modes)) if len(distinct_modes) == 1 else "conflict"
        output = {"session_id": session_id, "participant_id": first.get("participant_id"), "mode": mode,
                  "sources": [row["source"] for row in versions],
                  "record_sha256": list(by_fingerprint), "original_status": first.get("status"),
                  "browser_exposure_ms": first.get("browser_exposure_ms"),
                  "record": first, "questions": []}
        if len(by_fingerprint) > 1:
            output.update(category="record_conflict", reasons=["同一 session_id 的记录内容不同"])
            output["conflicting_versions"] = [{"sha256": fingerprint, "record": rows[0]["value"],
                                               "sources": [row["source"] for row in rows]}
                                              for fingerprint, rows in by_fingerprint.items()]
            conflict_sessions.append(session_id)
        elif any(row["container_mismatch"] for row in versions):
            output.update(category="incomplete", reasons=["导出类型与条目类型需核对"])
        else:
            output["category"], output["reasons"] = _record_category(first)
        records.append(output)

    # 同一人跨会话再次曝光不作两名参与者；由主持人核对编号和首次观看记录。
    participants = defaultdict(list)
    for entry in records:
        participant_id = entry["participant_id"]
        if entry["mode"] == "participant" and isinstance(participant_id, str) and participant_id.strip():
            participants[participant_id].append(entry)
    participant_duplicates = []
    for participant_id, entries in sorted(participants.items()):
        if len(entries) > 1:
            participant_duplicates.append({"participant_id": participant_id,
                                           "session_ids": [entry["session_id"] for entry in entries]})
            for entry in entries:
                entry["reasons"].append("同一匿名编号出现多个会话，待主持人确认首次观看记录")
                if entry["category"] != "record_conflict":
                    entry["category"] = "participant_duplicate"

    used_scores = set()
    for entry in records:
        for question_id in QUESTIONS:
            key = (entry["session_id"], question_id)
            if key in scores:
                used_scores.add(key)
            judged = _judge_question(entry["record"], question_id, scores.get(key, []), entry["category"])
            judged["label"] = LABELS[judged["category"]]
            entry["questions"].append(judged)
        entry["label"] = "可判分记录" if entry["category"] == "eligible" else LABELS[entry["category"]]
    for key in sorted(scores.keys() - used_scores):
        issues.append(_issue("orphan_score", "判分未找到对应导出会话。", session_id=key[0], question_id=key[1],
                             sources=[row["source"] for row in scores[key]]))

    formal = [entry for entry in records if entry["mode"] == "participant"]
    practice = [entry for entry in records if entry["mode"] == "practice"]
    status = "已收取记录" if formal else ("待核对记录" if issues or rejected_records or len(records) > len(practice) else "尚待记录")
    questions = {}
    for question_id in QUESTIONS:
        counts = dict.fromkeys(LABELS, 0)
        for entry in formal:
            result = next(item for item in entry["questions"] if item["question_id"] == question_id)
            counts[result["category"]] += 1
        denominator = counts["correct"] + counts["incorrect"]
        questions[question_id] = {"counts": counts, "count_labels": LABELS.copy(),
                                  "valid_denominator": denominator, "correct_numerator": counts["correct"],
                                  "correct_ratio": counts["correct"] / denominator if denominator else None,
                                  "correct_percentage": 100 * counts["correct"] / denominator if denominator else None,
                                  "ratio_text": f"{counts['correct']}/{denominator}（{100 * counts['correct'] / denominator:.1f}%）" if denominator else "暂无有效判分分母",
                                  "status": "已汇总" if denominator else (status if not formal else "待形成有效判分")}
    return {"study_id": STUDY_ID, "schema_version": "1.0", "author": "逐题判分与程序汇总",
            "status": status,
            "input_dir": str(input_dir), "score_source": str(score_file) if score_file else None,
            "scoring_basis": "分题有效回答为正确与错误之和；自由文本依据逐题判分表；判分者见各条 scorer。",
            "files": files, "formal_session_count": len(formal), "formal_participant_id_count": len(participants),
            "eligible_formal_session_count": sum(entry["category"] == "eligible" for entry in formal),
            "practice_session_count": len(practice), "unclassified_session_count": len(records) - len(formal) - len(practice),
            "record_status_counts": dict(Counter(entry["category"] for entry in formal)),
            "questions": questions, "records": records, "duplicate_exports": duplicate_exports,
            "participant_duplicates": participant_duplicates, "conflicting_sessions": conflict_sessions,
            "rejected_records": rejected_records, "issues": issues}
