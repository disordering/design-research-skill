"""按有明确来源的冻结参考计算发现覆盖率与错误发现占比。

同一位置、现象及修改动作是一项具体发现；规则编号不是去重键。
共识参考沿用原 records 结构，并在整份文件中确认 sample_scope。
匹配文件格式：
  {"model_sample_scope": ["S01"],
   "sample_sources": [{"sample_id": "S01", "source_file": "report.json",
                       "source_sha256": "..."}],
   "records": [{"model_finding_id": "S01/F001", "status": "unresolved",
                "reference_ids": [], "reason": "", "confirmed_by": []}]}
已确认匹配、有效新发现、误报均填写两位确认者和判断依据。有效新发现
计入模型发现的判定总数，保持冻结参考集及其召回分母不变。
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


FINAL_STATES = {"confirmed_match", "valid_new_finding", "false_positive"}
MATCH_STATES = FINAL_STATES | {"unresolved"}
REFERENCE_STATES = {"candidate_issue", "no_visible_issue", "insufficient_evidence", "not_applicable"}


def _text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _strings(value: Any) -> bool:
    return isinstance(value, list) and all(_text(item) for item in value)


def _has_evidence(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip() not in {"", "暂无", "待填写", "无", "待补充"}
    if isinstance(value, dict):
        return any(_has_evidence(item) for item in value.values())
    if isinstance(value, list):
        return any(_has_evidence(item) for item in value)
    return False


def _rate(numerator: int, denominator: int, ready: bool) -> dict:
    return {
        "numerator": numerator,
        "denominator": denominator,
        "rate": numerator / denominator if ready and denominator else None,
        "status": "待完成共识与逐项匹配" if not ready else "不适用：分母为零" if not denominator else "已计算",
    }


def summarize_effect(reference_path: Path | None, matching_path: Path | None,
                     model_catalog: list[dict]) -> dict:
    """返回可序列化汇总；输入问题列入 issues，不以缺记录充当 0% 或误报。"""
    issues: list[dict] = []
    sources: list[dict] = []

    def issue(code: str, message: str, *, level: str = "error", item: str = "") -> None:
        issues.append({"code": code, "level": level, "item": item, "message": message})

    def read(path: Path | None, role: str) -> dict:
        if path is None or not Path(path).is_file():
            issue("missing_" + role, "待放入" + ("人类共识参考。" if role == "reference" else "模型发现逐项匹配表。"), level="pending")
            return {}
        try:
            raw = Path(path).read_bytes()
            value = json.loads(raw.decode("utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            issue("invalid_" + role, "文件读取失败：" + str(exc), item=str(path))
            return {}
        sources.append({"role": role, "path": str(path), "sha256": hashlib.sha256(raw).hexdigest()})
        if not isinstance(value, dict):
            issue("invalid_" + role, "文件顶层应为 JSON 对象。", item=str(path))
            return {}
        return value

    reference = read(reference_path, "reference")
    matching = read(matching_path, "matching")
    source_type = reference.get('source_type', 'human_consensus')
    if source_type not in ('human_consensus', 'ai_simulation'):
        issue('invalid_source_type', '参考来源填写 human_consensus 或 ai_simulation。')
    simulation = source_type == 'ai_simulation'
    reviewers = reference.get("reviewers", [])
    scope = reference.get("sample_scope", [])
    finalized = reference.get("finalized") is True
    if not _strings(scope) or len(set(scope)) != len(scope):
        issue("invalid_sample_scope", "sample_scope 应填写互不重复的样本编号。")
        scope = []
    if not scope:
        issue("empty_sample_scope", "待确认本次完整评审的样本范围。", level="pending")
    if not finalized:
        issue("reference_not_finalized", "两位评审者完成共识后，将 finalized 改为 true。", level="pending")
    if finalized:
        if reference.get("protocol_version") != "D v1.1":
            issue("protocol_mismatch", "共识口径须为 D v1.1。")
        if not _strings(reviewers) or len(reviewers) != 2 or len(set(reviewers)) != 2:
            issue("invalid_reviewers", "冻结共识由两位不同编号的评审者确认。")
        confirmed = reference.get("confirmed_by", [])
        if not _strings(confirmed) or len(confirmed) != 2 or not _strings(reviewers) or set(confirmed) != set(reviewers):
            issue("reference_confirmation_missing", "confirmed_by 填写同一组两位评审者编号。")
        if not _text(reference.get("finalized_at")):
            issue("finalized_at_missing", "填写共识冻结时间 finalized_at。")
        if not _strings(reference.get("independent_files")) or len(set(reference["independent_files"])) < 2:
            issue("independent_files_missing", "保留两份独立评审文件路径。")

    records = reference.get("records", [])
    if not isinstance(records, list):
        issue("invalid_reference_records", "共识 records 应为数组。")
        records = []
    references: dict[str, dict] = {}
    all_reference_ids: set[str] = set()
    for number, rec in enumerate(records, 1):
        if not isinstance(rec, dict) or not _text(rec.get("reference_id")):
            issue("invalid_reference_record", "共识条目需要唯一 reference_id。", item=str(number))
            continue
        rid = rec["reference_id"]
        if rid in all_reference_ids:
            issue("duplicate_reference_id", "共识参考编号重复，保留一项具体发现的唯一编号。", item=rid)
            continue
        all_reference_ids.add(rid)
        sid = rec.get("sample_id")
        if not _text(sid) or sid not in scope:
            issue("reference_outside_scope", "共识条目的样本不在已声明的 sample_scope 中。", item=rid)
        if not isinstance(rec.get("decision"), str) or rec.get("decision") not in REFERENCE_STATES:
            issue("invalid_reference_decision", "共识 decision 不是规定的四种规则状态。", item=rid)
        if rec.get("decision") != "candidate_issue":
            continue
        references[rid] = rec
        if finalized:
            for field in ("location", "phenomenon", "evidence", "resolution_reason"):
                if not _has_evidence(rec.get(field)):
                    issue("reference_detail_missing", "补齐具体发现的 " + field + "。", item=rid)
            rules = rec.get("rule_ids")
            if not _strings(rules) or not rules or len(set(rules)) != len(rules) or any(not re.fullmatch(r"R(?:0[1-9]|1[0-9]|2[0-4])", rule) for rule in rules):
                issue("invalid_reference_rules", "通用评审的 rule_ids 填写 R01–R24；P01 的目标建议另行统计。", item=rid)

    catalog: dict[str, dict] = {}
    if not isinstance(model_catalog, list):
        issue("invalid_model_catalog", "模型发现目录应为数组。")
        model_catalog = []
    for number, rec in enumerate(model_catalog, 1):
        if not isinstance(rec, dict) or not _text(rec.get("model_finding_id")) or not _text(rec.get("sample_id")):
            issue("invalid_model_finding", "模型发现需要唯一编号与样本编号。", item=str(number))
            continue
        mid = rec["model_finding_id"]
        if mid in catalog:
            issue("duplicate_model_id", "模型发现编号重复。", item=mid)
            continue
        catalog[mid] = rec
        rules = rec.get("rule_ids")
        if not _strings(rules) or not rules or len(set(rules)) != len(rules) or any(not re.fullmatch(r"R(?:0[1-9]|1[0-9]|2[0-4])", rule) for rule in rules):
            issue("invalid_model_rules", "通用模型目录只收录 R01–R24 发现；目标建议另存。", item=mid)
        if not mid.startswith(rec["sample_id"] + "/"):
            issue("model_id_sample_mismatch", "模型发现编号以所属样本编号加斜杠开头，例如 S07/F001。", item=mid)

    model_scope = matching.get("model_sample_scope", [])
    if not _strings(model_scope) or len(set(model_scope)) != len(model_scope):
        issue("invalid_model_scope", "model_sample_scope 应为互不重复的样本编号数组。")
        model_scope = []
    raw_sample_sources = matching.get("sample_sources", [])
    if not isinstance(raw_sample_sources, list):
        issue("invalid_sample_sources", "sample_sources 应为逐样本原报告来源数组。")
        raw_sample_sources = []
    sample_sources: dict[str, dict] = {}
    for rec in raw_sample_sources:
        if not isinstance(rec, dict) or not _text(rec.get("sample_id")):
            issue("invalid_sample_source", "每个报告来源需要 sample_id。")
            continue
        sid = rec["sample_id"]
        if sid in sample_sources:
            issue("duplicate_sample_source", "每个样本本次只选定一份模型报告。", item=sid)
            continue
        sample_sources[sid] = rec
        if not _text(rec.get("source_file")) or not isinstance(rec.get("source_sha256"), str) or not re.fullmatch(r"[0-9a-fA-F]{64}", rec["source_sha256"]):
            issue("invalid_sample_provenance", "报告来源需要文件路径和 SHA-256。", item=sid)
    for sid in model_scope:
        if sid not in sample_sources:
            issue("missing_sample_source", "补齐样本原报告来源；零发现也保留报告。", item=sid)
    for sid in scope:
        if sid not in model_scope:
            issue("model_sample_missing", "共识范围内的样本尚未绑定本次模型报告。", level="pending", item=sid)
    for mid, rec in catalog.items():
        sid = rec["sample_id"]
        if sid not in model_scope:
            issue("catalog_outside_model_scope", "目录中的模型样本未列入 model_sample_scope。", item=mid)
        source = sample_sources.get(sid)
        if source and (rec.get("source_file") != source.get("source_file") or str(rec.get("source_sha256", "")).lower() != str(source.get("source_sha256", "")).lower()):
            issue("catalog_source_mismatch", "模型目录与样本来源所指的报告不同。", item=mid)

    rows = matching.get("records", [])
    if not isinstance(rows, list):
        issue("invalid_matching_records", "匹配 records 应为数组。")
        rows = []
    mappings: dict[str, dict] = {}
    reference_to_models: dict[str, list[str]] = {}
    for number, rec in enumerate(rows, 1):
        if not isinstance(rec, dict) or not _text(rec.get("model_finding_id")):
            issue("invalid_matching_record", "匹配条目需要 model_finding_id。", item=str(number))
            continue
        mid = rec["model_finding_id"]
        if mid in mappings:
            issue("duplicate_matching_id", "同一模型发现重复出现，合并为一条最终判断。", item=mid)
            continue
        mappings[mid] = rec
        if mid not in catalog:
            issue("unknown_model_id", "匹配条目未出现在选定的模型目录中。", item=mid)
            continue
        state = rec.get("status")
        links = rec.get("reference_ids", [])
        if not isinstance(state, str) or state not in MATCH_STATES:
            issue("invalid_matching_status", "选择已确认匹配、有效新发现、误报或未决。", item=mid)
            state = "invalid"
            mappings[mid] = {**rec, "status": state}
        if not _strings(links) or len(set(links)) != len(links):
            issue("invalid_reference_links", "reference_ids 应是互不重复的参考编号数组。", item=mid)
            links = []
        if state == "confirmed_match" and len(links) != 1:
            evidence = rec.get('reference_link_evidence', [])
            covered = {r.get('reference_id'): r.get('reason') for r in evidence if isinstance(r, dict)} if isinstance(evidence, list) else {}
            if not links or len(covered)!=len(links) or set(covered)!=set(links) or any(not _has_evidence(v) for v in covered.values()):
                issue("match_unit_conflict", "一项模型发现对应多项独立参考时，逐项填写 reference_link_evidence 的 reference_id 与覆盖依据。", item=mid)
        if state != "confirmed_match" and links:
            issue("unexpected_reference_links", "仅 confirmed_match 填写 reference_ids；其他状态清空该列表。", item=mid)
        if state in FINAL_STATES and catalog[mid]["sample_id"] in scope:
            confirmation = rec.get("confirmed_by", [])
            if not _strings(confirmation) or len(confirmation) != 2 or not _strings(reviewers) or set(confirmation) != set(reviewers):
                issue("matching_confirmation_missing", "最终匹配判断由同一组两位评审者确认。", item=mid)
            if not _has_evidence(rec.get("reason")):
                issue("matching_reason_missing", "填写位置、具体表现及判定依据。", item=mid)
        for rid in links:
            if rid not in references:
                issue("unknown_reference_id", "匹配须指向已记录的 candidate_issue 共识参考。", item=mid + " → " + rid)
            elif references[rid].get("sample_id") != catalog[mid]["sample_id"]:
                issue("cross_sample_match", "模型发现和共识参考须来自同一张样本图。", item=mid + " → " + rid)
            elif state == "confirmed_match":
                reference_to_models.setdefault(rid, []).append(mid)
    for rid, mids in reference_to_models.items():
        if len(mids) > 1:
            issue("duplicate_reference_match", "多项模型发现链接同一参考：" + "、".join(mids) + "。先核对重复与具体问题单位。", item=rid)

    sample_rows: list[dict] = []
    for sid in scope:
        mids = [mid for mid, rec in catalog.items() if rec["sample_id"] == sid]
        rids = [rid for rid, rec in references.items() if rec.get("sample_id") == sid]
        states = Counter(mappings[mid].get("status") for mid in mids if mid in mappings)
        missing = [mid for mid in mids if mid not in mappings]
        unresolved = [mid for mid in mids if mid in mappings and mappings[mid].get("status") not in FINAL_STATES]
        matched = {rid for rid in rids if rid in reference_to_models}
        if missing:
            issue("missing_mappings", "待逐项判定：" + "、".join(missing), level="pending", item=sid)
        if unresolved:
            issue("unresolved_mappings", "待完成判断：" + "、".join(unresolved), level="pending", item=sid)
        sample_rows.append({
            "sample_id": sid,
            "model_report_present": sid in model_scope and sid in sample_sources,
            "reference_count": len(rids), "model_finding_count": len(mids),
            "matched_reference_count": len(matched),
            "unmatched_reference_ids": sorted(set(rids) - matched),
            "confirmed_match_count": states["confirmed_match"],
            "valid_new_finding_count": states["valid_new_finding"],
            "false_positive_count": states["false_positive"],
            "unresolved_count": len(unresolved), "missing_mapping_count": len(missing),
            "missing_mapping_ids": missing, "unresolved_ids": unresolved,
        })

    ready = finalized and bool(scope) and not issues
    counts = {key: sum(row[key] for row in sample_rows) for key in (
        "reference_count", "model_finding_count", "matched_reference_count", "confirmed_match_count",
        "valid_new_finding_count", "false_positive_count", "unresolved_count", "missing_mapping_count")}
    judged = counts["confirmed_match_count"] + counts["valid_new_finding_count"] + counts["false_positive_count"]
    for row in sample_rows:
        row["reference_recall"] = _rate(row["matched_reference_count"], row["reference_count"], ready)
        row["false_positive_share"] = _rate(row["false_positive_count"], row["model_finding_count"], ready)
    error_count = sum(i["level"] == "error" for i in issues)
    return {
        "schema_version": 1,
        "status": ("AI 模拟对照已完成" if simulation else "已完成") if ready else "核对输入" if error_count else "待共识" if not finalized else "待匹配",
        "source_type": source_type,
        "source_label": "AI 模拟共识" if simulation else "真人共识",
        "calculation_ready": ready,
        "simulation_metrics_ready": ready and simulation,
        "formal_metrics_ready": ready and not simulation,
        "protocol_version": "D v1.1",
        "sample_scope": scope, "model_sample_scope": model_scope,
        "samples_outside_reference_scope": sorted(set(model_scope) - set(scope)),
        "counts": {**counts, "judged_model_finding_count": judged, "catalog_model_finding_count": len(catalog)},
        "reference_recall": _rate(counts["matched_reference_count"], counts["reference_count"], ready),
        "false_positive_share": _rate(counts["false_positive_count"], counts["model_finding_count"], ready),
        "samples": sample_rows, "issues": issues, "sources": sources,
        "counting_unit": "同一位置、同一具体表现、同一修改动作的独立发现；各规则状态另行统计。",
        "metric_note": "覆盖率按唯一参考问题计数，错误发现占比按模型发现计数；一项模型发现同时覆盖多个参考时保留逐项依据。错误占比分母包含已确认匹配、误报和有效新发现。全部逐项判定完成后输出比例，分母为零显示不适用。",
    }
