"""读取评审工作台 JSON，保留原始选择并对照两位评审者。"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re

RULE_STATES = {'candidate_issue', 'no_visible_issue', 'insufficient_evidence', 'not_applicable'}
GOAL_STATES = {'met', 'observed_violation', 'insufficient_evidence'}
ISSUES = {'candidate_issue', 'observed_violation'}
NEED_EVIDENCE = ISSUES | {'no_visible_issue', 'met'}


def filled(value):
    return isinstance(value, str) and value.strip() not in {'', '暂无', '未填写'}


def unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('JSON 包含重复字段：' + key)
        result[key] = value
    return result


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'), object_pairs_hook=unique_keys)


def summarize_reviews(input_dir: Path, materials_path: Path) -> dict:
    materials = load_json(materials_path)
    expected = [(s['id'], i['id']) for s in materials['samples']
                for i in materials['rules'] + (materials['goals'] if s['id'] == 'P01' else [])]
    expected_set = set(expected)
    sources, errors, duplicates = [], [], []
    by_reviewer = defaultdict(list)
    for path in sorted(p for p in input_dir.glob('*.json') if p.is_file()):
        try:
            source = {'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            sources.append(source)
            state = load_json(path)
            if not isinstance(state, dict) or type(state.get('schemaVersion')) is not int or state['schemaVersion'] != 1:
                raise ValueError('不是评审工作台版本 1 的备份')
            if state.get('materialVersion') != materials['version']:
                raise ValueError('材料版本不符')
            reviewer = state.get('reviewer')
            if not isinstance(reviewer, dict) or not filled(reviewer.get('code')):
                raise ValueError('缺少评审者编号')
            reviews = state.get('reviews')
            if not isinstance(reviews, dict):
                raise ValueError('reviews 必须为对象')
            judgments, finding_count, complete, evidence, reasons = {}, 0, 0, 0, 0
            finding_ids = set()
            for sid, review in reviews.items():
                if sid not in {s for s, _ in expected} or not isinstance(review, dict):
                    raise ValueError('未知样本或样本格式错误：' + str(sid))
                rows, findings = review.get('judgments', {}), review.get('findings', [])
                if not isinstance(rows, dict) or not isinstance(findings, list):
                    raise ValueError(sid + ' 的判断/问题格式错误')
                valid_related = set()
                for finding in findings:
                    if not isinstance(finding, dict) or not filled(finding.get('id')):
                        raise ValueError(sid + ' 的问题记录缺少编号')
                    fid = finding['id']
                    match = re.fullmatch(re.escape(sid) + r'-F([0-9]+)', fid)
                    if not match or not 0 < int(match.group(1)) < 9007199254740991:
                        raise ValueError('具体问题编号格式错误：' + fid)
                    if fid in finding_ids:
                        raise ValueError('具体问题编号重复：' + fid)
                    finding_ids.add(fid)
                    related = finding.get('relatedIds', [])
                    if not isinstance(related, list) or any(not isinstance(i, str) for i in related):
                        raise ValueError(fid + ' 的关联编号格式错误')
                    if any((sid, i) not in expected_set for i in related):
                        raise ValueError(fid + ' 关联未知条目')
                    if (related and len(set(related)) == len(related)
                            and all(filled(finding.get(k)) for k in ['location', 'phenomenon', 'impact', 'suggestion'])
                            and finding.get('severity') in ['高', '中', '低', '未知']
                            and all(isinstance(rows.get(i), dict) and rows[i].get('decision') in ISSUES for i in related)):
                        valid_related.update(related)
                finding_count += len(findings)
                for item, row in rows.items():
                    if (sid, item) not in expected_set or not isinstance(row, dict):
                        raise ValueError(sid + '/' + str(item) + ' 是未知或格式错误的条目')
                    decision = row.get('decision', '')
                    allowed = RULE_STATES if item.startswith('R') else GOAL_STATES
                    if not isinstance(decision, str) or decision not in allowed | {''}:
                        raise ValueError(sid + '/' + item + ' 判断状态无效')
                    judgments[(sid, item)] = decision
                    has_reason, has_evidence = filled(row.get('reason')), filled(row.get('evidence'))
                    reasons += int(has_reason)
                    evidence += int(has_evidence)
                    complete += int(bool(decision) and has_reason and (decision not in NEED_EVIDENCE or has_evidence)
                                    and (decision not in ISSUES or item in valid_related))
            # 导出时间、当前打开的页面变化不改变评审内容；原始文件哈希仍逐份留存。
            semantic = json.dumps({'reviewer': reviewer, 'reviews': reviews}, ensure_ascii=False, sort_keys=True)
            result = {'reviewer_code': reviewer['code'].strip(), 'selected_items': sum(bool(v) for v in judgments.values()),
                      'expected_items': len(expected), 'recorded_complete_items': complete,
                      'reasons': reasons, 'non_placeholder_evidence': evidence, 'findings': finding_count,
                      'state_counts': dict(Counter(v for v in judgments.values() if v)), 'source_files': [path.name]}
            by_reviewer[result['reviewer_code']].append((semantic, result, judgments))
        except (OSError, ValueError, TypeError, KeyError) as exc:
            errors.append({'file': path.name, 'message': str(exc)})
    accepted = []
    for code, entries in sorted(by_reviewer.items()):
        if len({x[0] for x in entries}) > 1:
            errors.append({'reviewer_code': code, 'message': '同一编号存在不同内容；请在输入目录中只保留该评审者本轮使用的一份备份。',
                           'files': [x[1]['source_files'][0] for x in entries]})
            continue
        _, info, rows = entries[0]
        info['source_files'] = [x[1]['source_files'][0] for x in entries]
        if len(entries) > 1:
            duplicates.append({'reviewer_code': code, 'files': info['source_files']})
        accepted.append((info, rows))
    comparison = None
    if len(accepted) == 2 and not errors:
        rows = []
        for sid, item in expected:
            a, b = accepted[0][1].get((sid, item), ''), accepted[1][1].get((sid, item), '')
            rows.append({'sample_id': sid, 'item_id': item, 'reviewer_1': a, 'reviewer_2': b,
                         'comparable': bool(a and b), 'agree': a == b if a and b else None})
        def summarize(group):
            eligible = [r for r in group if r['comparable']]
            agreed = sum(r['agree'] for r in eligible)
            return {'expected': len(group), 'compared': len(eligible), 'missing': len(group)-len(eligible),
                    'agreed': agreed, 'disagreed': len(eligible)-agreed,
                    'agreement_ratio': agreed/len(eligible) if eligible else None}
        comparison = {'reviewer_codes': [x[0]['reviewer_code'] for x in accepted], 'all': summarize(rows),
                      'rules': summarize([r for r in rows if r['item_id'].startswith('R')]),
                      'goals': summarize([r for r in rows if r['item_id'].startswith('G')]),
                      'candidate_union': sum(r['reviewer_1'] in ISSUES or r['reviewer_2'] in ISSUES for r in rows),
                      'rows': rows}
    return {'status': '需核对输入' if errors else ('已完成双评审选择对照' if comparison else '等待两份独立记录'),
            'material_version': materials['version'], 'sources': sources, 'reviewers': [x[0] for x in accepted],
            'duplicate_exports': duplicates, 'errors': errors, 'comparison': comparison,
            '口径': '只比较双方已选择的状态，缺项单列；G02 汇总不重复计数。判断理由和具体问题按原文记录，内容含义由评审者复核。'}
