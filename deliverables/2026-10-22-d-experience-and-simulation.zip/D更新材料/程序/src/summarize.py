"""D 本地收取与汇总入口，输出 JSON 明细和中文摘要。"""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

from reviews import load_json, summarize_reviews
from recognition import aggregate_recognition
from effect_metrics import summarize_effect
from tool_experience import summarize_experience


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def verify_catalog(root):
    """由固定报告逐项复核目录，包含零发现样本，避免修改输入后沿用旧分母。"""
    payload = load_json(root/'材料/模型发现目录.json')
    catalog, sources = payload['catalog'], payload['sample_sources']
    rebuilt, known_samples = [], set()
    for row in sources:
        sid = row['sample_id']
        if sid in known_samples:
            raise ValueError('模型样本来源重复：' + sid)
        known_samples.add(sid)
        path = (root/row['source_file']).resolve()
        path.relative_to(root.resolve())
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['source_sha256']:
            raise ValueError('模型报告哈希发生变化：' + sid)
        report = load_json(path)
        for finding in report['findings']:
            rebuilt.append({'model_finding_id':sid+'/'+finding['id'], 'sample_id':sid,
                            **{key:finding.get(key) for key in ['rule_ids','title','description','evidence','suggestion','severity']},
                            'source_file':row['source_file'], 'source_sha256':row['source_sha256']})
    if catalog != rebuilt:
        raise ValueError('模型目录与保存的原报告不一致')
    matching = load_json(root/'输入/共识/模型匹配.json')
    if matching.get('sample_sources') != sources or matching.get('model_sample_scope') != [s['sample_id'] for s in sources]:
        raise ValueError('模型匹配表的报告来源和范围需与固定目录一致；只在共识表 sample_scope 中选择本轮对照范围。')
    return catalog, sources


def build_summary(root: Path):
    root = root.resolve()
    sources = []
    for folder in ['输入','材料']:
        for path in sorted((root/folder).rglob('*')):
            if path.is_file():
                sources.append({'file':path.relative_to(root).as_posix(), 'bytes':path.stat().st_size,
                                'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    output = {'schema_version':1, 'generated_at':datetime.now().astimezone().isoformat(timespec='seconds'),
              'source_files':sources, 'errors':[]}
    for key, action in [
        ('reviews', lambda: summarize_reviews(root/'输入/独立评审', root/'材料/评审材料定义.json')),
        ('recognition', lambda: aggregate_recognition(root/'输入/识别实验', root/'输入/判分/识别判分.json')),
        ('experience', lambda: summarize_experience(root/'输入/工具体验'))]:
        try:
            output[key] = action()
        except (OSError, ValueError, TypeError, KeyError) as exc:
            output[key] = {'status':'需核对输入', 'error':str(exc)}
            output['errors'].append({'section':key, 'message':str(exc)})
    try:
        catalog, model_sources = verify_catalog(root)
        output['model_sources'] = model_sources
        output['model_findings'] = len(catalog)
        output['effect'] = summarize_effect(root/'输入/共识/共识参考.json', root/'输入/共识/模型匹配.json', catalog)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        output['effect'] = {'status':'需核对输入', 'error':str(exc)}
        output['errors'].append({'section':'effect', 'message':str(exc)})
    return output


def to_text(summary):
    lines = ['D 材料收取与汇总', '生成时间：'+summary['generated_at'], '', '一、两位评审者的独立选择']
    reviews = summary['reviews']
    for row in reviews.get('reviewers', []):
        lines.append(f"评审者 {row['reviewer_code']}：已选 {row['selected_items']}/{row['expected_items']}；已写理由 {row['reasons']}；非占位证据 {row['non_placeholder_evidence']}；具体修改项 {row['findings']}。")
    comparison = reviews.get('comparison')
    if comparison:
        for key, label in [('rules','通用判据'),('goals','目标填写项'),('all','全部条目')]:
            count = comparison[key]
            ratio = f"{100*count['agreement_ratio']:.2f}%" if count['agreement_ratio'] is not None else '待有可比较记录'
            lines.append(f"{label}：{count['agreed']}/{count['compared']} 状态相同（{ratio}）；分歧 {count['disagreed']}；缺项 {count['missing']}。")
        lines.append(f"候选条目并集：{comparison['candidate_union']}。这是原始选择对照；共同确认后的具体问题进入参考集。")
    else:
        lines.append(reviews.get('status','需核对输入'))
    effect = summary['effect']
    lines += ['', '二、共识参考与模型发现', '当前状态：'+effect['status'],
              '参考来源：'+effect.get('source_label','待记录'),
              f"已绑定 {len(summary.get('model_sources',[]))} 份模型报告，通用判据具体发现 {summary.get('model_findings',0)} 项。P01 两项目标建议单独存放。"]
    if effect.get('calculation_ready', effect.get('formal_metrics_ready')):
        for key, label in [('reference_recall','参考问题召回'),('false_positive_share','错误发现占比')]:
            value = effect[key]
            rate = f"{100*value['rate']:.2f}%" if value['rate'] is not None else value['status']
            lines.append(f"{label}：{value['numerator']}/{value['denominator']}，{rate}。")
    else:
        lines.append('收到共识参考和逐项匹配后，程序生成召回与错误发现占比。')
    recognition = summary['recognition']
    lines += ['', '三、P01 五秒识别',
              f"正式会话 {recognition.get('formal_session_count',0)}；可判分会话 {recognition.get('eligible_formal_session_count',0)}；演练会话 {recognition.get('practice_session_count',0)}。"]
    for q, row in recognition.get('questions',{}).items():
        counts = row['counts']
        lines.append(q+'：'+row['ratio_text']+f"；未判分 {counts['unscored']}；缺失 {counts['missing']}；中止 {counts['aborted']}；设备异常 {counts['device_anomaly']}；记录待补 {counts['incomplete']}。")
    for row in recognition.get('records',[]):
        if row.get('mode') == 'participant' and row.get('category') in {'aborted','device_anomaly'}:
            lines.append(f"单列会话 {row['session_id']}：{row['label']}；"+'；'.join(row['reasons'])+'。')
    experience = summary['experience']
    lines += ['', '四、工具使用与体验']
    counts = experience.get('summary',{})
    lines.append(f"演练 {counts.get('practice_sessions',0)} 次；排除 {counts.get('excluded_sessions',0)} 次；内容冲突 {counts.get('conflicting_sessions',0)} 次。")
    for item in experience.get('excluded_records',[]):
        lines.append('单列会话 '+item['record']['session_id']+'：'+'；'.join(item['record']['exclusions'])+'。')
    for condition, row in experience.get('conditions',{}).items():
        label = '纯人工' if condition == 'manual' else '工具辅助'
        timing = row['timing']
        seconds = f"{timing['mean_seconds']:.1f} 秒" if timing['mean_seconds'] is not None else '待计时记录'
        lines.append(f"{label}：{row['operators']} 人、{row['sessions']} 次；完成 {row['completed_sessions']} 次、中止 {row['aborted_sessions']} 次；平均耗时 {seconds}（计时分母 {timing['eligible_sessions']}）。")
        if row.get('host_pending_sessions'):
            lines.append(f"  主持人待补版本或节点核对：{row['host_pending_sessions']} 次；参与者评分保留，计时按记录情境汇总。")
        if timing.get('retrospective_completed_sessions'):
            lines.append(f"  使用后补填 {timing['retrospective_completed_sessions']} 次；原始按键计时保留，任务耗时分母单列处理，人数与评分计入。")
        if timing['zero_duration_completed_sessions']:
            lines.append(f"  耗时为零的完成记录 {timing['zero_duration_completed_sessions']} 次，单列核对起止时间。")
        for key, title in [('understand','理解意见'),('evidence','找到证据'),('save','修订并保存')]:
            value = row['ratings'][key]
            score = f"{value['mean']:.2f}" if value['mean'] is not None else '待评分'
            lines.append(f"  {title}：{score}；实填 {value['valid_count']}、未填 {value['missing_count']}、不适用 {value['not_applicable_count']}。")
    issues = [*summary['errors'], *reviews.get('errors',[]), *recognition.get('issues',[]),
              *recognition.get('rejected_records',[]), *experience.get('errors',[]), *experience.get('conflicts',[]),
              *[i for i in effect.get('issues',[]) if i.get('level')=='error']]
    issues.extend({'message':'识别同一会话内容冲突', 'session_id':sid} for sid in recognition.get('conflicting_sessions',[]))
    issues.extend({'message':'识别匿名编号重复', **row} for row in recognition.get('participant_duplicates',[]))
    for row in recognition.get('records',[]):
        for question in row.get('questions',[]):
            if question.get('category') in {'score_conflict','score_invalid','incomplete'}:
                issues.append({'session_id':row['session_id'], 'question_id':question['question_id'], 'message':question['reason']})
    lines += ['', '五、输入核对', f'需要处理的输入问题：{len(issues)}。']
    lines.extend(json.dumps(i, ensure_ascii=False) for i in issues)
    consensus_next = ('1. AI 模拟共识与模型逐项对照已完成，按“AI 模拟参考对照”口径用于本轮报告。'
                      if effect.get('simulation_metrics_ready') else
                      '1. 收回两位评审的补充与共同确认，把确认后的参考问题及模型逐项判定交回 D。')
    lines += ['', '下一步', consensus_next,
              '2. 完成 6–8 人识别，收取真实导出与主持人判分；收取实际工具操作计时和三项评分。',
              '3. 按“汇报与统稿”中的交接单收齐成员信息与章节，配合 B、C 保存完整模型联调。',
              '', '原始记录、判分和模型报告的来源与 SHA-256 见“汇总结果.json”；逐项状态对照见“逐项对照.json”。']
    return '\n'.join(lines)+'\n'


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description='汇总 D 评审、识别与工具体验记录')
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    target = args.output or args.root/'结果'
    target.mkdir(parents=True, exist_ok=True)
    summary = build_summary(args.root)
    write_json(target/'汇总结果.json', summary)
    comparison = summary['reviews'].get('comparison')
    write_json(target/'逐项对照.json', comparison['rows'] if comparison else [])
    (target/'当前结果.txt').write_text(to_text(summary), encoding='utf-8')
    print('已生成：'+str((target/'当前结果.txt').resolve()))
    print('四类记录的明细与来源保存在同目录“汇总结果.json”。')


if __name__ == '__main__':
    main()
