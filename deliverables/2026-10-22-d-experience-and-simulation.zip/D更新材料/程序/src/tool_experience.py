"""按条件汇总真实工具体验记录；原记录与异常均保留供核对。"""

import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from statistics import mean, median

RATINGS = ("understand", "evidence", "save")
CHECKPOINTS = ("goal", "review", "severity", "recheck")


def _text(value, label, required=False):
    if not isinstance(value, str) or (required and not value.strip()):
        raise ValueError(f"{label}须为{'非空' if required else ''}文字")


def _time(value, label):
    _text(value, label, True)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise ValueError(f"{label}须为 ISO 时间，如 2026-10-22T09:00:00+08:00") from None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{label}须带时区")
    return parsed


def _validate(record):
    if not isinstance(record, dict):
        raise ValueError("记录须为对象")
    for key in ("session_id", "operator_id", "sample_id", "task"):
        _text(record.get(key), key, True)
    for key in ("frontend_version", "backend_version"):
        _text(record.get(key, ""), key)
    if record.get("condition") not in ("manual", "assisted"):
        raise ValueError("condition 须为 manual 或 assisted")
    if record.get("completion") not in ("completed", "aborted"):
        raise ValueError("completion 须为 completed 或 aborted")
    _text(record.get("abort_reason", ""), "abort_reason", record["completion"] == "aborted")
    if type(record.get("practice", False)) is not bool:
        raise ValueError("practice 须为 true 或 false")
    exclusions = record.get("exclusions")
    if not isinstance(exclusions, list) or any(not isinstance(item, str) or not item.strip() for item in exclusions):
        raise ValueError("exclusions 须为事件文字数组，无事件时填 []")
    duration = (_time(record.get("ended_at"), "ended_at") - _time(record.get("started_at"), "started_at")).total_seconds()
    if duration < 0:
        raise ValueError("结束时间早于开始时间")
    timing_context = record.get("timing_context", "unknown")
    if timing_context not in ("realtime", "retrospective", "unknown"):
        raise ValueError("timing_context 须为 realtime、retrospective 或 unknown")
    _text(record.get("timing_note", ""), "timing_note", timing_context == "retrospective")
    ratings = record.get("ratings")
    reasons = record.get("rating_na_reasons", {})
    if not isinstance(ratings, dict) or not isinstance(reasons, dict):
        raise ValueError("ratings 与 rating_na_reasons 须为对象")
    for key in RATINGS:
        if key not in ratings:
            raise ValueError(f"ratings 缺少 {key}；未填时使用 null")
        score = ratings[key]
        if score is not None and (type(score) is not int or not 1 <= score <= 5):
            raise ValueError(f"{key} 评分须为 1–5 的整数或 null")
        reason = reasons.get(key, "")
        _text(reason, f"{key} 不适用理由")
        if score is not None and reason.strip():
            raise ValueError(f"{key} 已有评分，不适用理由应留空")
    comments = record.get("comments")
    if not isinstance(comments, dict):
        raise ValueError("comments 须为对象")
    for key in ("difficulty", "suggestion"):
        _text(comments.get(key, ""), f"comments.{key}")
    checkpoints = record.get("checkpoints")
    if not isinstance(checkpoints, dict):
        raise ValueError("checkpoints 须为对象")
    for key in CHECKPOINTS:
        check = checkpoints.get(key)
        if not isinstance(check, dict):
            raise ValueError(f"缺少 {key} 介入节点记录")
        if check.get("result") not in ("pass", "fail", "not_applicable", "pending"):
            raise ValueError(f"{key} 结果须为 pass、fail、not_applicable 或 pending")
        _text(check.get("reason", ""), f"{key} 理由", check["result"] in ("fail", "not_applicable"))
        for stage in ("before", "after", "review", "export"):
            _text(check.get(stage), f"{key}.{stage}", check["result"] == "pass")
    return duration


def _condition_summary(records):
    complete = [item for item in records if item["record"]["completion"] == "completed"]
    aborted = [item for item in records if item["record"]["completion"] == "aborted"]
    retrospective = [item for item in complete if item["record"].get("timing_context") == "retrospective"]
    timer_candidates = [item for item in complete if item["record"].get("timing_context") != "retrospective"]
    timed = [item for item in timer_candidates if item["duration_seconds"] > 0]
    durations = [item["duration_seconds"] for item in timed]
    result = {
        "sessions": len(records),
        "operators": len({item["record"]["operator_id"] for item in records}),
        "completed_sessions": len(complete),
        "completed_operators": len({item["record"]["operator_id"] for item in complete}),
        "aborted_sessions": len(aborted),
        "aborted_operators": len({item["record"]["operator_id"] for item in aborted}),
        "completion_rate": len(complete) / len(records) if records else None,
        "timing": {
            "eligible_sessions": len(timed),
            "eligible_operators": len({item["record"]["operator_id"] for item in timed}),
            "zero_duration_completed_sessions": len(timer_candidates) - len(timed),
            "retrospective_completed_sessions": len(retrospective),
            "retrospective_completed_operators": len({item["record"]["operator_id"] for item in retrospective}),
            "mean_seconds": mean(durations) if durations else None,
            "median_seconds": median(durations) if durations else None,
        },
        "ratings": {},
        "checkpoints": {},
        "host_pending_sessions": sum(any(not item['record'].get(key, '').strip() for key in ('frontend_version','backend_version'))
                                     or any(item['record']['checkpoints'][key]['result']=='pending' for key in CHECKPOINTS) for item in records),
    }
    for key in RATINGS:
        scores = [item["record"]["ratings"][key] for item in records if item["record"]["ratings"][key] is not None]
        na = sum(item["record"]["ratings"][key] is None and bool(item["record"].get("rating_na_reasons", {}).get(key, "").strip()) for item in records)
        result["ratings"][key] = {
            "valid_count": len(scores), "not_applicable_count": na,
            "missing_count": len(records) - len(scores) - na,
            "mean": mean(scores) if scores else None,
            "distribution": {str(n): scores.count(n) for n in range(1, 6)},
        }
    for key in CHECKPOINTS:
        counts = Counter(item["record"]["checkpoints"][key]["result"] for item in records)
        applicable = counts["pass"] + counts["fail"]
        result["checkpoints"][key] = {
            "pass": counts["pass"], "fail": counts["fail"],
            "not_applicable": counts["not_applicable"], "applicable_count": applicable,
            "pending": counts["pending"],
            "pass_rate": counts["pass"] / applicable if applicable else None,
        }
    return result


def summarize_experience(input_dir: Path) -> dict:
    """读取目录内 JSON；同会话冲突、演练和排除事件分别列出。"""
    input_dir = Path(input_dir)
    result = {
        "schema_version": 1, "files": [], "source_record_count": 0,
        "errors": [], "duplicates": [], "conflicts": [],
        "practice_records": [], "excluded_records": [], "valid_records": [],
        "denominators": {
            "sessions": "结构与内容有效、去重且无冲突的正式会话；exclusions 非空的会话单列排除。",
            "operators": "各条件内按 operator_id 去重；同一人跨条件参与时分别计入各条件。",
            "completion_rate": "完成会话数 / 正式有效会话数；已完成和中止人数可有重叠。",
            "timing": "实际完成且耗时大于零的会话进入计时分母；明确标注 retrospective 的补填计时单列，保留人数与评分。实时、未注明或 unknown 的记录沿用原计时口径；等待、重试与修订包含在起止时间内。",
            "ratings": "逐条件统计正式有效会话的实填分数；未填与不适用分别计数，中止会话的实填体验也保留。",
            "checkpoints": "通过数 /（通过数 + 未通过数），不适用与待补分别单列，均不进入通过率分母。",
            "comparison": "仅列各条件结果；不自动计算或推断效率提升。",
        },
    }
    grouped = defaultdict(list)
    if not input_dir.is_dir():
        result["errors"].append({"file": str(input_dir), "message": "输入目录不存在"})
    for file in sorted(input_dir.rglob("*.json")) if input_dir.is_dir() else []:
        relative = file.relative_to(input_dir).as_posix()
        result["files"].append(relative)
        try:
            payload = json.loads(file.read_text(encoding="utf-8-sig"))
            if not isinstance(payload, dict) or type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
                raise ValueError("文件须为对象，schema_version 须为整数 1")
            records = payload.get("records")
            if not isinstance(records, list):
                raise ValueError("records 须为数组；空白模板使用 []")
        except (ValueError, OSError) as exc:
            result["errors"].append({"file": relative, "message": str(exc)})
            continue
        for index, record in enumerate(records, 1):
            result["source_record_count"] += 1
            source = {"file": relative, "record_index": index}
            # 同 session_id 的全部版本先归组，包括待纠正版本，避免挑选有利版本。
            session_id = record.get("session_id") if isinstance(record, dict) else None
            if not isinstance(session_id, str) or not session_id.strip():
                result["errors"].append({**source, "message": "记录须为对象并填写非空 session_id"})
                continue
            grouped[session_id].append({"record": record, "source": source})
    for session_id, copies in sorted(grouped.items()):
        versions = defaultdict(list)
        for item in copies:
            versions[json.dumps(item["record"], ensure_ascii=False, sort_keys=True)].append(item)
        if len(versions) > 1:
            result["conflicts"].append({"session_id": session_id, "sources": [item["source"] for item in copies], "message": "同会话存在不同内容，整组等待确认后再计入", "versions": [items[0]["record"] for items in versions.values()]})
            continue
        first = copies[0]
        if len(copies) > 1:
            result["duplicates"].append({"session_id": session_id, "retained": first["source"], "ignored": [item["source"] for item in copies[1:]]})
        try:
            duration = _validate(first["record"])
        except ValueError as exc:
            result["errors"].append({**first["source"], "session_id": session_id, "message": str(exc)})
            continue
        item = {**first, "sources": [copy["source"] for copy in copies], "duration_seconds": duration}
        if item["record"].get("practice", False):
            result["practice_records"].append(item)
        elif item["record"]["exclusions"]:
            result["excluded_records"].append(item)
        else:
            result["valid_records"].append(item)
    result["conditions"] = {condition: _condition_summary([item for item in result["valid_records"] if item["record"]["condition"] == condition]) for condition in ("manual", "assisted")}
    result["has_anomalies"] = bool(result["errors"] or result["conflicts"])
    result["summary"] = {
        "valid_sessions": len(result["valid_records"]), "practice_sessions": len(result["practice_records"]),
        "excluded_sessions": len(result["excluded_records"]), "conflicting_sessions": len(result["conflicts"]),
        "error_count": len(result["errors"]), "duplicate_records": sum(len(item["ignored"]) for item in result["duplicates"]),
    }
    return result
