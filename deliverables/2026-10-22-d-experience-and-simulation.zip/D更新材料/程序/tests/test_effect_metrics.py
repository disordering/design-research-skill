"""共识指标的合成边界测试；测试记录不作为真人研究数据。"""

import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from effect_metrics import summarize_effect


class EffectMetricsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)
        self.catalog = [self.model("S07/F001"), self.model("S07/F003")]
        self.reference = {
            "protocol_version": "D v1.1", "finalized": True,
            "reviewers": ["1", "2"], "confirmed_by": ["2", "1"],
            "finalized_at": "2026-10-22T10:00:00+08:00",
            "sample_scope": ["S07"], "independent_files": ["评审1.json", "评审2.json"],
            "records": [self.ref("S07/H01", "提醒开关"), self.ref("S07/H02", "主题选项")],
        }
        self.matching = {
            "model_sample_scope": ["S07"],
            "sample_sources": [self.source("S07")],
            "records": [self.match("S07/F001", "S07/H01"), self.match("S07/F003", "S07/H02")],
        }

    @staticmethod
    def source(sid):
        return {"sample_id": sid, "source_file": sid + "/report.json", "source_sha256": "a" * 64}

    def model(self, mid):
        sid = mid.split("/")[0]
        return {"model_finding_id": mid, **self.source(sid), "rule_ids": ["R17"], "title": mid}

    @staticmethod
    def ref(rid, location):
        return {"reference_id": rid, "sample_id": rid.split("/")[0], "rule_ids": ["R17"],
                "location": location, "phenomenon": "缺少选中状态", "evidence": "控件旁没有选中标志",
                "decision": "candidate_issue", "resolution_reason": "两位共同确认对应的具体区域"}

    @staticmethod
    def match(mid, rid=None, state="confirmed_match"):
        return {"model_finding_id": mid, "status": state, "reference_ids": [rid] if rid else [],
                "reason": "已核对截图位置、具体表现和修改动作", "confirmed_by": ["1", "2"]}

    def run_case(self):
        a, b = self.path / "共识.json", self.path / "匹配.json"
        a.write_text(json.dumps(self.reference, ensure_ascii=False), encoding="utf-8-sig")
        b.write_text(json.dumps(self.matching, ensure_ascii=False), encoding="utf-8")
        return summarize_effect(a, b, self.catalog)

    def assert_issue(self, result, code):
        self.assertIn(code, {i["code"] for i in result["issues"]})
        self.assertFalse(result["formal_metrics_ready"])
        self.assertIsNone(result["reference_recall"]["rate"])
        self.assertIsNone(result["false_positive_share"]["rate"])

    def test_same_rule_different_locations_remain_two_findings(self):
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertEqual(result["reference_recall"]["denominator"], 2)
        self.assertEqual(result["reference_recall"]["rate"], 1)
        self.assertEqual(result["false_positive_share"]["rate"], 0)
        self.assertEqual(len(result["sources"]), 2)

    def test_ai_simulation_is_explicit_and_not_human_metric(self):
        self.reference['source_type'] = 'ai_simulation'
        got = self.run_case()
        self.assertTrue(got['calculation_ready'])
        self.assertTrue(got['simulation_metrics_ready'])
        self.assertFalse(got['formal_metrics_ready'])
        self.assertEqual(got['source_label'], 'AI 模拟共识')
        self.assertEqual(got['reference_recall']['rate'], 1)

    def test_unrecognized_reference_source_blocks_calculation(self):
        self.reference['source_type'] = 'unknown'
        self.assert_issue(self.run_case(), 'invalid_source_type')

    def test_one_model_covers_two_references_only_with_each_link_evidence(self):
        self.catalog = self.catalog[:1]
        row = self.matching['records'][0]
        row['reference_ids'] = ['S07/H01','S07/H02']
        row['reference_link_evidence'] = [
            {'reference_id':'S07/H01','reason':'合成报告明确描述提醒开关缺失状态'},
            {'reference_id':'S07/H02','reason':'同一合成报告还明确描述主题缺失状态'}]
        self.matching['records'] = [row]
        got = self.run_case()
        self.assertTrue(got['calculation_ready'], got['issues'])
        self.assertEqual(got['reference_recall']['numerator'], 2)
        self.assertEqual(got['false_positive_share']['denominator'], 1)

    def test_missing_reference_is_not_zero_accuracy(self):
        result = summarize_effect(None, None, self.catalog)
        self.assert_issue(result, "missing_reference")

    def test_unfinalized_reference_is_not_formal(self):
        self.reference["finalized"] = False
        self.assert_issue(self.run_case(), "reference_not_finalized")

    def test_false_positive_does_not_cover_reference(self):
        self.matching["records"][1] = self.match("S07/F003", state="false_positive")
        result = self.run_case()
        self.assertEqual(result["reference_recall"]["rate"], 0.5)
        self.assertEqual(result["false_positive_share"]["rate"], 0.5)
        self.assertEqual(result["samples"][0]["unmatched_reference_ids"], ["S07/H02"])

    def test_valid_new_finding_is_not_false_positive_or_new_reference(self):
        self.matching["records"][1] = self.match("S07/F003", state="valid_new_finding")
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertEqual(result["reference_recall"]["rate"], 0.5)
        self.assertEqual(result["false_positive_share"]["denominator"], 2)
        self.assertEqual(result["false_positive_share"]["rate"], 0)
        self.assertEqual(result["counts"]["valid_new_finding_count"], 1)

    def test_unresolved_prevents_partial_denominator(self):
        self.matching["records"][1] = self.match("S07/F003", state="unresolved")
        result = self.run_case()
        self.assert_issue(result, "unresolved_mappings")
        self.assertEqual(result["counts"]["judged_model_finding_count"], 1)
        self.assertEqual(result["false_positive_share"]["denominator"], 2)

    def test_missing_match_record_prevents_rate(self):
        self.matching["records"].pop()
        result = self.run_case()
        self.assert_issue(result, "missing_mappings")
        self.assertEqual(result["samples"][0]["missing_mapping_ids"], ["S07/F003"])

    def test_zero_model_findings_still_counts_human_misses(self):
        self.catalog = []
        self.matching["records"] = []
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertEqual(result["reference_recall"]["rate"], 0)
        self.assertIsNone(result["false_positive_share"]["rate"])
        self.assertEqual(result["false_positive_share"]["status"], "不适用：分母为零")

    def test_empty_reference_set_recall_is_not_applicable(self):
        self.reference["records"] = []
        self.matching["records"] = [self.match(row["model_finding_id"], state="false_positive") for row in self.catalog]
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertIsNone(result["reference_recall"]["rate"])
        self.assertEqual(result["false_positive_share"]["rate"], 1)

    def test_zero_finding_sample_requires_source(self):
        self.reference["sample_scope"].append("S09")
        self.matching["model_sample_scope"].append("S09")
        self.assert_issue(self.run_case(), "missing_sample_source")

    def test_zero_finding_sample_included_with_source(self):
        self.reference["sample_scope"].append("S09")
        self.matching["model_sample_scope"].append("S09")
        self.matching["sample_sources"].append(self.source("S09"))
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        row = result["samples"][1]
        self.assertEqual(row["sample_id"], "S09")
        self.assertTrue(row["model_report_present"])
        self.assertEqual(row["model_finding_count"], 0)

    def test_partial_sample_scope_is_reported_and_respected(self):
        self.matching["model_sample_scope"].append("S01")
        self.matching["sample_sources"].append(self.source("S01"))
        self.catalog.append(self.model("S01/F001"))
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertEqual(result["samples_outside_reference_scope"], ["S01"])
        self.assertEqual(result["false_positive_share"]["denominator"], 2)

    def test_repeated_model_id_rejected(self):
        self.catalog.append(copy.deepcopy(self.catalog[0]))
        self.assert_issue(self.run_case(), "duplicate_model_id")

    def test_repeated_reference_id_rejected(self):
        self.reference["records"].append(copy.deepcopy(self.reference["records"][0]))
        self.assert_issue(self.run_case(), "duplicate_reference_id")

    def test_repeated_matching_record_rejected_even_if_identical(self):
        self.matching["records"].append(copy.deepcopy(self.matching["records"][0]))
        self.assert_issue(self.run_case(), "duplicate_matching_id")

    def test_two_models_cannot_double_count_same_reference(self):
        self.matching["records"][1]["reference_ids"] = ["S07/H01"]
        result = self.run_case()
        self.assert_issue(result, "duplicate_reference_match")
        self.assertEqual(result["counts"]["matched_reference_count"], 1)

    def test_one_model_requires_unified_problem_unit(self):
        self.matching["records"][0]["reference_ids"] = ["S07/H01", "S07/H02"]
        self.assert_issue(self.run_case(), "match_unit_conflict")

    def test_cross_sample_links_rejected(self):
        self.reference["sample_scope"].append("S01")
        self.reference["records"][1]["sample_id"] = "S01"
        self.matching["model_sample_scope"].append("S01")
        self.matching["sample_sources"].append(self.source("S01"))
        self.assert_issue(self.run_case(), "cross_sample_match")

    def test_rule_identity_alone_does_not_create_match(self):
        self.matching["records"] = []
        result = self.run_case()
        self.assertEqual(result["counts"]["matched_reference_count"], 0)
        self.assert_issue(result, "missing_mappings")

    def test_unknown_reference_and_model_rejected(self):
        self.matching["records"][0]["reference_ids"] = ["S07/H99"]
        self.matching["records"].append(self.match("S07/F999", "S07/H02"))
        result = self.run_case()
        self.assert_issue(result, "unknown_reference_id")
        self.assert_issue(result, "unknown_model_id")

    def test_non_candidate_reference_cannot_match(self):
        self.reference["records"][0]["decision"] = "not_applicable"
        self.assert_issue(self.run_case(), "unknown_reference_id")

    def test_p01_goal_does_not_enter_general_rule_metrics(self):
        self.reference["records"][0]["rule_ids"] = ["G04"]
        self.assert_issue(self.run_case(), "invalid_reference_rules")

    def test_goal_model_finding_does_not_enter_general_catalog(self):
        self.catalog[0]["rule_ids"] = ["G04"]
        self.assert_issue(self.run_case(), "invalid_model_rules")

    def test_complete_zero_sets_are_not_zero_percent(self):
        self.catalog = []
        self.reference["records"] = []
        self.matching["records"] = []
        result = self.run_case()
        self.assertTrue(result["formal_metrics_ready"], result["issues"])
        self.assertIsNone(result["reference_recall"]["rate"])
        self.assertIsNone(result["false_positive_share"]["rate"])

    def test_missing_model_sample_is_explicit(self):
        self.reference["sample_scope"].append("S10")
        self.assert_issue(self.run_case(), "model_sample_missing")

    def test_finalized_set_requires_two_reviewers(self):
        self.reference["reviewers"] = ["1", "1"]
        self.assert_issue(self.run_case(), "invalid_reviewers")

    def test_match_requires_confirmed_reason(self):
        self.matching["records"][0]["confirmed_by"] = ["1"]
        self.matching["records"][0]["reason"] = "暂无"
        result = self.run_case()
        self.assert_issue(result, "matching_confirmation_missing")
        self.assert_issue(result, "matching_reason_missing")

    def test_finalized_reference_requires_actual_details(self):
        self.reference["records"][0]["evidence"] = "暂无"
        self.assert_issue(self.run_case(), "reference_detail_missing")

    def test_model_source_hash_mismatch_rejected(self):
        self.catalog[0]["source_sha256"] = "b" * 64
        self.assert_issue(self.run_case(), "catalog_source_mismatch")

    def test_malformed_types_return_issues(self):
        self.reference["records"][0]["decision"] = []
        self.matching["records"][0]["status"] = {}
        self.catalog[0]["source_sha256"] = []
        result = self.run_case()
        self.assert_issue(result, "invalid_reference_decision")
        self.assert_issue(result, "invalid_matching_status")

    def test_bad_json_is_reported(self):
        a = self.path / "invalid.json"
        a.write_text("{oops", encoding="utf-8")
        result = summarize_effect(a, None, [])
        self.assert_issue(result, "invalid_reference")

    def test_input_objects_are_not_modified(self):
        before = copy.deepcopy(self.catalog)
        self.run_case()
        self.assertEqual(self.catalog, before)


if __name__ == "__main__":
    unittest.main()
