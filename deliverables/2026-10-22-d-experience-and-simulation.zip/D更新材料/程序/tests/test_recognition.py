"""在临时目录检查真实导出格式；测试样本不进入正式收件目录。"""

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


MODULE_PATH = Path(__file__).resolve().parents[1] / "src" / "recognition.py"
SPEC = importlib.util.spec_from_file_location("recognition", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
aggregate_recognition = MODULE.aggregate_recognition


def make_record(participant="U01", session="session-1", mode="participant", answers=None):
    """字段取自现有识别页，测试原话仅用于程序验证。"""
    texts = answers if answers is not None else ["角色试用", "右下方", "开始试用"]
    return {
        "schema_version": "1.0", "study_id": MODULE.STUDY_ID, "session_id": session,
        "mode": mode, "participant_id": participant, "experience": "中轻度手游玩家",
        "prior_exposure": "no", "consent": True, "started_at": "2026-10-22T01:00:00.000Z",
        "image": "P01", "image_sha256": MODULE.IMAGE_SHA256, "planned_exposure_ms": 5000,
        "device": {"viewport_width": 1440, "viewport_height": 900, "screen_width": 1920,
                   "screen_height": 1080, "device_pixel_ratio": 1, "visual_viewport_scale": 1},
        "events": [], "answers": {f"q{i + 1}": {"text": text, "response_status": "answered" if text else "missing"}
                                  for i, text in enumerate(texts)},
        "status": "completed", "exposure_start_at": "2026-10-22T01:00:03.000Z",
        "exposure_rect": {"x": 0, "y": 0, "width": 1440, "height": 900},
        "exposure_end_at": "2026-10-22T01:00:08.000Z", "browser_exposure_ms": 5008,
        "answer_started_at": "2026-10-22T01:00:08.000Z", "ended_at": "2026-10-22T01:00:30.000Z",
        "exposure_quality": "按计划完成",
    }


def score_row(record, question, label="正确", **changes):
    value = {"session_id": record["session_id"], "participant_id": record["participant_id"],
             "question_id": question, "original_answer": record["answers"][question.lower()]["text"],
             "label": label, "scorer": "主持人甲", "reason": "依据固定判分表核对原话"}
    value.update(changes)
    return value


class RecognitionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.inputs = self.root / "正式收件"
        self.inputs.mkdir()
        self.scores = self.root / "主持人判分.json"

    def tearDown(self):
        self.temp.cleanup()

    def export(self, records, name="正式识别记录.json", mode="participant", **changes):
        data = {"study_id": MODULE.STUDY_ID, "exported_at": "2026-10-22T02:00:00.000Z",
                "record_type": mode, "record_count": len(records), "records": records}
        data.update(changes)
        path = self.inputs / name
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def set_scores(self, rows):
        self.scores.write_text(json.dumps({"study_id": MODULE.STUDY_ID, "scored_records": rows}, ensure_ascii=False), encoding="utf-8")

    def aggregate(self, scores=False):
        return aggregate_recognition(self.inputs, self.scores if scores else None)

    def test_empty_is_pending_not_zero_percent(self):
        result = self.aggregate()
        self.assertEqual(result["status"], "尚待记录")
        self.assertEqual(result["formal_session_count"], 0)
        self.assertIsNone(result["questions"]["Q1"]["correct_ratio"])
        self.assertNotIn("0%", result["questions"]["Q1"]["ratio_text"])

    def test_exact_export_preserves_answers_and_does_not_auto_score(self):
        record = make_record()
        path = self.export([record])
        result = self.aggregate()
        self.assertEqual(result["eligible_formal_session_count"], 1)
        self.assertEqual(result["questions"]["Q1"]["counts"]["unscored"], 1)
        self.assertEqual(result["records"][0]["record"], record)
        self.assertEqual(result["records"][0]["sources"][0]["path"], str(path.resolve()))

    def test_real_zero_differs_from_blank_score(self):
        a, b = make_record(), make_record("U02", "session-2")
        self.export([a, b])
        self.set_scores([score_row(a, "Q1", "错误"), score_row(b, "Q1", "", scorer="", reason="")])
        q = self.aggregate(True)["questions"]["Q1"]
        self.assertEqual(q["counts"]["incorrect"], 1)
        self.assertEqual(q["counts"]["unscored"], 1)
        self.assertEqual(q["valid_denominator"], 1)
        self.assertEqual(q["correct_ratio"], 0.0)
        self.assertEqual(q["ratio_text"], "0/1（0.0%）")

    def test_correct_and_incorrect_only_form_denominator(self):
        a, b, c, d = (make_record(f"U{i}", f"session-{i}") for i in range(1, 5))
        c["answers"]["q1"] = {"text": "", "response_status": "missing"}
        self.export([a, b, c, d])
        self.set_scores([score_row(a, "Q1"), score_row(b, "Q1", "错误")])
        result = self.aggregate(True)
        q = result["questions"]["Q1"]
        self.assertEqual(q["correct_ratio"], 0.5)
        self.assertEqual(q["valid_denominator"], 2)
        self.assertEqual(q["counts"]["missing"], 1)
        self.assertEqual(q["counts"]["unscored"], 1)
        self.assertEqual(result["questions"]["Q2"]["counts"]["unscored"], 4)

    def test_practice_never_enters_formal_denominator(self):
        record = make_record(mode="practice")
        self.export([record], mode="practice")
        self.set_scores([score_row(record, "Q1")])
        result = self.aggregate(True)
        self.assertEqual(result["practice_session_count"], 1)
        self.assertEqual(result["formal_session_count"], 0)
        self.assertEqual(result["questions"]["Q1"]["valid_denominator"], 0)
        self.assertEqual(result["status"], "尚待记录")

    def test_cumulative_exports_deduplicate_session_and_keep_both_sources(self):
        a, b = make_record(), make_record("U02", "session-2")
        self.export([a], "第一次.json")
        self.export([a, b], "第二次.json", exported_at="2026-10-22T03:00:00.000Z")
        result = self.aggregate()
        self.assertEqual(result["formal_session_count"], 2)
        self.assertEqual(result["duplicate_exports"][0]["duplicate_copies_removed"], 1)
        self.assertEqual(len(result["records"][0]["sources"]), 2)
        self.assertEqual(result["participant_duplicates"], [])

    def test_session_conflict_is_not_resolved_by_latest_export(self):
        a = make_record()
        b = copy.deepcopy(a)
        b["answers"]["q1"]["text"] = "领礼包"
        self.export([a], "一.json")
        self.export([b], "二.json")
        self.set_scores([score_row(a, "Q1")])
        result = self.aggregate(True)
        self.assertEqual(result["conflicting_sessions"], ["session-1"])
        self.assertEqual(result["questions"]["Q1"]["counts"]["record_conflict"], 1)
        self.assertEqual(result["questions"]["Q1"]["valid_denominator"], 0)
        self.assertEqual(len(result["records"][0]["conflicting_versions"]), 2)

    def test_repeated_participant_sessions_are_listed_for_confirmation(self):
        a, b = make_record(), make_record(session="session-2")
        self.export([a, b])
        self.set_scores([score_row(a, "Q1"), score_row(b, "Q1")])
        result = self.aggregate(True)
        self.assertEqual(result["formal_participant_id_count"], 1)
        self.assertEqual(result["participant_duplicates"][0]["participant_id"], "U01")
        self.assertEqual(result["questions"]["Q1"]["counts"]["participant_duplicate"], 2)
        self.assertEqual(result["questions"]["Q1"]["valid_denominator"], 0)

    def test_aborted_and_exposure_events_excluded_even_with_correct_scores(self):
        a, b = make_record(), make_record("U02", "session-2")
        a.update(status="aborted", exposure_quality="中止", browser_exposure_ms=1500)
        b["events"] = [{"type": "hidden", "phase": "exposure", "elapsed_ms": 1000}]
        self.export([a, b])
        self.set_scores([score_row(a, "Q1"), score_row(b, "Q1")])
        q = self.aggregate(True)["questions"]["Q1"]
        self.assertEqual(q["counts"]["aborted"], 1)
        self.assertEqual(q["counts"]["device_anomaly"], 1)
        self.assertEqual(q["valid_denominator"], 0)

    def test_window_event_during_answers_does_not_change_exposure(self):
        record = make_record()
        record["events"] = [{"type": "blur", "phase": "answer", "elapsed_ms": 8000}]
        self.export([record])
        self.assertEqual(self.aggregate()["eligible_formal_session_count"], 1)

    def test_missing_answer_field_and_blank_answer_are_different(self):
        record = make_record(answers=["", "", "开始试用"])
        del record["answers"]["q2"]
        self.export([record])
        result = self.aggregate()
        self.assertEqual(result["questions"]["Q1"]["counts"]["missing"], 1)
        self.assertEqual(result["questions"]["Q2"]["counts"]["incomplete"], 1)
        self.assertEqual(result["questions"]["Q3"]["counts"]["unscored"], 1)

    def test_scoring_keeps_exact_original_and_conflict(self):
        record = make_record()
        self.export([record])
        self.set_scores([score_row(record, "Q1", original_answer="原话被改写"),
                         score_row(record, "Q2"), score_row(record, "Q2", "错误")])
        result = self.aggregate(True)
        self.assertEqual(result["questions"]["Q1"]["counts"]["score_invalid"], 1)
        self.assertEqual(result["questions"]["Q2"]["counts"]["score_conflict"], 1)

    def test_identical_duplicate_scores_count_once(self):
        record = make_record()
        self.export([record])
        row = score_row(record, "Q1")
        self.set_scores([row, row])
        result = self.aggregate(True)
        self.assertEqual(result["questions"]["Q1"]["valid_denominator"], 1)
        self.assertEqual(len(result["records"][0]["questions"][0]["score_sources"]), 2)

    def test_numeric_zero_is_invalid_label_not_missing(self):
        record = make_record()
        self.export([record])
        self.set_scores([score_row(record, "Q1", 0)])
        self.assertEqual(self.aggregate(True)["questions"]["Q1"]["counts"]["score_invalid"], 1)

    def test_scores_require_identity_scorer_reason_and_compatible_missing(self):
        record = make_record(answers=["", "右下方", "开始试用"])
        self.export([record])
        self.set_scores([score_row(record, "Q1", "正确"), score_row(record, "Q2", "缺失"),
                         score_row(record, "Q3", scorer="")])
        result = self.aggregate(True)
        for question in MODULE.QUESTIONS:
            self.assertEqual(result["questions"][question]["counts"]["score_invalid"], 1)

    def test_host_may_mark_question_device_anomaly(self):
        record = make_record()
        self.export([record])
        self.set_scores([score_row(record, "Q1", "设备异常"), score_row(record, "Q2")])
        result = self.aggregate(True)
        self.assertEqual(result["questions"]["Q1"]["counts"]["device_anomaly"], 1)
        self.assertEqual(result["questions"]["Q1"]["valid_denominator"], 0)
        self.assertEqual(result["questions"]["Q2"]["valid_denominator"], 1)

    def test_plan_identity_and_exposure_fields_are_checked(self):
        variations = [
            {"image_sha256": "另一张图"}, {"planned_exposure_ms": 3000},
            {"prior_exposure": "yes"}, {"consent": False}, {"experience": "其他"},
            {"browser_exposure_ms": None}, {"status": "in_progress"},
        ]
        for changes in variations:
            with self.subTest(changes=changes):
                record = make_record()
                record.update(changes)
                self.export([record])
                self.assertEqual(self.aggregate()["questions"]["Q1"]["counts"]["incomplete"], 1)
        record = make_record()
        record["browser_exposure_ms"] = 1000
        self.export([record])
        self.assertEqual(self.aggregate()["questions"]["Q1"]["counts"]["device_anomaly"], 1)

    def test_broken_input_and_unmatched_scores_are_reported(self):
        (self.inputs / "坏文件.json").write_text("{", encoding="utf-8")
        self.export([{"participant_id": "U01"}], "无会话.json")
        self.set_scores([score_row(make_record(), "Q1")])
        result = self.aggregate(True)
        self.assertEqual(len(result["rejected_records"]), 1)
        self.assertIn("input_file", [item["type"] for item in result["issues"]])
        self.assertIn("orphan_score", [item["type"] for item in result["issues"]])
        self.assertEqual(result["formal_session_count"], 0)
        self.assertEqual(result["status"], "待核对记录")

    def test_broken_window_event_is_not_silently_ignored(self):
        record = make_record()
        record["events"] = ["窗口事件格式损坏"]
        self.export([record])
        self.assertEqual(self.aggregate()["questions"]["Q1"]["counts"]["incomplete"], 1)

    def test_blank_template_and_frozen_original_score_table_are_accepted(self):
        paths = [MODULE_PATH.parents[1] / "templates" / "识别判分_空白.json",
                 MODULE_PATH.parents[1] / "templates" / "既有主持人判分表.json"]
        for path in paths:
            with self.subTest(path=path):
                result = aggregate_recognition(self.inputs, path)
                self.assertEqual(result["issues"], [])
                self.assertEqual(result["status"], "尚待记录")

    def test_container_mode_mismatch_and_unknown_type_do_not_count(self):
        record = make_record()
        self.export([record], mode="practice")
        result = self.aggregate()
        self.assertEqual(result["eligible_formal_session_count"], 0)
        self.assertEqual(result["questions"]["Q1"]["counts"]["incomplete"], 1)
        record["mode"] = []
        self.export([record], mode="practice")
        result = self.aggregate()
        self.assertEqual(result["formal_session_count"], 0)
        self.assertEqual(result["unclassified_session_count"], 1)

    def test_score_file_inside_input_directory_is_not_imported_as_export(self):
        record = make_record()
        self.export([record])
        self.scores = self.inputs / "判分.json"
        self.set_scores([score_row(record, "Q1")])
        result = self.aggregate(True)
        self.assertEqual(len(result["files"]), 1)
        self.assertEqual(result["issues"], [])


if __name__ == "__main__":
    unittest.main()
