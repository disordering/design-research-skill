"""合成小样本用于测试导入边界，不作为真人实验记录。"""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from reviews import summarize_reviews


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.inputs = self.root/'inputs'
        self.inputs.mkdir()
        self.materials = self.root/'data.json'
        self.materials.write_text(json.dumps({'version':'test', 'samples':[{'id':'S01'}], 'rules':[{'id':'R01'},{'id':'R02'}], 'goals':[]}), encoding='utf-8')
        self.state = {'schemaVersion':1, 'materialVersion':'test', 'reviewer':{'code':'1'}, 'reviews':{'S01':{'judgments':{'R01':{'decision':'candidate_issue','reason':'','evidence':'暂无'}, 'R02':{'decision':'not_applicable','reason':'没有对象'}}, 'findings':[]}}}

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, state):
        (self.inputs/name).write_text(json.dumps(state), encoding='utf-8')

    def run_summary(self):
        return summarize_reviews(self.inputs, self.materials)

    def pair(self):
        self.write('a.json', self.state)
        other = copy.deepcopy(self.state)
        other['reviewer']['code'] = '2'
        return other

    def test_choices_do_not_imply_complete_findings(self):
        self.write('b.json', self.pair())
        got = self.run_summary()
        self.assertEqual(got['comparison']['all']['agreed'], 2)
        self.assertEqual(got['reviewers'][0]['recorded_complete_items'], 1)
        self.assertEqual(got['reviewers'][0]['non_placeholder_evidence'], 0)

    def test_missing_is_not_agreement(self):
        other = self.pair()
        del other['reviews']['S01']['judgments']['R02']
        self.write('b.json', other)
        got = self.run_summary()['comparison']['all']
        self.assertEqual((got['compared'], got['missing'], got['agreed']), (1,1,1))

    def test_changed_export_time_is_duplicate(self):
        self.write('a.json', self.state)
        state = copy.deepcopy(self.state)
        state['updatedAt'] = '2026-10-22'
        self.write('b.json', state)
        got = self.run_summary()
        self.assertEqual(len(got['reviewers']), 1)
        self.assertEqual(len(got['duplicate_exports']), 1)

    def test_conflicting_reviewer_does_not_choose_latest(self):
        self.write('a.json', self.state)
        state = copy.deepcopy(self.state)
        state['reviews']['S01']['judgments']['R01']['decision'] = 'not_applicable'
        self.write('b.json', state)
        got = self.run_summary()
        self.assertTrue(got['errors'])
        self.assertIsNone(got['comparison'])

    def test_wrong_material_blocks_comparison(self):
        state = self.pair()
        state['materialVersion'] = 'other'
        self.write('b.json', state)
        self.assertTrue(self.run_summary()['errors'])

    def test_unknown_item_blocks_comparison(self):
        state = self.pair()
        state['reviews']['S01']['judgments']['R99'] = {'decision':'not_applicable'}
        self.write('b.json', state)
        self.assertTrue(self.run_summary()['errors'])

    def test_empty_pair_has_no_rate(self):
        for row in self.state['reviews']['S01']['judgments'].values():
            row['decision'] = ''
        self.write('b.json', self.pair())
        self.assertIsNone(self.run_summary()['comparison']['all']['agreement_ratio'])

    def test_duplicate_json_keys_rejected(self):
        (self.inputs/'bad.json').write_text('{"reviews":{},"reviews":{}}', encoding='utf-8')
        self.assertTrue(self.run_summary()['errors'])

    def test_boolean_schema_rejected(self):
        self.state['schemaVersion'] = True
        self.write('bad.json', self.state)
        self.assertTrue(self.run_summary()['errors'])

    def test_json_directory_is_not_a_record(self):
        (self.inputs/'folder.json').mkdir()
        self.write('b.json', self.pair())
        self.assertEqual(self.run_summary()['comparison']['all']['compared'], 2)

    def test_invalid_finding_number_rejected(self):
        self.state['reviews']['S01']['findings'] = [{'id':'错误编号', 'relatedIds':['R01'],
            'location':'测试位置','phenomenon':'合成现象','impact':'测试影响','suggestion':'合成建议','severity':'中'}]
        self.write('bad.json', self.state)
        self.assertTrue(self.run_summary()['errors'])


if __name__ == '__main__':
    unittest.main()
