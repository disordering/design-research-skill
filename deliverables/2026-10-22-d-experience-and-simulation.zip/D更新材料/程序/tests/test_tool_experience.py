"""工具体验汇总的边界、分母与原稿保护检查。"""

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from tool_experience import summarize_experience


def record(session="T01", operator="U01", **updates):
    value = {
        "session_id": session, "operator_id": operator, "condition": "assisted", "practice": False,
        "frontend_version": "测试前端", "backend_version": "测试后端", "sample_id": "S07", "task": "测试任务",
        "started_at": "2026-10-22T09:00:00+08:00", "ended_at": "2026-10-22T09:01:00+08:00",
        "completion": "completed", "abort_reason": "", "exclusions": [],
        "ratings": {"understand": 4, "evidence": None, "save": None},
        "rating_na_reasons": {"understand": "", "evidence": "", "save": "本任务无需修订"},
        "comments": {"difficulty": "测试原话", "suggestion": ""},
        "checkpoints": {key: {"before": "原值", "after": "新值", "review": "复审值", "export": "导出值", "result": "pass", "reason": ""} for key in ("goal", "review", "severity", "recheck")},
    }
    value.update(updates)
    return value


class ToolExperienceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, records, name="data.json", **updates):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"schema_version": 1, "records": records, **updates}, ensure_ascii=False), encoding="utf-8")
        return path

    def test_participant_ratings_survive_pending_host_checks(self):
        item = record(frontend_version='', backend_version='')
        for checkpoint in item['checkpoints'].values():
            checkpoint.update(result='pending', before='', after='', review='', export='', reason='')
        self.write([item])
        got = summarize_experience(self.folder)
        self.assertFalse(got['errors'])
        condition = got['conditions']['assisted']
        self.assertEqual(condition['ratings']['understand']['mean'], 4)
        self.assertEqual(condition['timing']['mean_seconds'], 60)
        self.assertEqual(condition['host_pending_sessions'], 1)
        self.assertEqual(condition['checkpoints']['goal']['pending'], 1)
        self.assertIsNone(condition['checkpoints']['goal']['pass_rate'])

    def test_retrospective_timing_preserves_ratings_people_and_raw_timestamps(self):
        item = record(timing_context='retrospective', timing_note='已使用软件后补填',
                      ended_at='2026-10-22T09:00:01+08:00')
        source = self.write([item])
        before = source.read_bytes()
        got = summarize_experience(self.folder)
        summary = got['conditions']['assisted']
        self.assertEqual((summary['sessions'], summary['operators'], summary['completed_sessions']), (1, 1, 1))
        self.assertEqual(summary['ratings']['understand']['mean'], 4)
        self.assertEqual(summary['timing']['retrospective_completed_sessions'], 1)
        self.assertEqual(summary['timing']['eligible_sessions'], 0)
        self.assertIsNone(summary['timing']['mean_seconds'])
        self.assertEqual(got['valid_records'][0]['duration_seconds'], 1)
        self.assertEqual(got['valid_records'][0]['record']['ended_at'], item['ended_at'])
        self.assertEqual(source.read_bytes(), before)

    def test_mixed_realtime_and_retrospective_use_separate_denominators(self):
        self.write([record(timing_context='realtime'),
                    record('T02', 'U02', ended_at='2026-10-22T09:03:00+08:00'),
                    record('T03', 'U03', timing_context='retrospective', timing_note='使用后补填',
                           ended_at='2026-10-22T09:00:01+08:00')])
        summary = summarize_experience(self.folder)['conditions']['assisted']
        self.assertEqual((summary['sessions'], summary['operators']), (3, 3))
        self.assertEqual(summary['ratings']['understand']['valid_count'], 3)
        self.assertEqual(summary['timing']['eligible_sessions'], 2)
        self.assertEqual(summary['timing']['eligible_operators'], 2)
        self.assertEqual(summary['timing']['mean_seconds'], 120)
        self.assertEqual(summary['timing']['median_seconds'], 120)
        self.assertEqual(summary['timing']['retrospective_completed_sessions'], 1)

    def test_missing_and_explicit_unknown_timing_keep_existing_behavior(self):
        self.write([record(), record('T02', 'U02', timing_context='unknown')])
        summary = summarize_experience(self.folder)['conditions']['assisted']
        self.assertEqual(summary['timing']['eligible_sessions'], 2)
        self.assertEqual(summary['timing']['mean_seconds'], 60)

    def test_zero_retrospective_and_aborted_are_separate_categories(self):
        self.write([record(ended_at='2026-10-22T09:00:00+08:00'),
                    record('T02', timing_context='retrospective', timing_note='完成后补填',
                           ended_at='2026-10-22T09:00:00+08:00'),
                    record('T03', completion='aborted', abort_reason='退出',
                           timing_context='retrospective', timing_note='退出后补填')])
        summary = summarize_experience(self.folder)['conditions']['assisted']
        self.assertEqual(summary['timing']['zero_duration_completed_sessions'], 1)
        self.assertEqual(summary['timing']['retrospective_completed_sessions'], 1)
        self.assertEqual(summary['aborted_sessions'], 1)
        self.assertEqual(summary['ratings']['understand']['valid_count'], 3)

    def test_retrospective_requires_recorded_reason(self):
        self.write([record(timing_context='retrospective', timing_note='')])
        got = summarize_experience(self.folder)
        self.assertEqual(got['summary']['error_count'], 1)
        self.assertIn('timing_note', got['errors'][0]['message'])

    def test_unknown_timing_context_value_is_rejected(self):
        self.write([record(timing_context='manual-estimate')])
        got = summarize_experience(self.folder)
        self.assertEqual(got['summary']['error_count'], 1)
        self.assertIn('timing_context', got['errors'][0]['message'])

    def test_empty_template_has_no_participants_or_zero_rates(self):
        template = Path(__file__).resolve().parents[1] / "templates" / "工具体验_空白.json"
        (self.folder / "template.json").write_bytes(template.read_bytes())
        result = summarize_experience(self.folder)
        self.assertEqual(result["source_record_count"], 0)
        self.assertFalse(result["has_anomalies"])
        for condition in result["conditions"].values():
            self.assertEqual(condition["operators"], 0)
            self.assertIsNone(condition["completion_rate"])
            self.assertIsNone(condition["timing"]["mean_seconds"])
            self.assertIsNone(condition["checkpoints"]["goal"]["pass_rate"])

    def test_cross_day_and_time_zone_timing(self):
        self.write([record(started_at="2026-10-22T23:59:30+08:00", ended_at="2026-10-22T16:01:30Z")])
        summary = summarize_experience(self.folder)["conditions"]["assisted"]
        self.assertEqual(summary["timing"]["mean_seconds"], 120)
        self.assertEqual(summary["timing"]["median_seconds"], 120)

    def test_aborted_zero_duration_and_operator_denominators(self):
        self.write([record(), record("T02", completion="aborted", abort_reason="主动中止"), record("T03", ended_at="2026-10-22T09:00:00+08:00"), record("T04", "U02", ended_at="2026-10-22T09:03:00+08:00")])
        summary = summarize_experience(self.folder)["conditions"]["assisted"]
        self.assertEqual((summary["sessions"], summary["operators"]), (4, 2))
        self.assertEqual((summary["completed_sessions"], summary["aborted_sessions"]), (3, 1))
        self.assertEqual(summary["completion_rate"], 0.75)
        self.assertEqual(summary["timing"]["eligible_sessions"], 2)
        self.assertEqual(summary["timing"]["mean_seconds"], 120)
        self.assertEqual(summary["timing"]["median_seconds"], 120)
        self.assertEqual(summary["timing"]["zero_duration_completed_sessions"], 1)

    def test_duplicate_export_deduplicates_and_preserves_files(self):
        source = self.write([record()])
        self.write([record()], "nested/copy.json")
        before = source.read_bytes()
        result = summarize_experience(self.folder)
        self.assertEqual(result["summary"]["duplicate_records"], 1)
        self.assertEqual(result["summary"]["valid_sessions"], 1)
        self.assertEqual(source.read_bytes(), before)

    def test_conflicting_versions_exclude_whole_session(self):
        self.write([record(), record("T02")])
        self.write([record(ended_at="2026-10-22T09:02:00+08:00")], "conflict.json")
        result = summarize_experience(self.folder)
        self.assertTrue(result["has_anomalies"])
        self.assertEqual(result["summary"]["conflicting_sessions"], 1)
        self.assertEqual(result["summary"]["valid_sessions"], 1)
        self.assertEqual(result["valid_records"][0]["record"]["session_id"], "T02")

    def test_practice_and_exclusions_are_separate(self):
        self.write([record(), record("T02", practice=True), record("T03", exclusions=["主持人记录设备断电，本次排除"])])
        result = summarize_experience(self.folder)
        self.assertEqual(result["summary"]["valid_sessions"], 1)
        self.assertEqual(result["summary"]["practice_sessions"], 1)
        self.assertEqual(result["summary"]["excluded_sessions"], 1)

    def test_missing_and_not_applicable_ratings_are_not_zero(self):
        self.write([record()])
        ratings = summarize_experience(self.folder)["conditions"]["assisted"]["ratings"]
        self.assertEqual(ratings["understand"]["mean"], 4)
        self.assertEqual(ratings["evidence"]["missing_count"], 1)
        self.assertEqual(ratings["save"]["not_applicable_count"], 1)
        self.assertIsNone(ratings["evidence"]["mean"])
        self.assertIsNone(ratings["save"]["mean"])

    def test_invalid_records_leave_other_valid_records_available(self):
        invalid = [None, [], record("T02", ratings={"understand": True, "evidence": None, "save": None}), record("T03", started_at="2026-10-22T09:00:00"), record("T04", ended_at="2026-10-22T08:59:00+08:00"), record("T05", completion="aborted", abort_reason="")]
        self.write([record(), *invalid])
        result = summarize_experience(self.folder)
        self.assertEqual(result["summary"]["error_count"], 6)
        self.assertEqual(result["summary"]["valid_sessions"], 1)

    def test_non_object_wrong_schema_and_malformed_file_are_errors(self):
        (self.folder / "array.json").write_text("[]", encoding="utf-8")
        (self.folder / "broken.json").write_text("{", encoding="utf-8")
        self.write([], "boolean.json", schema_version=True)
        self.write([record()], "valid.json")
        result = summarize_experience(self.folder)
        self.assertEqual(result["summary"]["error_count"], 3)
        self.assertEqual(result["summary"]["valid_sessions"], 1)

    def test_conditions_and_checkpoint_denominators_are_separate(self):
        manual = record("T02", condition="manual")
        manual["checkpoints"]["goal"] = {"before": "", "after": "", "review": "", "export": "", "result": "not_applicable", "reason": "纯人工任务"}
        failed = record("T03")
        failed["checkpoints"]["goal"]["result"] = "fail"
        failed["checkpoints"]["goal"]["reason"] = "导出值未更新"
        self.write([record(), manual, failed])
        summary = summarize_experience(self.folder)["conditions"]
        self.assertEqual(summary["manual"]["sessions"], 1)
        self.assertIsNone(summary["manual"]["checkpoints"]["goal"]["pass_rate"])
        self.assertEqual(summary["assisted"]["checkpoints"]["goal"]["pass_rate"], 0.5)
        self.assertNotIn("efficiency_improvement", summary)

    def test_checkpoint_requires_evidence_and_na_reason(self):
        empty_pass = record("T02")
        empty_pass["checkpoints"]["goal"]["export"] = ""
        empty_na = copy.deepcopy(empty_pass)
        empty_na["session_id"] = "T03"
        empty_na["checkpoints"]["goal"]["result"] = "not_applicable"
        self.write([record(), empty_pass, empty_na])
        result = summarize_experience(self.folder)
        self.assertEqual(result["summary"]["error_count"], 2)
        self.assertEqual(result["summary"]["valid_sessions"], 1)


if __name__ == "__main__":
    unittest.main()
