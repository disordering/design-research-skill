'use strict';
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.StudyCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const STUDY_ID = 'D-P01-5s-v1';
  const IMAGE_HASH = 'f1201f54c66f3210ed14bd8785f0a3c532ee0e89cd6d3992cfaeb9970b7db1ed';
  const RATINGS = ['understand', 'evidence', 'save'];
  const CHECKPOINTS = ['goal', 'review', 'severity', 'recheck'];
  const clone = value => JSON.parse(JSON.stringify(value));
  const blankAnswers = () => Object.fromEntries(['q1', 'q2', 'q3'].map(k => [k, {text: '', response_status: 'missing'}]));
  const blankCheckpoints = () => Object.fromEntries(CHECKPOINTS.map(k => [k, {before: '', after: '', review: '', export: '', result: 'pending', reason: ''}]));
  function settings() {
    return {frontend_version: '', backend_version: '', system_url: '', sample_id: 'P01', condition: 'assisted', task: '在界面 AI 评审系统中上传指定截图，查看意见和截图证据；按任务完成确认或驳回、严重度调整、复审，并导出结果。'};
  }
  function emptyState() { return {schemaVersion: 1, settings: settings(), recognition: [], experience: [], draft: null}; }
  function validateState(state) {
    if (!state || state.schemaVersion !== 1 || !Array.isArray(state.recognition) || !Array.isArray(state.experience) || !state.settings || typeof state.settings !== 'object') throw Error('本机保存格式无法读取。');
    for (const rows of [state.recognition, state.experience]) {
      const seen = new Set();
      for (const record of rows) {
        if (!record || typeof record.session_id !== 'string' || !record.session_id || seen.has(record.session_id)) throw Error('本机记录编号需要核对。');
        seen.add(record.session_id);
      }
    }
    if (state.draft) {
      const draft = state.draft;
      if (!['recognition', 'experience'].includes(draft.kind) || !draft.record || !draft.record.session_id || typeof draft.phase !== 'string') throw Error('本机草稿格式无法读取。');
      if (draft.kind === 'recognition' && (!['countdown', 'exposure', 'answer'].includes(draft.phase) || !Array.isArray(draft.record.events) || !draft.record.answers || ['q1', 'q2', 'q3'].some(key => !draft.record.answers[key] || typeof draft.record.answers[key].text !== 'string'))) throw Error('识别回答草稿需要核对。');
      if (draft.kind === 'experience' && (!['timing', 'ratings'].includes(draft.phase) || !draft.record.ratings || !draft.record.rating_na_reasons || !draft.record.comments || !draft.record.metadata)) throw Error('体验回答草稿需要核对。');
    }
    return clone(state);
  }
  function answers(values) {
    return Object.fromEntries(['q1', 'q2', 'q3'].map(k => {
      // 保留回答原话；仅用去空格后的内容判断是否为空。
      const text = typeof values[k] === 'string' ? values[k] : '';
      return [k, {text, response_status: text.trim() ? 'answered' : 'missing'}];
    }));
  }
  function newRecognition(options) {
    const {id, participant, mode, experience, prior, at, device} = options;
    if (!participant.trim()) throw Error('请填写匿名编号。');
    if (!['participant', 'practice'].includes(mode)) throw Error('请选择记录类型。');
    if (mode === 'participant' && (prior !== 'no' || experience !== '中轻度手游玩家')) throw Error('正式参与者为首次看图的中轻度手游玩家；其他情况可选择设备演练。');
    return {schema_version: '1.0', study_id: STUDY_ID, session_id: id, mode, participant_id: participant.trim(), experience, prior_exposure: prior, consent: true, started_at: at, image: 'P01', image_sha256: IMAGE_HASH, planned_exposure_ms: 5000, device: clone(device), events: [], answers: blankAnswers(), status: 'in_progress', metadata: {source_type: 'human_participant', collection_tool: 'D被试填写台-v1'}};
  }
  function finishRecognition(record, values, status, at, abortReason = '') {
    if (!['completed', 'aborted'].includes(status)) throw Error('记录状态无效。');
    const out = clone(record);
    out.answers = answers(values);
    out.status = status;
    out.ended_at = at;
    out.exposure_quality = status === 'aborted' ? '中止' : out.events.some(e => e.phase === 'exposure' && ['hidden', 'blur', 'resize'].includes(e.type)) ? '需复核' : '按计划完成';
    if (status === 'aborted') out.abort_reason = abortReason || '参与者退出';
    return out;
  }
  function newExperience({id, participant, practice, config, at}) {
    if (!participant.trim()) throw Error('请填写匿名编号。');
    if (!config.sample_id.trim() || !config.task.trim()) throw Error('请在主持设置中填写样本和任务。');
    if (!['assisted', 'manual'].includes(config.condition)) throw Error('请选择实际任务条件。');
    return {session_id: id, operator_id: participant.trim(), condition: config.condition, practice: Boolean(practice), frontend_version: config.frontend_version.trim(), backend_version: config.backend_version.trim(), sample_id: config.sample_id.trim(), task: config.task.trim(), started_at: at, ended_at: '', completion: 'in_progress', abort_reason: '', exclusions: [], ratings: Object.fromEntries(RATINGS.map(k => [k, null])), rating_na_reasons: Object.fromEntries(RATINGS.map(k => [k, ''])), comments: {difficulty: '', suggestion: ''}, checkpoints: blankCheckpoints(), metadata: {source_type: 'human_participant', collection_tool: 'D被试填写台-v1', experience_target: '界面 AI 评审系统', experience_target_url: config.system_url || '', configuration_status: config.frontend_version.trim() && config.backend_version.trim() ? 'configured' : 'pending', consent: true}};
  }
  function stopExperience(record, status, at, reason = '') {
    if (!['completed', 'aborted'].includes(status)) throw Error('请选择完成或中止。');
    if (status === 'aborted' && !reason.trim()) throw Error('请写一句中止原因。');
    const duration = Date.parse(at) - Date.parse(record.started_at);
    if (!Number.isFinite(duration) || duration < 0) throw Error('起止时间需要核对。');
    return {...clone(record), ended_at: at, completion: status, abort_reason: status === 'aborted' ? reason : ''};
  }
  function setExperienceAnswers(record, ratingChoices, reasons, comments) {
    const out = clone(record);
    for (const key of RATINGS) {
      const choice = ratingChoices[key];
      if (![null, 'na', 1, 2, 3, 4, 5].includes(choice)) throw Error('评分请选择 1–5 分、不适用或暂未填写。');
      if (choice === 'na' && !String(reasons[key] || '').trim()) throw Error('选择不适用时，请补一句原因。');
      out.ratings[key] = choice === 'na' ? null : choice;
      out.rating_na_reasons[key] = choice === 'na' ? reasons[key] : '';
    }
    out.comments = {difficulty: String(comments.difficulty || ''), suggestion: String(comments.suggestion || '')};
    return out;
  }
  function setHostChecks(record, checks, versions) {
    const out = clone(record);
    for (const key of CHECKPOINTS) {
      const check = checks[key];
      if (!check || !['pending', 'pass', 'fail', 'not_applicable'].includes(check.result)) throw Error('请为四个节点选择检查结果。');
      for (const field of ['before', 'after', 'review', 'export', 'reason']) if (typeof check[field] !== 'string') throw Error('节点描述应为文字。');
      if (check.result === 'pass' && ['before', 'after', 'review', 'export'].some(field => !check[field].trim())) throw Error('通过的节点请补齐四阶段记录。');
      if (['fail', 'not_applicable'].includes(check.result) && !check.reason.trim()) throw Error('未通过或不适用请补充原因。');
      out.checkpoints[key] = clone(check);
    }
    out.frontend_version = versions.frontend_version.trim();
    out.backend_version = versions.backend_version.trim();
    out.metadata.configuration_status = out.frontend_version && out.backend_version ? 'configured' : 'pending';
    return out;
  }
  function upsert(records, record) {
    const out = records.filter(item => item.session_id !== record.session_id).map(clone);
    out.push(clone(record));
    return out;
  }
  function recognitionExport(records, mode, at) {
    const chosen = records.filter(record => record.mode === mode);
    return {study_id: STUDY_ID, exported_at: at, record_type: mode, record_count: chosen.length, records: clone(chosen)};
  }
  function experienceExport(records, at) {
    return {schema_version: 1, exported_at: at, record_type: 'tool_experience', record_count: records.length, metadata: {source_type: 'human_participant'}, records: clone(records)};
  }
  function recoverDraft(draft, at) {
    if (!draft) return null;
    const out = clone(draft);
    if (out.kind === 'recognition' && ['countdown', 'exposure'].includes(out.phase)) {
      out.record.events.push({type: 'reload', phase: out.phase, at, elapsed_ms: null});
      out.record = finishRecognition(out.record, Object.fromEntries(Object.entries(out.record.answers).map(([k, value]) => [k, value.text])), 'aborted', at, '页面刷新或关闭中断观看');
      out.phase = 'done';
      out.recovered_interruption = true;
    } else if (out.kind === 'experience' && out.phase === 'timing') {
      out.record = stopExperience(out.record, 'aborted', at, '页面刷新或关闭中断计时');
      out.phase = 'ratings';
      out.recovered_interruption = true;
    }
    return out;
  }
  return {STUDY_ID, IMAGE_HASH, RATINGS, CHECKPOINTS, clone, settings, emptyState, validateState, answers, newRecognition, finishRecognition, newExperience, stopExperience, setExperienceAnswers, setHostChecks, upsert, recognitionExport, experienceExport, recoverDraft};
});
