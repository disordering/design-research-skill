'use strict';
// 全部使用虚构编号与合成记录，仅验证程序，不进入正式研究数据。
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');
const at = '2026-10-22T10:00:00.000Z', end = '2026-10-22T10:01:00.000Z';
const recognition = (mode = 'participant') => C.newRecognition({id: 'synthetic-r1', participant: 'TEST01', mode, experience: '中轻度手游玩家', prior: 'no', at, device: {viewport_width: 1000}});
const experience = () => C.newExperience({id: 'synthetic-e1', participant: 'TEST01', practice: true, config: C.settings(), at});

test('正式识别固定图、方案和五秒时长', () => {
  const r = recognition(); assert.equal(r.study_id, C.STUDY_ID); assert.equal(r.image_sha256, C.IMAGE_HASH); assert.equal(r.planned_exposure_ms, 5000); assert.equal(r.metadata.source_type, 'human_participant');
});
test('不符首次观看条件只能演练', () => {
  const options = {id:'a', participant:'TEST', mode:'participant', experience:'中轻度手游玩家', prior:'yes', at, device:{}};
  assert.throws(() => C.newRecognition(options), /正式参与者/);
  assert.equal(C.newRecognition({...options, mode:'practice'}).mode, 'practice');
});
test('识别原话保留，不把空白或不记得判成错误', () => {
  const r = C.finishRecognition(recognition(), {q1: '  我不记得  ', q2: '', q3: '\n'}, 'completed', end);
  assert.equal(r.answers.q1.text, '  我不记得  '); assert.equal(r.answers.q1.response_status, 'answered'); assert.equal(r.answers.q2.response_status, 'missing'); assert.equal(r.answers.q3.response_status, 'missing'); assert.equal(r.answers.q1.score, undefined);
});
test('曝光窗口事件保留并标记复核', () => {
  const r = recognition(); r.events.push({type:'resize', phase:'exposure', at});
  assert.equal(C.finishRecognition(r, {}, 'completed', end).exposure_quality, '需复核');
});
test('识别导出正式演练分开、数量准确、深拷贝', () => {
  const real = recognition(), practice = recognition('practice'); practice.session_id='synthetic-r2';
  const data = C.recognitionExport([real, practice], 'participant', end);
  assert.equal(data.record_count,1); assert.equal(data.records[0].mode,'participant'); data.records[0].participant_id='CHANGED'; assert.equal(real.participant_id,'TEST01');
});
test('计时从开始至停止并保留实际版本空白和待检查节点', () => {
  const r = C.stopExperience(experience(), 'completed', end);
  assert.equal(r.started_at, at); assert.equal(r.ended_at, end); assert.equal(r.frontend_version,''); assert.equal(r.metadata.configuration_status,'pending');
  assert.deepEqual(Object.values(r.checkpoints).map(x => x.result), ['pending','pending','pending','pending']);
});
test('中止要求理由、拒绝倒序时间', () => {
  assert.throws(() => C.stopExperience(experience(), 'aborted', end, ''), /中止原因/);
  assert.throws(() => C.stopExperience(experience(), 'completed', '2026-10-22T09:00:00.000Z'), /起止时间/);
  assert.equal(C.stopExperience(experience(), 'aborted', end, '合成设备中断').abort_reason, '合成设备中断');
});
test('评分、未填和不适用分开保存', () => {
  const r = C.setExperienceAnswers(experience(), {understand: 4, evidence: null, save: 'na'}, {save:'合成任务没有保存步骤'}, {difficulty:'合成原话', suggestion:''});
  assert.deepEqual(r.ratings, {understand:4,evidence:null,save:null}); assert.equal(r.rating_na_reasons.save,'合成任务没有保存步骤'); assert.equal(r.rating_na_reasons.evidence,'');
});
test('不适用必须写理由，数值仅1至5整数', () => {
  assert.throws(() => C.setExperienceAnswers(experience(), {understand:'na', evidence:null, save:null}, {}, {}), /不适用/);
  for (const value of [0,6,2.5,'3',false,undefined]) assert.throws(() => C.setExperienceAnswers(experience(), {understand:value, evidence:null, save:null}, {}, {}), /评分/);
});
test('主持通过必须四阶段证据，不适用必须原因', () => {
  const r = experience(), checks = C.clone(r.checkpoints); checks.goal.result='pass';
  assert.throws(() => C.setHostChecks(r,checks,{frontend_version:'a',backend_version:'b'}), /四阶段/);
  Object.assign(checks.goal,{before:'合成前',after:'合成后',review:'合成复审',export:'合成导出'});
  checks.review.result='not_applicable';
  assert.throws(() => C.setHostChecks(r,checks,{frontend_version:'a',backend_version:'b'}), /原因/);
  checks.review.reason='合成任务无此对象';
  const updated = C.setHostChecks(r,checks,{frontend_version:'a',backend_version:'b'}); assert.equal(updated.metadata.configuration_status,'configured'); assert.equal(r.checkpoints.goal.result,'pending');
});
test('同会话修订替换，不重复累计', () => {
  const r = experience(); const first = C.upsert([],r); const second = C.upsert(first,{...r,frontend_version:'v2'});
  assert.equal(second.length,1); assert.equal(second[0].frontend_version,'v2'); assert.equal(first[0].frontend_version,'');
});
test('体验导出保留schema与原记录，不混入识别格式', () => {
  const data = C.experienceExport([experience()],end); assert.equal(data.schema_version,1); assert.equal(data.record_count,1); assert.equal(data.record_type,'tool_experience'); assert.equal(data.records[0].operator_id,'TEST01');
});
test('曝光刷新记中止，永不重放图片', () => {
  for (const phase of ['countdown','exposure']) {
    const restored = C.recoverDraft({kind:'recognition',phase,record:recognition()},end);
    assert.equal(restored.phase,'done'); assert.equal(restored.record.status,'aborted'); assert.equal(restored.record.events[0].type,'reload'); assert.equal(restored.record.exposure_quality,'中止');
  }
});
test('作答草稿恢复原话，不再次曝光', () => {
  const r = recognition(); r.answers = C.answers({q1:'合成回答'});
  const restored = C.recoverDraft({kind:'recognition',phase:'answer',record:r},end);
  assert.equal(restored.phase,'answer'); assert.equal(restored.record.answers.q1.text,'合成回答');
});
test('体验计时刷新中止，评分阶段恢复原停止时间', () => {
  const restored = C.recoverDraft({kind:'experience',phase:'timing',record:experience()},end);
  assert.equal(restored.phase,'ratings'); assert.equal(restored.record.completion,'aborted'); assert.equal(restored.record.ended_at,end);
  const again = C.recoverDraft(restored,'2026-10-22T12:00:00.000Z'); assert.equal(again.record.ended_at,end);
});
test('本机存储格式及重复会话校验', () => {
  assert.throws(() => C.validateState({}), /格式/);
  const state=C.emptyState(); state.recognition=[recognition(),recognition()]; assert.throws(() => C.validateState(state), /编号/);
  state.recognition=[recognition()]; assert.deepEqual(C.validateState(state),state);
});
test('损坏的回答草稿拒绝读入，不以空白覆盖', () => {
  const state = C.emptyState(); state.draft={kind:'recognition',phase:'answer',record:{session_id:'synthetic',events:[],answers:{}}};
  assert.throws(() => C.validateState(state), /草稿/);
  state.draft={kind:'experience',phase:'timing',record:{session_id:'synthetic'}}; assert.throws(() => C.validateState(state), /草稿/);
});
