@echo off
chcp 65001 >nul
setlocal
set "PYTHONDONTWRITEBYTECODE=1"
if defined D_PYTHON goto custom
if exist "%~dp0..\..\..\work\d_execution_20261021\.venv\Scripts\python.exe" goto local
where py >nul 2>nul
if not errorlevel 1 goto py
where python >nul 2>nul
if not errorlevel 1 goto python
echo 请安装 Python 3.10 或以上版本，再运行本文件。
goto finish
:custom
"%D_PYTHON%" -X utf8 "%~dp0程序\src\summarize.py"
goto finish
:local
"%~dp0..\..\..\work\d_execution_20261021\.venv\Scripts\python.exe" -X utf8 "%~dp0程序\src\summarize.py"
goto finish
:py
py -3 -X utf8 "%~dp0程序\src\summarize.py"
goto finish
:python
python -X utf8 "%~dp0程序\src\summarize.py"
:finish
if /I not "%~1"=="--no-pause" pause
endlocal
