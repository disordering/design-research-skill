import {execFile} from 'node:child_process';

const url='http://127.0.0.1:4181/';
const checkOnly=process.argv.includes('--check-only');
let running=false;
try {
 const page=await fetch(url,{signal:AbortSignal.timeout(3000)});
 const text=await page.text();
 if(page.status!==200||!text.includes('<title>明鉴 · 交互评审工作台</title>')) {
  console.error('4181 端口正在提供其他服务，请保留现有服务后再安排试用端口。');
  process.exit(2);
 }
 running=true;
} catch(error) {
 if(error.cause?.code!=='ECONNREFUSED') {
  console.error('4181 入口尚未完成响应，请稍后重试。');
  process.exit(2);
 }
}

if(checkOnly) process.exit(running?0:1);
if(running) {
 console.log('明鉴已经运行：'+url);
 execFile('C:\\Windows\\System32\\rundll32.exe',['url.dll,FileProtocolHandler',url],error=>{
  if(error) console.log('请在浏览器打开：'+url);
 });
} else {
 console.log('明鉴正在启动。请保留此窗口，并打开：'+url);
 console.log('结束使用可按 Ctrl+C。');
 await import('./server-user.mjs');
}
