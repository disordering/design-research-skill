@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
"C:\Program Files\nodejs\node.exe" launch-user.mjs
if errorlevel 1 pause
