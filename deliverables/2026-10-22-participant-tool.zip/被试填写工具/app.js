'use strict';
(() => {
  const C = window.StudyCore;
  const $ = id => document.getElementById(id);
  const KEY = 'd-participant-desk-v1-20261022';
  const now = () => new Date().toISOString();
  const makeId = prefix => prefix + '-' + Date.now() + '-' + (window.crypto && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2));
  let state = C.emptyState(), current = null, last = null, phase = 'home', imageReady = false;
  let storageBlocked = false, storageOkay = true, frame = null, countdown = null, fallback = null, clock = null, exposureStart = null;
  const ratingChoices = Object.fromEntries(C.RATINGS.map(key => [key, null]));
  const ratingLabels = {understand: '我能理解系统给出的意见', evidence: '我能找到意见对应的截图证据', save: '我能完成修订，并确认结果已保存'};
  const checkLabels = {goal: '目标确认', review: '发现确认或驳回', severity: '严重度调整', recheck: '复审'};
  const stageLabels = {before: '操作前', after: '操作后', review: '复审结果', export: '导出结果'};

  function message(text, error = false) {
    $('message').textContent = text;
    $('message').hidden = !text;
    $('message').classList.toggle('error', error);
  }
  function storageWarning(text) {
    storageOkay = false;
    $('storage-warning').textContent = text;
    $('storage-warning').hidden = false;
  }
  try {
    const saved = localStorage.getItem(KEY);
    if (saved) state = C.validateState(JSON.parse(saved));
  } catch (error) {
    storageBlocked = true;
    storageWarning('本机旧记录暂未读入，原内容保持不变。本次可继续填写并导出；关闭页面前请保存 JSON。');
  }
  function counts() {
    const formal = state.recognition.filter(record => record.mode === 'participant');
    const practice = state.recognition.filter(record => record.mode === 'practice');
    $('counts').textContent = `正式识别 ${formal.length} 条（完成 ${formal.filter(record => record.status === 'completed').length} 条）；识别演练 ${practice.length} 条；工具体验 ${state.experience.length} 条（正式 ${state.experience.filter(record => !record.practice).length} 条）。`;
  }
  function persist() {
    if (!storageBlocked) {
      try { localStorage.setItem(KEY, JSON.stringify(state)); storageOkay = true; $('storage-warning').hidden = true; }
      catch (error) { storageWarning('浏览器未能保存到本机。当前记录仍在页面内，请导出 JSON 后再关闭。'); }
    }
    counts();
  }
  function saveDraft() {
    state.draft = current ? {kind: current.kind, phase, record: C.clone(current.record), ratingChoices: {...ratingChoices}, ratingReasons: Object.fromEntries(C.RATINGS.map(key => [key, $('na-' + key).value]))} : null;
    persist();
  }
  function show(view) {
    document.querySelectorAll('.view').forEach(node => { node.hidden = node.id !== view; });
    $('host-panel').hidden = !['home', 'recognition-setup', 'experience-setup', 'done'].includes(view);
    if (view !== 'done') $('host-completion').open = false;
    window.scrollTo({top: 0, behavior: 'instant'});
  }
  function clearInputs() {
    for (const id of ['recognition-id', 'experience-id', 'q1', 'q2', 'q3', 'difficulty', 'suggestion', 'abort-reason']) $(id).value = '';
    for (const id of ['recognition-consent', 'experience-consent', 'used-tool']) $(id).checked = false;
    $('recognition-experience').value = '';
    $('recognition-prior').value = '';
    $('recognition-mode').value = 'participant';
    $('experience-mode').value = 'participant';
    $('abort-box').hidden = true;
    $('host-panel').open = false;
    $('host-completion').open = false;
    for (const key of C.RATINGS) { ratingChoices[key] = null; $('na-' + key).value = ''; updateRating(key); }
  }
  function goHome() {
    clearTimers(); current = null; last = null; phase = 'home'; state.draft = null;
    clearInputs(); message(''); show('home'); persist();
  }
  function setSettingsFields() {
    for (const [name, id] of Object.entries({frontend_version: 'frontend', backend_version: 'backend', system_url: 'url', sample_id: 'sample', condition: 'condition', task: 'task'})) $('setting-' + id).value = state.settings[name] || '';
    $('task-preview').textContent = state.settings.task;
    const url = state.settings.system_url || '';
    $('system-link').hidden = !url; $('system-link-hint').hidden = Boolean(url);
    if (url) $('system-link').href = url;
  }
  $('save-settings').addEventListener('click', () => {
    const config = {frontend_version: $('setting-frontend').value, backend_version: $('setting-backend').value, system_url: $('setting-url').value.trim(), sample_id: $('setting-sample').value.trim(), condition: $('setting-condition').value, task: $('setting-task').value.trim()};
    if (!config.sample_id || !config.task) return message('请填写样本编号和任务说明。', true);
    if (config.system_url) {
      try { if (!['http:', 'https:'].includes(new URL(config.system_url).protocol)) throw Error(); }
      catch (error) { return message('系统入口请填写完整的 http 或 https 网址。', true); }
    }
    state.settings = config; setSettingsFields(); persist(); message('任务设置已保存；下一次体验使用这些设置。');
  });
  $('open-recognition').addEventListener('click', () => { clearInputs(); phase = 'recognition-setup'; message(''); show('recognition-setup'); $('recognition-id').focus(); });
  $('open-experience').addEventListener('click', () => { clearInputs(); phase = 'experience-setup'; message(''); show('experience-setup'); $('experience-id').focus(); });
  document.querySelectorAll('.back-home').forEach(node => node.addEventListener('click', goHome));
  $('done-home').addEventListener('click', goHome);
  $('next-participant').addEventListener('click', () => {
    const kind = last && last.kind;
    goHome();
    if (kind) $('open-' + kind).click();
  });
  function dimensions() {
    return {viewport_width: innerWidth, viewport_height: innerHeight, screen_width: screen.width, screen_height: screen.height, device_pixel_ratio: devicePixelRatio, visual_viewport_scale: window.visualViewport ? visualViewport.scale : null};
  }
  function event(type) {
    if (current && current.kind === 'recognition' && ['countdown', 'exposure', 'answer'].includes(phase)) {
      current.record.events.push({type, phase, at: now(), elapsed_ms: exposureStart === null ? null : Math.round(performance.now() - exposureStart)});
      saveDraft();
    }
  }
  function ready() {
    imageReady = true; $('recognition-begin').disabled = false;
    $('image-status').textContent = '图片已准备好。正式测试请使用主持人指定的设备和窗口尺寸。';
  }
  $('stimulus').addEventListener('load', ready);
  $('stimulus').addEventListener('error', () => { imageReady = false; $('recognition-begin').disabled = true; $('image-status').textContent = '图片未读入，请保留 assets 文件夹，再打开 index.html。'; });
  if ($('stimulus').complete && $('stimulus').naturalWidth) ready();
  function clearTimers() {
    clearInterval(countdown); cancelAnimationFrame(frame); clearTimeout(fallback); clearInterval(clock);
    countdown = frame = fallback = clock = null;
  }
  $('recognition-begin').addEventListener('click', () => {
    if (!imageReady || current) return;
    const participant = $('recognition-id').value.trim(), mode = $('recognition-mode').value;
    if (!participant || !$('recognition-experience').value || !$('recognition-prior').value || !$('recognition-consent').checked) return message('请填写匿名编号、看图经历和手游情况，并勾选参与确认。', true);
    if (mode === 'participant' && state.recognition.some(record => record.mode === mode && record.participant_id === participant)) return message('这个编号已有正式记录。下一位请使用新的匿名编号。', true);
    try { current = {kind: 'recognition', record: C.newRecognition({id: makeId('recognition'), participant, mode, experience: $('recognition-experience').value, prior: $('recognition-prior').value, at: now(), device: dimensions()})}; }
    catch (error) { return message(error.message, true); }
    message(''); phase = 'countdown'; exposureStart = null; saveDraft();
    $('recognition-setup').hidden = true; $('host-panel').hidden = true;
    $('stage').hidden = false; $('countdown').hidden = false; $('stimulus').hidden = true;
    let count = 3; $('countdown').textContent = count;
    countdown = setInterval(() => {
      count -= 1;
      if (count > 0) $('countdown').textContent = count;
      else { clearInterval(countdown); expose(); }
    }, 1000);
  });
  function expose() {
    if (phase !== 'countdown' || !current) return;
    phase = 'exposure'; $('countdown').hidden = true; $('stimulus').hidden = false;
    saveDraft(); frame = requestAnimationFrame(tick);
  }
  function tick(t) {
    if (phase !== 'exposure' || !current) return;
    if (exposureStart === null) {
      exposureStart = t; current.record.exposure_start_at = now();
      current.record.exposure_rect = Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, $('stimulus').getBoundingClientRect()[key]]));
      saveDraft();
      fallback = setTimeout(() => { if (phase === 'exposure') finishExposure(performance.now()); }, 5100);
    }
    if (t - exposureStart >= 5000) finishExposure(t);
    else frame = requestAnimationFrame(tick);
  }
  function finishExposure(t) {
    if (!current || phase !== 'exposure') return;
    clearTimeout(fallback); cancelAnimationFrame(frame);
    $('stimulus').hidden = true; $('stage').hidden = true;
    current.record.exposure_end_at = now(); current.record.browser_exposure_ms = Math.round(t - exposureStart);
    current.record.image_display_rect_after = dimensions(); current.record.answer_started_at = now();
    phase = 'answer'; saveDraft(); show('recognition-answer'); $('q1').focus();
  }
  function readAnswers() { return Object.fromEntries(['q1', 'q2', 'q3'].map(key => [key, $(key).value])); }
  for (const key of ['q1', 'q2', 'q3']) $(key).addEventListener('input', () => {
    if (!current || current.kind !== 'recognition') return;
    current.record.answers = C.answers(readAnswers()); saveDraft();
  });
  function finishRecognition(status, reason) {
    if (!current || current.kind !== 'recognition') return;
    if (phase === 'exposure' && exposureStart !== null) { current.record.browser_exposure_ms = Math.round(performance.now() - exposureStart); current.record.exposure_end_at = now(); }
    clearTimers(); $('stage').hidden = true; $('stimulus').hidden = true;
    current.record = C.finishRecognition(current.record, readAnswers(), status, now(), reason);
    commitCurrent();
  }
  $('recognition-save').addEventListener('click', () => finishRecognition('completed'));
  $('recognition-abort').addEventListener('click', () => finishRecognition('aborted', '参与者在回答阶段退出'));
  $('stage-abort').addEventListener('click', () => finishRecognition('aborted', '参与者退出观看'));

  $('experience-begin').addEventListener('click', () => {
    if (current) return;
    if (!$('experience-consent').checked) return message('请先勾选自愿参与确认。', true);
    try { current = {kind: 'experience', record: C.newExperience({id: makeId('experience'), participant: $('experience-id').value, practice: $('experience-mode').value === 'practice', config: state.settings, at: now()})}; }
    catch (error) { return message(error.message, true); }
    phase = 'timing'; message(''); saveDraft(); $('running-task').textContent = current.record.task;
    show('experience-timing'); renderClock(); clock = setInterval(renderClock, 250);
  });
  function renderClock() {
    if (!current || current.kind !== 'experience') return;
    const seconds = Math.max(0, Math.floor((Date.now() - Date.parse(current.record.started_at)) / 1000));
    $('timer').textContent = `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
  }
  function stopExperience(status, reason) {
    if (!current || current.kind !== 'experience') return;
    try { current.record = C.stopExperience(current.record, status, now(), reason); }
    catch (error) { return message(error.message, true); }
    current.record.metadata.used_tool = status === 'completed';
    clearInterval(clock); phase = 'ratings'; saveDraft(); showRatings();
  }
  $('experience-complete').addEventListener('click', () => stopExperience('completed', ''));
  $('show-abort').addEventListener('click', () => { $('abort-box').hidden = false; $('abort-reason').focus(); });
  $('experience-abort').addEventListener('click', () => stopExperience('aborted', $('abort-reason').value));
  function createRatingCards() {
    for (const key of C.RATINGS) {
      const box = document.createElement('div'); box.className = 'rating-card';
      const heading = document.createElement('h2'); heading.textContent = ratingLabels[key]; box.append(heading);
      const buttons = document.createElement('div'); buttons.className = 'rating-buttons'; buttons.setAttribute('role', 'group'); buttons.setAttribute('aria-label', ratingLabels[key]);
      for (const choice of [1, 2, 3, 4, 5, 'na']) {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = choice === 'na' ? '不适用' : String(choice); button.dataset.choice = String(choice); button.dataset.rating = key; button.setAttribute('aria-pressed', 'false'); if (choice === 'na') button.className = 'na-button';
        button.addEventListener('click', () => { ratingChoices[key] = choice; if (choice !== 'na') $('na-' + key).value = ''; updateRating(key); saveRatingDraft(); }); buttons.append(button);
      }
      box.append(buttons);
      const scale = document.createElement('div'); scale.className = 'rating-hints'; scale.innerHTML = '<span>非常不同意</span><span>非常同意</span>'; box.append(scale);
      const clear = document.createElement('button'); clear.type = 'button'; clear.className = 'text-button rating-clear'; clear.textContent = '清除此项选择'; clear.addEventListener('click', () => { ratingChoices[key] = null; $('na-' + key).value = ''; updateRating(key); saveRatingDraft(); }); box.append(clear);
      const label = document.createElement('label'); label.id = 'na-label-' + key; label.hidden = true; label.textContent = '不适用的原因';
      const input = document.createElement('input'); input.id = 'na-' + key; input.placeholder = '例如本次任务没有这项操作'; input.addEventListener('input', saveRatingDraft); label.append(input); box.append(label); $('ratings').append(box);
    }
  }
  function updateRating(key) {
    document.querySelectorAll(`[data-rating="${key}"]`).forEach(button => { const selected = String(ratingChoices[key]) === button.dataset.choice; button.classList.toggle('active', selected); button.setAttribute('aria-pressed', String(selected)); });
    $('na-label-' + key).hidden = ratingChoices[key] !== 'na';
  }
  function saveRatingDraft() {
    if (!current || current.kind !== 'experience' || phase !== 'ratings') return;
    for (const key of C.RATINGS) {
      current.record.ratings[key] = ratingChoices[key] === 'na' ? null : ratingChoices[key];
      current.record.rating_na_reasons[key] = ratingChoices[key] === 'na' ? $('na-' + key).value : '';
    }
    current.record.comments = {difficulty: $('difficulty').value, suggestion: $('suggestion').value};
    current.record.metadata.used_tool = $('used-tool').checked;
    saveDraft();
  }
  for (const id of ['difficulty', 'suggestion', 'used-tool']) $(id).addEventListener('input', saveRatingDraft);
  function showRatings() {
    const record = current.record;
    const seconds = Math.round((Date.parse(record.ended_at) - Date.parse(record.started_at)) / 1000);
    $('duration-receipt').textContent = `本次${record.completion === 'completed' ? '完成' : '中止'}任务，用时 ${Math.floor(seconds / 60)} 分 ${seconds % 60} 秒。`;
    $('difficulty').value = record.comments.difficulty; $('suggestion').value = record.comments.suggestion; $('used-tool').checked = Boolean(record.metadata.used_tool);
    for (const key of C.RATINGS) updateRating(key);
    message(''); show('experience-ratings');
  }
  $('experience-save').addEventListener('click', () => {
    if (!current || current.kind !== 'experience') return;
    if (!$('used-tool').checked && C.RATINGS.some(key => typeof ratingChoices[key] === 'number')) return message('请确认已实际操作再评分；尚未体验的项目可以清除选择或填写不适用。', true);
    try { current.record = C.setExperienceAnswers(current.record, ratingChoices, Object.fromEntries(C.RATINGS.map(key => [key, $('na-' + key).value])), {difficulty: $('difficulty').value, suggestion: $('suggestion').value}); }
    catch (error) { return message(error.message, true); }
    current.record.metadata.used_tool = $('used-tool').checked;
    commitCurrent();
  });
  function commitCurrent() {
    if (!current) return;
    state[current.kind] = C.upsert(state[current.kind], current.record);
    last = C.clone(current); current = null; phase = 'done'; state.draft = null; persist(); message(''); renderDone();
  }
  function renderDone() {
    const record = last.record, recognition = last.kind === 'recognition';
    $('done-receipt').textContent = `${recognition ? record.participant_id : record.operator_id} · ${recognition ? '五秒识别' : '工具体验'} · ${(recognition ? record.status : record.completion) === 'completed' ? '已完成' : '已记录中止'}。`;
    $('done-storage').textContent = storageOkay ? '已保存在本机。请将导出的 JSON 交给主持人。' : '当前记录已留在页面内。请先导出 JSON，再关闭页面。';
    $('host-completion').hidden = recognition;
    if (!recognition) fillHostChecks(record);
    show('done');
  }
  function createCheckEditors() {
    for (const key of C.CHECKPOINTS) {
      const box = document.createElement('div'); box.className = 'checkpoint';
      const title = document.createElement('h3'); title.textContent = checkLabels[key]; box.append(title);
      const label = document.createElement('label'); label.textContent = '检查结果';
      const select = document.createElement('select'); select.id = 'check-' + key + '-result';
      for (const [value, text] of [['pending', '待补充'], ['pass', '通过'], ['fail', '未通过'], ['not_applicable', '不适用']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; select.append(option); }
      label.append(select); box.append(label);
      const grid = document.createElement('div'); grid.className = 'grid';
      for (const field of ['before', 'after', 'review', 'export']) { const label = document.createElement('label'); label.textContent = stageLabels[field]; const input = document.createElement('textarea'); input.id = 'check-' + key + '-' + field; label.append(input); grid.append(label); }
      box.append(grid);
      const reasonLabel = document.createElement('label'); reasonLabel.textContent = '原因或补充'; const input = document.createElement('textarea'); input.id = 'check-' + key + '-reason'; reasonLabel.append(input); box.append(reasonLabel); $('checkpoint-editors').append(box);
    }
  }
  function fillHostChecks(record) {
    $('record-frontend').value = record.frontend_version; $('record-backend').value = record.backend_version;
    for (const key of C.CHECKPOINTS) for (const field of ['before', 'after', 'review', 'export', 'result', 'reason']) $('check-' + key + '-' + field).value = record.checkpoints[key][field];
  }
  $('save-host-checks').addEventListener('click', () => {
    if (!last || last.kind !== 'experience') return;
    const checks = Object.fromEntries(C.CHECKPOINTS.map(key => [key, Object.fromEntries(['before', 'after', 'review', 'export', 'result', 'reason'].map(field => [field, $('check-' + key + '-' + field).value]))]));
    try { last.record = C.setHostChecks(last.record, checks, {frontend_version: $('record-frontend').value, backend_version: $('record-backend').value}); }
    catch (error) { return message(error.message, true); }
    state.experience = C.upsert(state.experience, last.record); persist(); message('主持人补充已保存。请重新导出本次记录，交回最新文件。');
  });
  function download(payload, name) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], {type: 'application/json;charset=utf-8'}));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = name.replace(/[<>:"/\\|?*]/g, '_') + '_' + now().replace(/[:.]/g, '-') + '.json'; document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  $('export-current').addEventListener('click', () => {
    if (!last) return;
    const record = last.record;
    if (last.kind === 'recognition') download(C.recognitionExport([record], record.mode, now()), (record.mode === 'participant' ? '正式识别_' : '识别演练_') + record.participant_id);
    else download(C.experienceExport([record], now()), '工具体验_' + record.operator_id);
  });
  $('export-recognition').addEventListener('click', () => download(C.recognitionExport(state.recognition, 'participant', now()), '全部正式识别'));
  $('export-practice').addEventListener('click', () => download(C.recognitionExport(state.recognition, 'practice', now()), '全部识别演练'));
  $('export-experience').addEventListener('click', () => download(C.experienceExport(state.experience, now()), '全部工具体验'));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && current && current.kind === 'recognition') { event('escape'); finishRecognition('aborted', '参与者按 Esc 退出'); } });
  document.addEventListener('visibilitychange', () => {
    event(document.hidden ? 'hidden' : 'visible');
    if (document.hidden && current && current.kind === 'recognition' && ['countdown', 'exposure'].includes(phase)) finishRecognition('aborted', '观看期间切换了页面或应用');
  });
  window.addEventListener('blur', () => event('blur'));
  window.addEventListener('resize', () => event('resize'));
  window.addEventListener('pagehide', () => {
    if (!current) return;
    if (current.kind === 'recognition' && ['countdown', 'exposure'].includes(phase)) { event('pagehide'); finishRecognition('aborted', '页面关闭或刷新中断观看'); }
    else if (current.kind === 'experience' && phase === 'timing') {
      clearInterval(clock); current.record = C.stopExperience(current.record, 'aborted', now(), '页面关闭或刷新中断计时'); phase = 'ratings'; saveDraft(); showRatings();
    } else saveDraft();
  });
  createRatingCards(); createCheckEditors(); setSettingsFields(); counts();
  if (state.draft) {
    const restored = C.recoverDraft(state.draft, now());
    current = {kind: restored.kind, record: restored.record}; phase = restored.phase;
    for (const key of C.RATINGS) {
      ratingChoices[key] = restored.ratingChoices && Object.prototype.hasOwnProperty.call(restored.ratingChoices, key) ? restored.ratingChoices[key] : current.kind === 'experience' ? (current.record.rating_na_reasons[key] ? 'na' : current.record.ratings[key]) : null;
      $('na-' + key).value = restored.ratingReasons ? restored.ratingReasons[key] || '' : current.kind === 'experience' ? current.record.rating_na_reasons[key] : '';
      updateRating(key);
    }
    if (phase === 'done') { commitCurrent(); message('上次观看已记录为中止。下一位使用新的匿名编号开始。'); }
    else if (current.kind === 'recognition' && phase === 'answer') {
      for (const key of ['q1', 'q2', 'q3']) $(key).value = current.record.answers[key].text;
      show('recognition-answer'); message('已恢复上次回答草稿，可以继续填写。'); saveDraft();
    } else if (current.kind === 'experience' && phase === 'ratings') { showRatings(); message(restored.recovered_interruption ? '上次计时已记录为中止，请按实际体验补充回答。' : '已恢复上次体验回答草稿。'); saveDraft(); }
  }
})();
