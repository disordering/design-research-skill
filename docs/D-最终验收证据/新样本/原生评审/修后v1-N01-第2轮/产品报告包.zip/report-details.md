# 协同交互方案评审报告

> 会话：`session-d52bfcc6dfc641bc98aeedbcfa8ae1ea`  
> 运行：`run-72cb38f9793b46d0a690c3a50e85359f`  
> 报告版本：`1`  
> 状态 / 完整性：`completed` / `partial`  
> 技术路径：`A 0.2-method-draft / T01–T10`  
> 判据版本：`0.2-method-draft`  
> 证据模式：`runtime`

## 一、结论摘要

本次围绕“本次检查本机演示原型的实际操作。按以下任务卡执行评审：  
任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ-N01-03 恢复初始后，三个选项及已应用预览共同恢复初始值。  
请根据实际操作证据逐项评审，并记录其他具体、可定位的问题。操作仅影响本地页面。”执行 46 项检查。执行状态：not_executed=46；判断状态：无。`complete` 仅表示计划项均有可追溯处置，不代表产品全部通过。

当前没有通过证据核验的候选发现；请结合未决项理解范围。

## 二、版本、路径与复现

| 字段 | 当前值 |
| --- | --- |
| 会话 / 运行 | `session-d52bfcc6dfc641bc98aeedbcfa8ae1ea` / `run-72cb38f9793b46d0a690c3a50e85359f` |
| 上下文 / 报告版本 | 1 / 1 |
| 会话契约 | `session-1.0` |
| 判据 / 方法 | `0.2-method-draft` / A T01–T10 |
| 方法目录 | C:\Users\nozomi222333\Documents\Codex\2026-10-02\wo\design-research-skill\docs\D-最终验收证据\新样本\冻结运行源码-修后v1\方法专家开发交付-v0.2 |
| 判据来源 | {'name': "Jakob Nielsen's 10 Usability Heuristics for User Interface Design", 'url': 'https://www.nngroup.com/articles/ten-usability-heuristics/', 'relationship': '以下条目由小组据宽泛原则操作化，并非源文逐条摘录或正式规范符合性声明'} |
| 模型 | codex_cli/gpt-6.1-sol |
| 是否测试夹具 | 否 |
| 方法文件指纹 | `{'00先看这个！！！！-阅读与开发交接.md': '6dca7b14918a08d65e40362bfec2fc40a1f8f1d0492e4f356b2ac9b8f00d051e', '01-04-场景输入流程与技术路径.md': 'fe432cf3851ad10528e53d6fecc14e9ffaba0a4fafd96a1b6ee61c4007c28347', '05-24条判据修订与变更对照.md': 'bd2f82f8d8e539d2011b0b684d77de775b0149ec0e14736717944f2057847c99', '05-判据库-v0.2.json': 'b785eb9c6b64b5d9ceb87ca76430af4a2658c944c9aff99a97ce9298bdf54af7', '05-判据执行补充-v0.2.json': '8e502b943023c7e39a8da6a479c1cc09f621c9474520e4f116cae0553bc9c24d', '05-逐字段变更对照.csv': 'd0b1d25442662ecf10150e923b98b8049ad7291e2bf56653690a138392d8307d', '06-新场景方法-v0.2.json': '1702aa0350c41ced0363a41d73c46aeb547d60d7299616964875b51ce8fd689c', '06-新场景方法与正反例.md': 'e21e0996cc25bc218f5e24e2c3a7aa66649001eb58ad00e84fcb5fc88b48ca26', '07-会话变更重查与复审规则.md': 'c9a5f573648a20094f4b0c4602043979b33ea3cb935a6976b641cf57b539f025', '08-问题表达严重度与评价验收.md': '4d92cfcfdb8417a20678995528ea0180f6182eb52b0b2becbb3a7fc44886eead', '09-开发验收用例.json': 'fc85e0bd301b081d393ab4764f0f0b59003e2462d842ebee91bc990eb9f41f60', '09-开发验收用例.md': 'e2ca3487871026558697e1283734849af2ef94de25b984ade9ae8334a73a2fd3', '10-来源索引.json': 'e6147e42231bb4602cb506caa7a2d6ff69812b2d7d1289731a33220db667017a', '11-交付校验结果.json': '3ec123147dae0c46a6bd2a473a0c5f0bbe5f1d311f42bc2568e41b63b5694cad'}` |

复现依据是本次保存的原始材料、证据、模型原始响应、检查计划与判断记录；不得用新运行结果覆盖本版本。

判定口径：R/E01–E06 使用 `candidate_issue`、`no_visible_issue`、`insufficient_evidence`、`not_applicable`；G/REQ/E07 使用 `met`、`observed_violation`、`insufficient_evidence`；E08 使用 `open`、`no_conflict`、`needs_clarification`、`resolved`。`complete` 只表示计划项均有处置，不表示问题数为零或运行效果已验证。

## 三、输入材料

| 来源 | 类型/角色 | 版本 | 读取状态 | 证据数 | 入口 |
| --- | --- | --- | --- | ---: | --- |
| `src-3d4c403dc4794d3bab0e79664983aefe` N01-阅读设置 | website / design | N01-v1 | success | 1 | http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html |
| `src-567cbed11f7b459cb152f3c11ef997f3` N01-阅读设置任务要求 | document / product_spec | 冻结任务卡-v1 | success | 1 |  |
| `src-2c868f36de824501a3793adc9019616c` initial_purpose | document / review_instruction | context-1 | success | 1 | user://initial_purpose |

<img src="artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png" alt="N01-阅读设置" style="display:block;max-width:100%;width:640px;height:auto;margin:12px 0;border:1px solid #ddd;border-radius:4px;" loading="lazy">

## 四、T01–T10 逐步输入输出

| 阶段 | 状态 | 输入摘要 | 输出摘要 | 模型调用 | 模型耗时 |
| --- | --- | --- | --- | --- | ---: |
| T01 接收与能力检查 | completed | {'purpose': '本次检查本机演示原型的实际操作。按以下任务卡执行评审：\n任务名称：阅读版面设置与恢复\n材料来源：AI 制作的独立本地交互样本，版本 N01-v1。\n任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。\n初始状态：新开页面，标准字号、紧凑行距、白色背景。\n允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。\n结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。\n验收要求：\nREQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。\nREQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。\nREQ-N01-03 恢复初始后，三个选项及已应用预览共同恢复初… | {'session_id': 'session-d52bfcc6dfc641bc98aeedbcfa8ae1ea', 'capabilities': {'schema_version': 'session-1.0', 'methods_version': '0.2-method-draft', 'technical_path_version': 'A-0.2/T01-T10', 'method_root': 'C:\\Users\\nozomi222333\\Documents\\Codex\\2026-10-02\\wo\\design-research-skill\\docs\\D-最终验收证据\\新样本\\冻结运行源码-修后v1\\方法专家开发交付-v0.2', 'method_validation': {'delivery_version': '0.2-method-draft', 'checked_files': 12… | 无 | 0ms |
| T02 材料读取与证据登记 | completed | {'sources': [{'source_id': 'src-3d4c403dc4794d3bab0e79664983aefe', 'kind': 'website', 'reference': 'http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html', 'role': 'design', 'version': 'N01-v1'}, {'source_id': 'src-567cbed11f7b459cb152f3c11ef997f3', 'kind': 'document', 'reference': '', 'role': 'product_spec… | {'evidence_count': 3, 'evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956', 'ev-230a4d2615a6416087da60291209915d', 'ev-1a3b7f9fd5644fea902767d3c4979deb'], 'source_status': {'src-3d4c403dc4794d3bab0e79664983aefe': 'success', 'src-567cbed11f7b459cb152f3c11ef997f3': 'success', 'src-2c868f36de824501a3793adc9019616c': 'success'}, 'warnings': []} | 无 | 0ms |
| T03 任务与材料理解 | completed | {'evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956', 'ev-230a4d2615a6416087da60291209915d', 'ev-1a3b7f9fd5644fea902767d3c4979deb'], 'context_version': 1} | {'task_summary': '针对 N01-v1 本地演示原型，完成大字号、舒适行距、暖色背景的设置与应用，查看预览，再恢复初始版面并检查结果。本阶段仅整理材料，现有观察仅覆盖初始状态。', 'target_user_summary': '', 'review_tasks': [{'task_id': 'TASK-N01-01', 'text': '将版面设为大字号、舒适行距和暖色背景，应用设置并查看阅读预览。', 'success_criteria': '预览与三个所选设置一致；应用期间和完成后有明确反馈，处理期间避免重复提交。', 'evidence_ids': ['ev-230a4d2615a6416087da60291209915d'], 'source_ids': ['src-567cbed11f7b459cb152f3c11ef997f3'], 'page_ids': [], 'state_ids': [], … | call-b0c0085787344f5bbd3a38c868145352 | 49359ms |
| T04 检查规划与适用性筛选 | completed | {'goal_refs': ['G-N01-01'], 'requirement_refs': ['REQ-N01-01', 'REQ-N01-02', 'REQ-N01-03'], 'evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956', 'ev-230a4d2615a6416087da60291209915d', 'ev-1a3b7f9fd5644fea902767d3c4979deb']} | {'check_count': 46, 'applicability': {'applicable': 28, 'needs_context': 11, 'not_applicable': 7, 'not_assessed': 0}, 'check_refs': ['G-N01-01', 'REQ-N01-01', 'REQ-N01-02', 'REQ-N01-03', 'E07', 'E08', 'R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'G-N01-01… | call-29272ad7b32e47f8a785a1f4b8e6af73, call-8dcad002d7fe45b998b3eaa33d79d944, call-3c80b1eb0dd748b390346a0181f5420e, call-cd9840166256459aa8ef17fad73ee822, call-ee0366040bae4f2aa8f52e477ff8827e | 318016ms |
| T05 执行、取证与逐屏技术审查 | not_needed | {'authorized_interaction': True, 'planned_check_refs': ['G-N01-01', 'REQ-N01-01', 'REQ-N01-02', 'REQ-N01-03', 'E07', 'E08', 'R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'G-N01-01', 'E07', 'E08', … | {'action_count': 0, 'actions': [], 'action_outcomes': [], 'transition_count': 0} | 无 | 0ms |
| T06 逐项判断 | partial | {'check_ids': ['check-f6e3746f2eae53c2', 'check-03904ba98377f6bb', 'check-d5d9038b32288ae3', 'check-c42e58f8a3bad009', 'check-5f6f48046463e9dc', 'check-438f73a166a7318b', 'check-6db0bc25fd4f93d3', 'check-8c650cea2ab94d73', 'check-f8b98719bc4e4a16', 'check-14caa5160427a574', 'check-811e8bb812875c3d', 'check-7ba9e809ec59a1c5', 'check-9b54bc5cb86a177e', 'check-… | {'decisions': {}, 'judgments': [{'check_id': 'check-f6e3746f2eae53c2', 'ref': 'G-N01-01', 'decision': None, 'reason': '用户结束/终止，未完成检查。', 'evidence_ids': []}, {'check_id': 'check-03904ba98377f6bb', 'ref': 'REQ-N01-01', 'decision': None, 'reason': '用户结束/终止，未完成检查。', 'evidence_ids': []}, {'check_id': 'check-d5d9038b32288ae3', 'ref': 'REQ-N01-02', 'decision': None, 'reason': '用户结束/终止，未完成检查。', 'evidence_ids': []}, {'check_i… | 无 | 0ms |
| T07 证据核验与发现归并 | not_needed | {'candidate_finding_count': 0} | {'verified_finding_ids': [], 'rejected': []} | 无 | 0ms |
| T08 讨论、变更与重查 | not_needed | {'context_version': 1, 'events': [{'at': '2026-11-04T12:03:22.246524+00:00', 'actor_type': 'ai', 'actor': 'D 新样本 AI 操作员', 'type': 'purpose', 'content': '本次检查本机演示原型的实际操作。按以下任务卡执行评审：\n任务名称：阅读版面设置与恢复\n材料来源：AI 制作的独立本地交互样本，版本 N01-v1。\n任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。\n初始状态：新开页面，标准字号、紧凑行距、白色背景。\n允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。\n结束条件：完成应用和恢复，并… | {'questions': [], 'conflict_dispositions': []} | 无 | 0ms |
| T09 报告与保存 | completed | {'run_id': 'run-72cb38f9793b46d0a690c3a50e85359f', 'check_count': 46} | {'report_version': 1, 'report_completeness': 'partial', 'status': 'completed'} | 无 | 0ms |
| T10 修改后复审 | not_needed | {'previous_finding_ids': []} | {'rechecks': []} | 无 | 0ms |

```mermaid
flowchart LR
    T01["T01 接收与能力检查<br/>completed"]
    T02["T02 材料读取与证据登记<br/>completed"]
    T03["T03 任务与材料理解<br/>completed"]
    T04["T04 检查规划与适用性筛选<br/>completed"]
    T05["T05 执行、取证与逐屏技术审查<br/>not_needed"]
    T06["T06 逐项判断<br/>partial"]
    T07["T07 证据核验与发现归并<br/>not_needed"]
    T08["T08 讨论、变更与重查<br/>not_needed"]
    T09["T09 报告与保存<br/>completed"]
    T10["T10 修改后复审<br/>not_needed"]
    T01 --> T02
    T02 --> T03
    T03 --> T04
    T04 --> T05
    T05 --> T06
    T06 --> T07
    T07 --> T08
    T08 --> T09
    T09 --> T10
```


### T01 · 接收与能力检查

- 状态：`completed`
- 输入：评审目的 1 条；来源 3 项
- 输出：契约 session-1.0；方法 0.2-method-draft；R=24；E=8
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T02 · 材料读取与证据登记

- 状态：`completed`
- 输入：来源 3 项
- 输出：证据 3 条；来源状态 读取成功=3
- 模型调用：无
- 模型耗时：0ms
- 关联证据：ev-ff29fd5c1dc24b78982d6ecec63f3956, ev-230a4d2615a6416087da60291209915d, ev-1a3b7f9fd5644fea902767d3c4979deb

### T03 · 任务与材料理解

- 状态：`completed`
- 输入：用于理解的材料证据 3 条
- 输出：目标 1；要求 3；意见 0；冲突 0；未知 4
- 模型调用：call-b0c0085787344f5bbd3a38c868145352
- 模型耗时：49359ms
- 关联证据：ev-ff29fd5c1dc24b78982d6ecec63f3956, ev-230a4d2615a6416087da60291209915d, ev-1a3b7f9fd5644fea902767d3c4979deb

### T04 · 检查规划与适用性筛选

- 状态：`completed`
- 输入：目标 1；要求 3；可用证据 3
- 输出：检查 46 项；不适用=7；待补上下文=11；未评估=0；适用=28
- 模型调用：call-29272ad7b32e47f8a785a1f4b8e6af73, call-8dcad002d7fe45b998b3eaa33d79d944, call-3c80b1eb0dd748b390346a0181f5420e, call-cd9840166256459aa8ef17fad73ee822, call-ee0366040bae4f2aa8f52e477ff8827e
- 模型耗时：318016ms
- 关联证据：ev-ff29fd5c1dc24b78982d6ecec63f3956, ev-230a4d2615a6416087da60291209915d, ev-1a3b7f9fd5644fea902767d3c4979deb

### T05 · 执行、取证与逐屏技术审查

- 状态：`not_needed`
- 输入：交互授权 是；计划检查 46
- 输出：动作 0；状态变化 0；结果 无
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T06 · 逐项判断

- 状态：`partial`
- 输入：检查 46；计划证据 3
- 输出：无
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T07 · 证据核验与发现归并

- 状态：`not_needed`
- 输入：候选发现 0
- 输出：通过核验 0；退回 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T08 · 讨论、变更与重查

- 状态：`not_needed`
- 输入：上下文版本 1
- 输出：问题 0；业务决定 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T09 · 报告与保存

- 状态：`completed`
- 输入：运行 run-72cb38f9793b46d0a690c3a50e85359f；检查 46
- 输出：报告 v1；完整性 部分；状态 已完成
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T10 · 修改后复审

- 状态：`not_needed`
- 输入：旧问题 0
- 输出：复审记录 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

## 五、目标要求对应与材料理解

- 任务理解：针对 N01-v1 本地演示原型，完成大字号、舒适行距、暖色背景的设置与应用，查看预览，再恢复初始版面并检查结果。本阶段仅整理材料，现有观察仅覆盖初始状态。
- 目标用户：未明确
- `G-N01-01` G：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。；来源 ev-230a4d2615a6416087da60291209915d
  - 原文 `ev-230a4d2615a6416087da60291209915d`：任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。
- `REQ-N01-01` REQ：应用后的阅读预览与用户所选字号、行距、背景一致。；来源 ev-230a4d2615a6416087da60291209915d
  - 原文 `ev-230a4d2615a6416087da60291209915d`：REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。
- `REQ-N01-02` REQ：应用期间和完成后有明确状态反馈，处理期间避免重复提交。；来源 ev-230a4d2615a6416087da60291209915d
  - 原文 `ev-230a4d2615a6416087da60291209915d`：REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。
- `REQ-N01-03` REQ：恢复初始后，三个选项及已应用预览共同恢复为标准字号、紧凑行距、白色背景。；来源 ev-230a4d2615a6416087da60291209915d
  - 原文 `ev-230a4d2615a6416087da60291209915d`：REQ-N01-03 恢复初始后，三个选项及已应用预览共同恢复初始值。
  - 原文 `ev-230a4d2615a6416087da60291209915d`：初始状态：新开页面，标准字号、紧凑行距、白色背景。
- 未知：未提供目标用户、任务必要性及用户熟悉度，不能据此判断特定用户的学习或使用负担。
- 未知：现有截图 ev-ff29fd5c1dc24b78982d6ecec63f3956 仅显示初始选项、初始预览及“当前使用初始版面”；缺少选择、应用期间、应用完成和恢复后的实际操作证据，尚不能判断 REQ-N01-01 至 REQ-N01-03 是否满足。
- 未知：任务卡未规定大字号、舒适行距、暖色背景的具体数值，也未规定反馈时限或防重复提交的具体实现方式；不得自行补为正式阈值。
- 未知：材料明确的是本地样本任务目标与验收条件，未提供更广泛的产品业务目的、实现代码或专家意见。

### 已观察状态与动作迁移

| 状态 | 来源 | 定位 | 入/出 | 已接入检查 |
| --- | --- | --- | ---: | --- |
| `b4b55ae03f67bcd1bd7bcbe0` | src-3d4c403dc4794d3bab0e79664983aefe | URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知 | 0/0 | 否 |

### 必需覆盖矩阵

| 覆盖单元 | 任务 | 状态 | 来源 | 已覆盖 | 缺证类型 |
| --- | --- | --- | --- | --- | --- |
| `coverage-8feebfcf352e8f36` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-c7e6550b1db32aa6` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-73ad4f0bbd4edd0f` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-28561631ef5c1943` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-49e1191f85849c7e` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-01e61b924e816181` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-17aa00f5052f7bd3` | TASK-N01-01 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | task_not_planned |
| `coverage-c969c3aabdc2c39e` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-35d643f1d1e726c8` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-815d8fd735d23a2f` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-a2d15a3fbad574f7` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-b1e90fc023928f17` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-1330b3666dd938a0` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | unobserved_branch |
| `coverage-b8612a8630caf22a` | TASK-N01-02 | 任务级 | src-567cbed11f7b459cb152f3c11ef997f3 | 否 | task_not_planned |

## 六、证据链总表

| 证据 | 来源 / 类型 | 版本 | 定位 | 内容摘要 | 被哪些检查/发现使用 |
| --- | --- | --- | --- | --- | --- |
| `ev-ff29fd5c1dc24b78982d6ecec63f3956` | src-3d4c403dc4794d3bab0e79664983aefe / observation | N01-v1 | URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知 | 阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效 | G-N01-01, REQ-N01-01, REQ-N01-02, REQ-N01-03, E07, R01, R02, R03, R04, R05, R06, R07, R08, R09, R10, R11, R12, R13, R14, R16, R17, R18, R19, R20, R21, R22, R23, R24, E01, E02, E03, E04, E05, E06, G-N01-01, E07, R04, R06, R17, R19, E01, E02, E03 |
| `ev-230a4d2615a6416087da60291209915d` | src-567cbed11f7b459cb152f3c11ef997f3 / requirement | 冻结任务卡-v1 | 文档分块 0/1；行 1-11；字符 0-352 | 任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ-N01-03 恢复初始后，三个选项及已… | G-N01-01, REQ-N01-01, REQ-N01-02, REQ-N01-03, E07, E08, R01, R02, R03, R04, R05, R06, R07, R08, R09, R10, R13, R15, R17, R18, R19, R20, R21, R22, R23, R24, E01, E02, E03, E04, E05, E06, G-N01-01, E07, E08, R04, R06, R17, R19, E01, E02, E03 |
| `ev-1a3b7f9fd5644fea902767d3c4979deb` | src-2c868f36de824501a3793adc9019616c / statement | context-1 | 文档分块 0/1；行 1-12；字符 0-380 | 本次检查本机演示原型的实际操作。按以下任务卡执行评审：  
任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重… | E08, E08 |

## 七、逐项检查与判断

| 编号 | 类型 | 适用性 | 执行 | 判断 | 证据 | 发现 |
| --- | --- | --- | --- | --- | --- | --- |
| `G-N01-01` 将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。 | goal | applicable | not_executed | — | 无 | 无 |
| `REQ-N01-01` 应用后的阅读预览与用户所选字号、行距、背景一致。 | goal | applicable | not_executed | — | 无 | 无 |
| `REQ-N01-02` 应用期间和完成后有明确状态反馈，处理期间避免重复提交。 | goal | applicable | not_executed | — | 无 | 无 |
| `REQ-N01-03` 恢复初始后，三个选项及已应用预览共同恢复为标准字号、紧凑行距、白色背景。 | goal | applicable | not_executed | — | 无 | 无 |
| `E07` 目标与明确要求落实 | goal | applicable | not_executed | — | 无 | 无 |
| `E08` 跨职能要求冲突识别与处理 | conflict | applicable | not_executed | — | 无 | 无 |
| `R01` 当前导航位置可见 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R02` 多步骤任务显示当前步骤 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R03` 等待状态说明系统正在做什么 | rule | needs_context | not_executed | — | 无 | 无 |
| `R04` 完成状态说清结果 | rule | needs_context | not_executed | — | 无 | 无 |
| `R05` 关键文案避免未解释的内部术语 | rule | needs_context | not_executed | — | 无 | 无 |
| `R06` 操作名称说明预期结果 | rule | applicable | not_executed | — | 无 | 无 |
| `R07` 输入项名称说明所需信息 | rule | applicable | not_executed | — | 无 | 无 |
| `R08` 弹窗具有可见退出方式 | rule | needs_context | not_executed | — | 无 | 无 |
| `R09` 多步骤页面具有可见返回方式 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R10` 确认页允许取消高风险操作 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R11` 同一动作使用一致名称 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R12` 同类控件呈现一致的视觉规则 | rule | applicable | not_executed | — | 无 | 无 |
| `R13` 必填项在填写前可识别 | rule | needs_context | not_executed | — | 无 | 无 |
| `R14` 受格式限制的字段提供输入提示 | rule | applicable | not_executed | — | 无 | 无 |
| `R15` 高后果操作确认页说明对象和动作 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R16` 重要图标操作具有可见含义线索 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R17` 当前选择状态可见 | rule | applicable | not_executed | — | 无 | 无 |
| `R18` 相关输入和选项形成可识别的组 | rule | applicable | not_executed | — | 无 | 无 |
| `R19` 主要任务操作易于定位 | rule | applicable | not_executed | — | 无 | 无 |
| `R20` 无关信息不压过主要任务 | rule | applicable | not_executed | — | 无 | 无 |
| `R21` 错误状态指明问题位置 | rule | needs_context | not_executed | — | 无 | 无 |
| `R22` 错误提示给出修正办法 | rule | needs_context | not_executed | — | 无 | 无 |
| `R23` 错误提示使用用户可理解的语言 | rule | needs_context | not_executed | — | 无 | 无 |
| `R24` 复杂任务提供就近帮助入口 | rule | needs_context | not_executed | — | 无 | 无 |
| `E01` 关键任务路径衔接 | method | applicable | not_executed | — | 无 | 无 |
| `E02` 跨页面对象与信息一致性 | method | applicable | not_executed | — | 无 | 无 |
| `E03` 操作与反馈状态对应 | method | applicable | not_executed | — | 无 | 无 |
| `E04` 返回取消后的任务恢复 | method | applicable | not_executed | — | 无 | 无 |
| `E05` 异常分支与恢复路径 | method | needs_context | not_executed | — | 无 | 无 |
| `E06` 前置条件与操作开放状态 | method | applicable | not_executed | — | 无 | 无 |
| `G-N01-01` 将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。 | goal | applicable | not_executed | — | 无 | 无 |
| `E07` 目标与明确要求落实 | goal | applicable | not_executed | — | 无 | 无 |
| `E08` 跨职能要求冲突识别与处理 | conflict | applicable | not_executed | — | 无 | 无 |
| `R04` 完成状态说清结果 | rule | needs_context | not_executed | — | 无 | 无 |
| `R06` 操作名称说明预期结果 | rule | applicable | not_executed | — | 无 | 无 |
| `R17` 当前选择状态可见 | rule | applicable | not_executed | — | 无 | 无 |
| `R19` 主要任务操作易于定位 | rule | applicable | not_executed | — | 无 | 无 |
| `E01` 关键任务路径衔接 | method | applicable | not_executed | — | 无 | 无 |
| `E02` 跨页面对象与信息一致性 | method | applicable | not_executed | — | 无 | 无 |
| `E03` 操作与反馈状态对应 | method | applicable | not_executed | — | 无 | 无 |

### G-N01-01 · 将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。

- 检查 ID / 类型：`check-f6e3746f2eae53c2` / goal
- 计划：applicable；任务卡明确要求设置并应用三个选项；当前仅有初始状态，需检查实际路径和结果。
- 对象：['文字大小', '段落行距', '使用暖色背景', '应用设置', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['三个选项改为目标值后的观察', '应用动作、处理过程和完成后的预览']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### REQ-N01-01 · 应用后的阅读预览与用户所选字号、行距、背景一致。

- 检查 ID / 类型：`check-03904ba98377f6bb` / goal
- 计划：applicable；要求明确约束应用后预览；需同时核对实际字号、行距和背景，不能只看已应用说明。
- 对象：['文字大小', '段落行距', '使用暖色背景', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['应用前目标选项的实际取值', '应用后预览与初始预览的对照；不自行规定数值阈值']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### REQ-N01-02 · 应用期间和完成后有明确状态反馈，处理期间避免重复提交。

- 检查 ID / 类型：`check-d5d9038b32288ae3` / goal
- 计划：applicable；任务卡明确要求处理反馈及防重复提交；初始按钮可用不能说明处理期间的行为。
- 对象：['应用设置', '状态反馈区域']
- 必需证据类型：['requirement', 'observation']
- 缺项：['应用触发后处理期间的状态反馈', '处理期间按钮状态或重复提交被阻止的观察', '完成后的明确反馈；不自行规定反馈时限']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### REQ-N01-03 · 恢复初始后，三个选项及已应用预览共同恢复为标准字号、紧凑行距、白色背景。

- 检查 ID / 类型：`check-c42e58f8a3bad009` / goal
- 计划：applicable；要求三个选项及已应用预览共同恢复；必须从已应用目标版面执行恢复后核对。
- 对象：['恢复初始', '文字大小', '段落行距', '使用暖色背景', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['恢复前已应用大字号、舒适行距和暖色背景的观察', '恢复后选项为标准字号、紧凑行距、背景未勾选', '恢复后实际预览及已应用说明与初始状态对照']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-5f6f48046463e9dc` / goal
- 计划：applicable；存在有原文支持的目标及两项应用要求；分别核对预览、过程反馈和完成反馈，再汇总。
- 对象：['阅读设置页面', '应用设置', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['选项改变及应用后的实际预览', '应用期间反馈、防重复提交和完成反馈的观察']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E08 · 跨职能要求冲突识别与处理

- 检查 ID / 类型：`check-438f73a166a7318b` / conflict
- 计划：applicable；任务卡与委托对同一版本有可比陈述；计划核对能否同时满足，界面偏差不自动等于要求冲突。
- 对象：['N01-阅读设置任务要求', 'initial_purpose']
- 必需证据类型：['requirement', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：跨职能要求冲突识别与处理；对象：策划/产品、设计、开发材料或用户决定对同一对象的要求与限制。；适用：两项以上要求/约束指向同一对象，可能无法同时满足或存在证据描述矛盾。；触发：原文可定位且同范围，两项要求无法同时成立。输出conflict记录，不未经裁决转换为产品违规。已裁决正式要求被实现违反时转E07。；弃权：同一对象或版本关系未知则待澄清；只有单份要求、或解释后可同时满足则不构成冲突。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-1a3b7f9fd5644fea902767d3c4979deb` / statement / 来源 `src-2c868f36de824501a3793adc9019616c` / 版本 context-1
  - 定位：文档分块 0/1；行 1-12；字符 0-380
  - 内容：本次检查本机演示原型的实际操作。按以下任务卡执行评审：  
任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期…
  - 原始记录：[`artifact-6e900814708c4f98820b0fe8f9ffa7a2`](artifacts/ev-1a3b7f9fd5644fea902767d3c4979deb-artifact-6e900814708c4f98820b0fe8f9ffa7a2.txt)
  - 原始文件：[`artifact-295284782ee44182b63f34c0c3ad159f`](artifacts/ev-1a3b7f9fd5644fea902767d3c4979deb-artifact-295284782ee44182b63f34c0c3ad159f.txt)

### R01 · 当前导航位置可见

- 检查 ID / 类型：`check-6db0bc25fd4f93d3` / rule
- 计划：not_applicable；任务卡明确独立本地单页样本，完整初始页面为设置与预览，无页面级导航；下拉选择不属于导航。
- 对象：['阅读设置页面']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：当前导航位置可见；适用：已确认当前页面且存在页面级导航。页面内筛选/单选交由R17。；检查：记录当前页面依据，比较页面级导航项及当前项标识；运行模式分别记录跳转前后导航。；触发：页面级导航及当前页面已知，可完整查看相关导航，但当前项无可辨选中标识或标识与当前页面冲突。；弃权：已知是无页面级导航的入口页时不适用；当前页面身份不明、导航被裁切或目标未加载完整时证据不足。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R02 · 多步骤任务显示当前步骤

- 检查 ID / 类型：`check-8c650cea2ab94d73` / rule
- 计划：not_applicable；材料明确这是独立单页内的设置操作，无分步页面流程；连续操作本身不构成需要步骤标识的流程。
- 对象：['阅读设置页面']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：多步骤任务显示当前步骤；适用：已由流程说明或实际路径确认是多步骤任务，当前页属于其中一步。；检查：记录步骤关系、当前步骤与可见进度线索，结合标题和上下文判断当前环节是否可辨。；触发：多步骤与当前位置已确认，但相关区域完整可查时仍无法从标题、进度或上下文辨认当前环节。；弃权：已确认独立单页时不适用；仅见一页且无法确认步骤关系，或进度区域未取得时证据不足。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R03 · 等待状态说明系统正在做什么

- 检查 ID / 类型：`check-f8b98719bc4e4a16` / rule
- 计划：needs_context；本条以已呈现等待状态为条件；现有观察仅为初始状态，尚不知应用是否出现等待。
- 对象：['应用设置按钮及其下方状态区域']
- 必需证据类型：['observation']
- 缺项：['应用触发动作及随后状态', '若出现等待，记录完整反馈区域、处理对象和观察时长']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：等待状态说明系统正在做什么；适用：当前取得的画面已经呈现加载、上传或处理中等等待状态；可来自截图、原型或运行记录。；检查：记录等待对象、可见文案与进度线索；运行时记录触发动作、观察时长及前后状态。；触发：已确认处于等待，完整相关区域仅有无法解释的转圈/空白，结合上下文仍不能判断正在处理的任务。；弃权：已确认普通非等待状态时不适用；无法确认等待状态、区域不全或动作结果未取得时证据不足；不能由点击前截图推断无反馈。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R04 · 完成状态说清结果

- 检查 ID / 类型：`check-14caa5160427a574` / rule
- 计划：needs_context；需确认一次应用完成后检查结果表达；初始页的“已应用”说明不能证明目标版面已应用完成。
- 对象：['应用设置按钮、状态区域及阅读预览']
- 必需证据类型：['observation']
- 缺项：['应用动作与完成状态的关联证据', '完成后的状态文案及预览说明']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：完成状态说清结果；适用：已取得某次操作完成/成功状态，完成对象与上下文可确认。；检查：检查成功表达是否能说明已完成的动作、对象及确有必要的后续操作。；触发：完成状态已确认，但只有泛化成功信息，结合上下文仍无法判断完成了什么，或遗漏任务必需的下一步线索。；弃权：明确非完成状态时不适用；只有完成前画面、对象不明或结果区域缺失时证据不足；没有后续任务不要求强加下一步。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R05 · 关键文案避免未解释的内部术语

- 检查 ID / 类型：`check-811e8bb812875c3d` / rule
- 计划：needs_context；页面有设置文案，但目标用户、专业程度及熟悉度未知，不能据常识认定术语理解障碍。
- 对象：['文字大小、段落行距及背景设置文案']
- 必需证据类型：['statement', 'observation']
- 缺项：['目标用户及专业程度依据', '若存在疑似内部术语，提供含义与任务必要性依据', '对应用户的熟悉度或理解证据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：关键文案避免未解释的内部术语；适用：已确认非领域专家用户，存在非错误状态的关键任务文案；错误文案转R23。；检查：逐词记录任务必要性、内部术语含义来源、目标用户熟悉度依据与可见解释；词表只能证明含义，不能证明熟悉度。；触发：有依据确认非专家完成主任务必须理解某内部术语，该用户群不熟悉该词，界面又未解释。；弃权：明确没有相关对象或目标用户为领域专家时不适用；用户、含义、必要性或熟悉度影响结论却未知时证据不足。已解释/有熟悉依据时不能报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R06 · 操作名称说明预期结果

- 检查 ID / 类型：`check-7ba9e809ec59a1c5` / rule
- 计划：applicable；任务明确要求应用设置；初始截图完整呈现“应用设置”按钮、三个选项及邻近预览，可检查名称含义。
- 对象：['应用设置按钮及邻近设置内容']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：操作名称说明预期结果；适用：当前状态有主要按钮/入口，用户任务和动作目的已知。；检查：核对按钮文字、邻近内容与预期动作；运行结果可用于确认动作，但不能替代文案清晰度检查。；触发：主要按钮使用泛词或含义不符，结合邻近说明仍不能理解预期结果，或与明确动作目的冲突。；弃权：无主操作对象时不适用；任务/动作目的不明或上下文缺失时证据不足；周围内容已清楚说明时，泛词本身不构成问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R07 · 输入项名称说明所需信息

- 检查 ID / 类型：`check-9b54bc5cb86a177e` / rule
- 计划：applicable；任务需要操作字号、行距和背景字段；初始标签可见，选择后名称是否持续可获取仍需观察。
- 对象：['文字大小选择框', '段落行距选择框', '使用暖色背景复选框']
- 必需证据类型：['requirement', 'observation']
- 缺项：['选择大字号、舒适行距并勾选暖色背景后的字段画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：输入项名称说明所需信息；适用：存在需要填写的重要表单字段，字段任务可确认。；检查：核对字段名称与紧邻说明；运行时分别查看输入前后，确认必要名称线索是否仍可获取。；触发：字段无名称或名称模糊，结合邻近内容仍无法知道应填什么；运行证据显示输入后唯一必要说明消失并产生含义不明。；弃权：无输入对象时不适用；字段说明区域裁切、业务含义未知或未取得输入后画面时，对相应判断记证据不足。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R08 · 弹窗具有可见退出方式

- 检查 ID / 类型：`check-dd1b2d8b82a8fdca` / rule
- 计划：needs_context；初始页未呈现弹窗，但尚无应用后的画面，不能据此认定路径中不存在普通弹窗。
- 对象：['阅读设置页面及应用设置入口']
- 必需证据类型：['observation']
- 缺项：['应用路径的后续状态', '若出现普通弹窗，提供完整边界及可中断性质依据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：弹窗具有可见退出方式；适用：存在普通信息/输入弹窗，完整边界可取得；高风险确认归R10。；检查：检查可见关闭/取消/返回方式；只有实际执行后才描述是否成功退出，行为验证转E01/E04。；触发：普通可中断弹窗占据焦点，完整边界和相关说明可查，但没有任何可见退出方式。；弃权：高风险确认或已确认不可中断流程不适用；边缘被裁、弹窗性质不明时证据不足。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R09 · 多步骤页面具有可见返回方式

- 检查 ID / 类型：`check-cd008d8c7b115bf0` / rule
- 计划：not_applicable；材料明确为独立本地样本的新开初始页面，并非已确认的多步骤任务非首步，不满足本条条件。
- 对象：['阅读设置初始页面']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：多步骤页面具有可见返回方式；适用：确认当前是多步骤任务非首步，且不是高风险确认页。；检查：检查可见返回/退出入口，说明系统/浏览器返回是否在本次观察范围内；执行结果交E01/E04。；触发：当前非首步已确认且相关区域完整，页面与可观察系统入口均无可见返回或退出方式。；弃权：已确认首步/独立页或高风险确认时不适用；步骤未知、系统导航未涵盖且可能承担功能、页面不全时证据不足。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R10 · 确认页允许取消高风险操作

- 检查 ID / 类型：`check-6984c9f7ca1ba527` / rule
- 计划：not_applicable；任务卡限定为当前本地页面的版面设置与恢复，可重新设置；该操作不属于已确认的高风险操作确认界面。
- 对象：['恢复初始按钮及本地页面作用范围说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：确认页允许取消高风险操作；适用：已确认删除/清空/永久变更等高风险操作的确认界面。；检查：检查清楚可见的取消/返回入口；默认仅观察，不为验证本条而执行真实危险操作。；触发：高风险性质已确认，确认区域完整且仅能执行，没有可见取消/返回入口。；弃权：明确非高风险确认时不适用；风险性质未知或取消区未取得时证据不足；无授权不执行真实副作用。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R11 · 同一动作使用一致名称

- 检查 ID / 类型：`check-76638df410bd795d` / rule
- 计划：not_applicable；完整初始页面中，应用设置与恢复初始各有一个入口，且是不同动作；不存在两个明确指向同一动作的入口。
- 对象：['应用设置', '恢复初始']
- 必需证据类型：['observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：同一动作使用一致名称；适用：在同一材料或已确认的同版本多页面中，至少两个入口明确指向同一动作。；检查：记录动作同一性的依据，比较入口名称与解释；不同对象的名称差异不据此判动作不一致。；触发：已证实同一动作、同一语境使用互相矛盾或无解释的不同名称。；弃权：仅一个相关入口时不适用；动作是否相同、版本或语境未知时证据不足；功能/对象/阶段确有差异且名称合理时未见问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R12 · 同类控件呈现一致的视觉规则

- 检查 ID / 类型：`check-8f8301f9e84b74f1` / rule
- 计划：applicable；字号与行距均为同一设置区域内已启用的下拉选择控件，可比较视觉规则；应用与恢复按钮的主次差异须结合功能解释。
- 对象：['文字大小', '段落行距']
- 必需证据类型：['observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：同类控件呈现一致的视觉规则；适用：存在至少两个功能、层级、状态和设计语境可比的控件，可跨同版本页面。；检查：先核对可比条件，再比较形状、颜色、文字、状态表达，记录差异造成的类别/状态歧义。；触发：同类同状态控件存在无解释的显著规则差异，具体导致操作类别或状态含义混淆。；弃权：只有一个可比对象时不适用；控件层级/状态/规范依据未知时证据不足；有明确状态或主题理由的差异不报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R13 · 必填项在填写前可识别

- 检查 ID / 类型：`check-2295551c5285385b` / rule
- 计划：needs_context；任务卡规定目标设置，但未说明字段是否具有必填校验要求；不能把完成任务所需的选择直接视为必填字段。
- 对象：['文字大小', '段落行距', '使用暖色背景']
- 必需证据类型：['requirement', 'observation']
- 缺项：['字段是否存在必填要求及其来源']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：必填项在填写前可识别；适用：存在已知必填要求的表单字段；要求有来源。；检查：在填写前查看字段标记和整体说明，与已确认必填清单对照。；触发：已知必填字段既无字段标记也无清楚整体说明，提交前无法辨认必填要求。；弃权：明确无必填字段时不适用；哪些必填未知时证据不足；全部必填且有整体说明时未见问题。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R14 · 受格式限制的字段提供输入提示

- 检查 ID / 类型：`check-89325b35890a79a3` / rule
- 计划：applicable；观察记录确认两个下拉框各有两个有效选项，可检查字段名和选项是否清楚表达可选值；不自行补充数值限制。
- 对象：['文字大小', '段落行距']
- 必需证据类型：['observation']
- 缺项：['展开两个下拉框时的可见选项证据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：受格式限制的字段提供输入提示；适用：字段有已确认的格式、长度或有效值限制。；检查：对照限制来源，查看填写前可获得的字段名、提示与有效示例。；触发：限制已知，但填写前无可理解线索，用户必须猜测要求；或提示与已确认限制冲突。；弃权：确认无特定格式限制时不适用；限制未知或提示区域不可查时证据不足；有效示例已清楚表达时未见问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R15 · 高后果操作确认页说明对象和动作

- 检查 ID / 类型：`check-fa46ac4255488b15` / rule
- 计划：not_applicable；任务卡明确操作仅影响本地页面，操作对象为可恢复的阅读版面；没有对象损失、不可逆或其他高后果确认对象。
- 对象：['应用设置', '恢复初始']
- 必需证据类型：['requirement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：高后果操作确认页说明对象和动作；适用：已确认是后果较大的操作确认界面，动作、对象及必要后果要求可确定。；检查：检查确认文字与邻近内容能否支持核对动作、对象和必要后果。；触发：完整上下文仍只有泛化确认，无法核对具体对象/动作，或遗漏已明确会影响决定的后果。；弃权：确认不是高后果确认时不适用；后果、对象未知或说明裁切时证据不足；无需为观察而实际执行危险动作。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R16 · 重要图标操作具有可见含义线索

- 检查 ID / 类型：`check-9e15f2586e6caa67` / rule
- 计划：not_applicable；完整页面及控件记录显示主任务通过带文字标签的下拉框、复选框和按钮完成；下拉箭头是控件附属线索，无独立重要图标操作。
- 对象：['文字大小', '段落行距', '使用暖色背景', '应用设置']
- 必需证据类型：['observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：重要图标操作具有可见含义线索；适用：有影响已知主任务的图标操作，目标用户和任务语境可确定。；检查：检查文字标签、邻近解释及有依据的通用含义；必要时查看可取得的悬停/聚焦说明，并注明设备条件。；触发：任务必需的自定义图标没有可见说明，且有依据表明其含义在本语境中不可辨认。；弃权：无重要图标对象时不适用；重要性或用户熟悉度影响结论但未知、辅助说明未取得时证据不足；不因无常驻文字自动报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-c8b4d1cdcccad512` / rule
- 计划：applicable；观察记录确认字号和行距已有选中值、暖色背景未勾选；需核对初始及变更后的可见状态，不以点击本身证明已选。
- 对象：['文字大小', '段落行距', '使用暖色背景']
- 必需证据类型：['observation']
- 缺项：['选择大字号、舒适行距和暖色背景后的控件状态与画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R18 · 相关输入和选项形成可识别的组

- 检查 ID / 类型：`check-5d8a2aee3cbe3978` / rule
- 计划：applicable；控件记录确认两个下拉框与一个复选框具有选择角色，任务卡确认三者共同设置阅读版面；预览为展示对象，需检查其与设置组的边界。
- 对象：['设置阅读版面区域', '文字大小', '段落行距', '使用暖色背景', '阅读预览区域']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：相关输入和选项形成可识别的组；适用：已确认存在多个相关输入字段或成组选项，业务分组关系已知；纯展示卡不纳入。；检查：逐项记录输入/可选/纯展示角色及其证据，核对关系来源，再检查组标题、间距与边界。；触发：输入/选择角色和分组关系已确认，相关与无关项混排，造成具体归属歧义。；弃权：确认仅纯展示、单个字段或单个选项时不适用；交互角色或分组关系未知、相关区域不全时证据不足。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R19 · 主要任务操作易于定位

- 检查 ID / 类型：`check-5812126c0106e5e6` / rule
- 计划：applicable；任务卡明确主操作，初始截图完整呈现设置区及应用按钮，可检查位置、遮挡与层级；不推定用户实际识别表现。
- 对象：['文字大小', '段落行距', '使用暖色背景', '应用设置']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：主要任务操作易于定位；适用：已确认主任务及对应主操作，取得其所在区域和必要上下文。；检查：记录主操作、竞争元素、位置/遮挡/层级关系；计算显著性只作线索，真人识别另行验证。；触发：有具体可见证据表明主操作被遮挡、与任务脱离或层级混淆，难以从当前界面定位。；弃权：确认无本条操作对象时不适用；主任务未知、区域未取得或仅有代理分值时证据不足；不能因按钮不最大而直接报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R20 · 无关信息不压过主要任务

- 检查 ID / 类型：`check-7a8718b4caf82279` / rule
- 计划：applicable；主任务明确，截图包含设置、预览、状态和页脚，可比较辅助信息是否挤占或遮挡任务内容，不以像素代理代替理解证据。
- 对象：['阅读设置页：设置区、阅读预览、状态说明与页脚']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：无关信息不压过主要任务；适用：主任务及内容相关性有依据，主要内容与竞争区域可取得。；检查：比较任务内容和装饰/推广/重复信息，说明具体干扰机制；高饱和或元素多不单独构成违反。；触发：有依据确认无关内容明显压制、遮挡或挤占关键任务内容，并指出具体区域与影响。；弃权：无相关比较对象时不适用；任务相关性未知或区域不全时证据不足；目标需要的角色展示/奖励说明不能仅凭面积大判无关。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R21 · 错误状态指明问题位置

- 检查 ID / 类型：`check-94de0d56d48a18c8` / rule
- 计划：needs_context；现有证据仅覆盖初始状态，未确认任务中是否出现错误及其范围；不能由初始画面无错误提示推断全程不适用。
- 对象：['应用设置及其反馈区域']
- 必需证据类型：['observation']
- 缺项：['实际任务中的错误状态或无错误过程记录', '若出现错误，取得完整提示及相关操作区域']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：错误状态指明问题位置；适用：已取得明确错误状态及其相关任务/操作范围。；检查：查看错误提示与字段/操作关联，记录错误原文和位置；多错误逐项检查。；触发：错误状态已确认，相关区域完整却只有笼统提示，无法辨别应处理的字段或操作。；弃权：确认不是错误状态时不适用；错误范围在未取得区域或状态性质未知时证据不足；只缺字段高亮但提示已清楚定位时不报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R22 · 错误提示给出修正办法

- 检查 ID / 类型：`check-a02c63e7a7a8c450` / rule
- 计划：needs_context；尚无已确认错误，也无可修正性依据；需先确认错误和用户可执行处理，再检查提示及关联恢复入口。
- 对象：['应用设置及其反馈区域']
- 必需证据类型：['observation', 'statement']
- 缺项：['错误完整提示与关联帮助内容', '用户可执行修正途径的依据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：错误提示给出修正办法；适用：已确认错误状态，且存在用户可以执行的修正或后续处理。；检查：检查当前提示和明确关联的帮助/恢复入口，核对建议步骤是否可执行；执行结果由E05记录。；触发：错误及可行修正途径已知，但当前信息没有可执行线索，或所给线索与已确认处理方法冲突。；弃权：确认无用户可执行处理时本条不适用；可修正性未知或帮助入口内容未取得时证据不足；已有明确关联修正说明时未见问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R23 · 错误提示使用用户可理解的语言

- 检查 ID / 类型：`check-b53c7af752e9cf61` / rule
- 计划：needs_context；尚未取得错误提示，目标用户背景也未提供；无法确定适用对象及技术术语是否妨碍理解。
- 对象：['应用设置及其反馈区域']
- 必需证据类型：['observation', 'statement']
- 缺项：['实际出现的完整错误提示', '影响错误理解的目标用户背景']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：错误提示使用用户可理解的语言；适用：存在面向已知目标用户的错误提示。；检查：记录错误原文，结合已知用户背景检查是否有可理解说明；技术码可作为辅助。；触发：面向非技术用户的错误信息只有内部码/异常栈/开发术语，且无可理解解释。；弃权：无错误提示对象时不适用；用户背景影响理解却未知、文字不清时证据不足；技术码同时附清楚说明或目标开发者确可理解时未见问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R24 · 复杂任务提供就近帮助入口

- 检查 ID / 类型：`check-ecdf00a123171695` / rule
- 计划：needs_context；任务和字段已知，但用户知识及必须解释的复杂步骤未确认；不能仅凭控件简单或没有帮助图标判定适用性。
- 对象：['文字大小', '段落行距', '使用暖色背景']
- 必需证据类型：['statement', 'observation']
- 缺项：['目标用户知识与解释需要的依据', '若确认需要解释，取得相关说明或帮助内容']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：复杂任务提供就近帮助入口；适用：已确认目标用户在某关键复杂/领域字段或步骤上需要解释才能完成任务。；检查：记录复杂性与用户需要的依据，查看邻近说明/示例/帮助入口及实际取得内容。；触发：解释需要已确认，当前可查范围既无可理解说明，也无清楚关联且可取得的帮助，必须脱离任务自行猜测含义。；弃权：确认无需要解释的对象时不适用；解释需要、用户知识或帮助内容未知时证据不足；专家也可能需特定业务解释，不自动排除。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E01 · 关键任务路径衔接

- 检查 ID / 类型：`check-5367530b133aa5b5` / method
- 计划：applicable；任务卡明确选择、应用和查看预览的跨状态路径；入口已取得，但没有动作及前后证据，不能判定路径完成。
- 对象：['文字大小', '段落行距', '使用暖色背景', '应用设置', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['三项选择后的控件及预览画面', '应用动作、处理期间反馈与重复提交防护记录', '应用完成后的预览和状态反馈']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：关键任务路径衔接；对象：任务起点、动作入口、目标页面/状态和已声明终点。；适用：存在需要跨页或跨状态的任务，关系可由已确认要求、原型连接或实际路径建立。；触发：目标关系明确且入口条件满足，本次操作到达错误对象、陷入可复现死路或无法抵达明确必需的下一步，且已排除访问/工具阻断。；弃权：关系或目标未知、权限失败、工具未执行、原型未实现分支时证据不足；明确独立静态任务无连接对象时不适用。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E02 · 跨页面对象与信息一致性

- 检查 ID / 类型：`check-e63bebe83da3d371` / method
- 计划：applicable；任务卡明确同一版面的三项设置与预览关系，截图已有多个可比较位置；应用后的同步情况仍需运行证据。
- 对象：['文字大小', '段落行距', '使用暖色背景', '阅读预览及已应用说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标设置选中值及对应应用完成画面', '预览字号、行距、背景的前后可比证据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：跨页面对象与信息一致性；对象：同一角色、订单、任务或其他对象在不同页面/状态中的名称、属性、数量和指代。；适用：至少两个材料位置已确认属于同一对象、可比版本与可比条件。；触发：同一对象与条件已确认，名称/属性/数量发生无依据矛盾或错误传递，且不是已确认的合法变化。；弃权：对象同一性、版本或允许变化条件未知时证据不足；只有一个对象位置时不适用。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E03 · 操作与反馈状态对应

- 检查 ID / 类型：`check-c92a87b9c199c456` / method
- 计划：applicable；任务明确要求应用期间及完成后反馈，并使预览与选择一致；当前只有初始状态，需补实际应用过程。
- 对象：['文字大小', '段落行距', '使用暖色背景', '应用设置', '阅读预览及状态说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：['三个目标选项选定后的状态及应用动作记录', '应用期间反馈、按钮开放状态及观察时长', '完成后实际预览与已应用说明']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：操作与反馈状态对应；对象：动作触发、等待/选择/完成/失败等反馈及其对应操作对象。；适用：存在可执行动作或明确的状态设计，且动作应产生的变化有任务依据。；触发：动作实际触发有证据，但反馈缺失/错误关联/与明确预期冲突，范围和观察条件足以支持本次结论。；弃权：动作未触发、工具失败、只有前状态、观察条件不足或异步完成条件未知时证据不足；无状态变化检查对象时不适用。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E04 · 返回取消后的任务恢复

- 检查 ID / 类型：`check-9a6b5aa4d4588da3` / method
- 计划：applicable；任务包含明确恢复分支，且规定三个选项与已应用预览共同重置；需比较目标版面应用后与恢复后的实际状态。
- 对象：['恢复初始', '文字大小', '段落行距', '使用暖色背景', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标版面已应用的恢复前状态', '恢复初始的实际动作路径', '恢复后三个选项及预览与初始基线的比较']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：返回取消后的任务恢复；对象：返回、取消、退出再进入时的数据、选择、进度及定位。；适用：任务包含返回/取消/恢复分支，且预期的保留或重置要求可确定。；触发：返回/取消后的状态与已确认要求矛盾，造成已证实的任务丢失、错误续接或不应保留的数据残留。；弃权：保留规则不明、未执行分支或新旧状态不可比时证据不足；无返回/取消分支时不适用；不默认所有进度都必须保留。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E05 · 异常分支与恢复路径

- 检查 ID / 类型：`check-8a93ace320144312` / method
- 计划：needs_context；任务要求遇阻记录，但未提供具体产品异常或恢复设计；初始画面不能证明异常对象不存在，也不能据此规划故障注入。
- 对象：['阅读设置页面', '应用设置']
- 必需证据类型：['requirement', 'observation']
- 缺项：['允许路径中若出现异常，其触发条件与画面', '该异常应提供的处理或恢复依据', '有恢复入口时的安全动作及结果']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：异常分支与恢复路径；对象：已取得的网络/输入/业务异常状态及可执行恢复步骤。；适用：已观察异常或提供明确异常设计，并存在应向用户交付的处理/恢复方式。；触发：条件明确且实际可测，恢复入口失效、进入同一无解循环或恢复结果违反明确要求；静态设计缺已确认必需分支只报设计层遗漏。；弃权：不能安全触发异常、无恢复依据或实际结果未取得时证据不足；任务确认无本条异常对象时不适用，不以未遇错误证明无错误。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E06 · 前置条件与操作开放状态

- 检查 ID / 类型：`check-feb0d5915415eb7b` / method
- 计划：applicable；REQ-N01-02明确规定处理期间避免重复提交，构成操作开放条件；初始按钮可用不能证明处理期间是否拦截重复提交。
- 对象：['应用设置', '应用状态反馈']
- 必需证据类型：['requirement', 'observation']
- 缺项：['应用动作及处理期间的可辨识状态', '处理期间应用按钮状态或其他重复提交拦截证据', '可安全取得时的重复触发处理结果；若无法捕获处理期则记录限制']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：前置条件与操作开放状态；对象：任务前置条件、按钮可用/禁用状态及操作结果。；适用：项目明确规定某操作的前置条件，且有可比状态或测试方式。；触发：已确认条件与当前操作开放/拦截行为矛盾；仅凭按钮外观可疑只形成待验证线索，不声称业务已绕过。；弃权：前置条件、账号状态或实际执行未知时证据不足；明确无该类条件时不适用；需真实发奖等未授权动作保持阻断。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### G-N01-01 · 将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。

- 检查 ID / 类型：`check-3f7e81a672e2c7d4` / goal
- 计划：applicable；恢复与检查是明确目标；初始截图不能证明从目标版面恢复成功。
- 对象：['恢复初始', '文字大小', '段落行距', '使用暖色背景', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标版面已应用的前置状态', '恢复动作及三个选项、预览和反馈的后置观察']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-0fc700a17e9ed1e3` / goal
- 计划：applicable；恢复要求有明确初始值依据；需核对三个选项和实际预览，未执行不能计为满足。
- 对象：['恢复初始', '阅读设置页面']
- 必需证据类型：['requirement', 'observation']
- 缺项：['已应用目标版面至恢复初始的动作前后证据', '恢复后三个选项和预览与初始值的对照']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### E08 · 跨职能要求冲突识别与处理

- 检查 ID / 类型：`check-00d9390b4ace4112` / conflict
- 计划：applicable；任务卡与委托均涉及恢复初始，需核对版本、范围和原文的一致性；冲突处理独立于实现检查。
- 对象：['N01-阅读设置任务要求', 'initial_purpose']
- 必需证据类型：['requirement', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：跨职能要求冲突识别与处理；对象：策划/产品、设计、开发材料或用户决定对同一对象的要求与限制。；适用：两项以上要求/约束指向同一对象，可能无法同时满足或存在证据描述矛盾。；触发：原文可定位且同范围，两项要求无法同时成立。输出conflict记录，不未经裁决转换为产品违规。已裁决正式要求被实现违反时转E07。；弃权：同一对象或版本关系未知则待澄清；只有单份要求、或解释后可同时满足则不构成冲突。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-1a3b7f9fd5644fea902767d3c4979deb` / statement / 来源 `src-2c868f36de824501a3793adc9019616c` / 版本 context-1
  - 定位：文档分块 0/1；行 1-12；字符 0-380
  - 内容：本次检查本机演示原型的实际操作。按以下任务卡执行评审：  
任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期…
  - 原始记录：[`artifact-6e900814708c4f98820b0fe8f9ffa7a2`](artifacts/ev-1a3b7f9fd5644fea902767d3c4979deb-artifact-6e900814708c4f98820b0fe8f9ffa7a2.txt)
  - 原始文件：[`artifact-295284782ee44182b63f34c0c3ad159f`](artifacts/ev-1a3b7f9fd5644fea902767d3c4979deb-artifact-295284782ee44182b63f34c0c3ad159f.txt)

### R04 · 完成状态说清结果

- 检查 ID / 类型：`check-4ec7daeb7019e4b7` / rule
- 计划：needs_context；需取得恢复完成状态后检查结果表达；当前初始状态不是恢复操作的完成证据。
- 对象：['恢复初始按钮、状态区域及阅读预览']
- 必需证据类型：['observation']
- 缺项：['目标版面应用后执行恢复的动作记录', '恢复完成后的完整反馈与预览']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：完成状态说清结果；适用：已取得某次操作完成/成功状态，完成对象与上下文可确认。；检查：检查成功表达是否能说明已完成的动作、对象及确有必要的后续操作。；触发：完成状态已确认，但只有泛化成功信息，结合上下文仍无法判断完成了什么，或遗漏任务必需的下一步线索。；弃权：明确非完成状态时不适用；只有完成前画面、对象不明或结果区域缺失时证据不足；没有后续任务不要求强加下一步。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R06 · 操作名称说明预期结果

- 检查 ID / 类型：`check-75b93cc37591be0b` / rule
- 计划：applicable；任务明确要求恢复初始版面；现有截图可检查“恢复初始”名称及上下文，实际恢复结果另需动作证据。
- 对象：['恢复初始按钮及当前初始版面说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：操作名称说明预期结果；适用：当前状态有主要按钮/入口，用户任务和动作目的已知。；检查：核对按钮文字、邻近内容与预期动作；运行结果可用于确认动作，但不能替代文案清晰度检查。；触发：主要按钮使用泛词或含义不符，结合邻近说明仍不能理解预期结果，或与明确动作目的冲突。；弃权：无主操作对象时不适用；任务/动作目的不明或上下文缺失时证据不足；周围内容已清楚说明时，泛词本身不构成问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-410cca21735a85f2` / rule
- 计划：applicable；恢复涉及同一组三个选择控件，需核对恢复后的状态是否可辨认；现有初始截图不能证明恢复已执行。
- 对象：['文字大小', '段落行距', '使用暖色背景']
- 必需证据类型：['observation']
- 缺项：['目标版面应用后执行恢复的动作记录', '恢复后的三个控件状态与画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

### R19 · 主要任务操作易于定位

- 检查 ID / 类型：`check-e1f2a3f74d899f01` / rule
- 计划：applicable；恢复是明确主操作，初始画面已有对应入口；仍须取得应用后的画面检查该阶段入口的位置与可见性。
- 对象：['恢复初始']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标版面应用完成后的完整画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：主要任务操作易于定位；适用：已确认主任务及对应主操作，取得其所在区域和必要上下文。；检查：记录主操作、竞争元素、位置/遮挡/层级关系；计算显著性只作线索，真人识别另行验证。；触发：有具体可见证据表明主操作被遮挡、与任务脱离或层级混淆，难以从当前界面定位。；弃权：确认无本条操作对象时不适用；主任务未知、区域未取得或仅有代理分值时证据不足；不能因按钮不最大而直接报问题。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E01 · 关键任务路径衔接

- 检查 ID / 类型：`check-6f3c1318c96b913d` / method
- 计划：applicable；任务卡明确应用后恢复的起点和终点；初始截图只能作为基线，不能证明恢复动作实际有效。
- 对象：['恢复初始', '文字大小', '段落行距', '使用暖色背景', '阅读预览']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标版面已应用的起点证据', '恢复初始动作及结果记录', '恢复后三项控件、预览及状态说明']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：关键任务路径衔接；对象：任务起点、动作入口、目标页面/状态和已声明终点。；适用：存在需要跨页或跨状态的任务，关系可由已确认要求、原型连接或实际路径建立。；触发：目标关系明确且入口条件满足，本次操作到达错误对象、陷入可复现死路或无法抵达明确必需的下一步，且已排除访问/工具阻断。；弃权：关系或目标未知、权限失败、工具未执行、原型未实现分支时证据不足；明确独立静态任务无连接对象时不适用。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E02 · 跨页面对象与信息一致性

- 检查 ID / 类型：`check-bc3b47f44828f8d1` / method
- 计划：applicable；REQ-N01-03明确控件与预览须共同恢复，初始基线已取得；需比较实际恢复结果，不能只检查说明文字。
- 对象：['文字大小', '段落行距', '使用暖色背景', '阅读预览及已应用说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：['恢复前已应用目标版面的记录', '恢复后三项选项、预览样式与已应用说明的同状态证据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：跨页面对象与信息一致性；对象：同一角色、订单、任务或其他对象在不同页面/状态中的名称、属性、数量和指代。；适用：至少两个材料位置已确认属于同一对象、可比版本与可比条件。；触发：同一对象与条件已确认，名称/属性/数量发生无依据矛盾或错误传递，且不是已确认的合法变化。；弃权：对象同一性、版本或允许变化条件未知时证据不足；只有一个对象位置时不适用。
- 证据链：
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)

### E03 · 操作与反馈状态对应

- 检查 ID / 类型：`check-e937882a76db8cdb` / method
- 计划：applicable；恢复动作应使三个选项及已应用预览共同回到初始值；现有初始画面不能证明恢复已执行。
- 对象：['恢复初始', '文字大小', '段落行距', '使用暖色背景', '阅读预览及状态说明']
- 必需证据类型：['requirement', 'observation']
- 缺项：['目标版面已应用的恢复前状态', '恢复初始动作及观察时长', '恢复后三个选项、实际预览和状态说明']
- 执行 / 判断：not_executed / 未判断
- 判断理由：用户结束/终止，未完成检查。
- 判据/方法定义：操作与反馈状态对应；对象：动作触发、等待/选择/完成/失败等反馈及其对应操作对象。；适用：存在可执行动作或明确的状态设计，且动作应产生的变化有任务依据。；触发：动作实际触发有证据，但反馈缺失/错误关联/与明确预期冲突，范围和观察条件足以支持本次结论。；弃权：动作未触发、工具失败、只有前状态、观察条件不足或异步完成条件未知时证据不足；无状态变化检查对象时不适用。
- 证据链：
- `ev-230a4d2615a6416087da60291209915d` / requirement / 来源 `src-567cbed11f7b459cb152f3c11ef997f3` / 版本 冻结任务卡-v1
  - 定位：文档分块 0/1；行 1-11；字符 0-352
  - 内容：任务名称：阅读版面设置与恢复  
材料来源：AI 制作的独立本地交互样本，版本 N01-v1。  
任务目标：将版面设为大字号、舒适行距和暖色背景，应用后查看预览；再恢复初始版面并检查结果。  
初始状态：新开页面，标准字号、紧凑行距、白色背景。  
允许动作：选择字号和行距、切换背景、应用设置、恢复初始；可以等待反馈、查看预览。  
结束条件：完成应用和恢复，并观察两个结果；遇到阻碍则记录当前状态和原因。  
验收要求：  
REQ-N01-01 应用后的阅读预览与用户所选字号、行距、背景一致。  
REQ-N01-02 应用期间和完成后有明确状态反馈，处理期间避免重复提交。  
REQ…
  - 原始记录：[`artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-3c21a9ad41e24c4b9fa4d5c2d69450b0.txt)
  - 原始文件：[`artifact-0b39a4dd47924330b647d4c25a7af172`](artifacts/ev-230a4d2615a6416087da60291209915d-artifact-0b39a4dd47924330b647d4c25a7af172.txt)
- `ev-ff29fd5c1dc24b78982d6ecec63f3956` / observation / 来源 `src-3d4c403dc4794d3bab0e79664983aefe` / 版本 N01-v1
  - 定位：URL http://127.0.0.1:49920/N01-%E9%98%85%E8%AF%BB%E8%AE%BE%E7%BD%AE/%E6%89%93%E5%BC%80%E7%95%8C%E9%9D%A2.html；状态 未知
  - 内容：阅读设置  
设置阅读版面  
文字大小  
标准字号  
大字号  
段落行距  
紧凑行距  
舒适行距  
使用暖色背景  
应用设置  
恢复初始  
  
当前使用初始版面  
  
阅读预览  
城市中的绿意  
  
清晨沿着街角向前，树叶的影子落在长椅上。留一点时间观察身边的植物，熟悉的街道也会带来新的发现。  
  
已应用：标准字号 · 紧凑行距 · 白色背景  
  
本地演示 · N01-v1 · 操作仅在当前页面生效
  - 画面：[`artifact-d21c779aa487423391b27a2cae10105e`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-d21c779aa487423391b27a2cae10105e.png)
  - 视觉分析：[`artifact-3516c5a9fe88451dacc9a0c80cc42972`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-3516c5a9fe88451dacc9a0c80cc42972.json)
  - 叠加图 overlay-elements.png：[`artifact-52a319a72dae4a44989851bf30a736aa`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-52a319a72dae4a44989851bf30a736aa.png)
  - 叠加图 overlay-focus.png：[`artifact-7578ea6ea7de458ebb1363401a959184`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-7578ea6ea7de458ebb1363401a959184.png)
  - 叠加图 overlay-flow.png：[`artifact-367f43535f8a4a8688aaf94d1a511a82`](artifacts/ev-ff29fd5c1dc24b78982d6ecec63f3956-artifact-367f43535f8a4a8688aaf94d1a511a82.png)

## 八、发现与修改建议

当前没有通过证据核验的候选发现。

## 九、问题、冲突与业务决定

无登记问题。

## 十、模型调用、输入与原始输出

| 调用 | 阶段/操作 | 模型 | 输入索引 | 输出摘要 | 原始响应 |
| --- | --- | --- | --- | --- | --- |
| `call-b0c0085787344f5bbd3a38c868145352` | T03 / understand | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_… | 目标 1；要求 3；意见 0；冲突 0 | [`artifact-b8f31491b7ea44e793adf421e34023e2`](raw/call-b0c0085787344f5bbd3a38c868145352-artifact-b8f31491b7ea44e793adf421e34023e2.txt) |
| `call-29272ad7b32e47f8a785a1f4b8e6af73` | T04 / plan_checks | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': ['G-N01-01', 'REQ-N01-01', 'REQ-N01-02', 'REQ-N01-03', 'E07', 'E08', 'R01', 'R02'], 'check_ids': [], 'findi… | 计划 11 项：G-N01-01, G-N01-01, REQ-N01-01, REQ-N01-02, REQ-N01-03, E07, E07, E08, E08, R01, R02 | [`artifact-b59a922c8cc345b38e999e5ae1f60947`](raw/call-29272ad7b32e47f8a785a1f4b8e6af73-artifact-b59a922c8cc345b38e999e5ae1f60947.txt) |
| `call-8dcad002d7fe45b998b3eaa33d79d944` | T04 / plan_checks | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': ['R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10'], 'check_ids': [], 'finding_ids': [], 'previous_fin… | 计划 10 项：R03, R04, R04, R05, R06, R06, R07, R08, R09, R10 | [`artifact-683cb07c35894d2a845432f212e8dd79`](raw/call-8dcad002d7fe45b998b3eaa33d79d944-artifact-683cb07c35894d2a845432f212e8dd79.txt) |
| `call-3c80b1eb0dd748b390346a0181f5420e` | T04 / plan_checks | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': ['R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18'], 'check_ids': [], 'finding_ids': [], 'previous_fin… | 计划 9 项：R11, R12, R13, R14, R15, R16, R17, R17, R18 | [`artifact-51fd8f5294b54853ad057cc225072020`](raw/call-3c80b1eb0dd748b390346a0181f5420e-artifact-51fd8f5294b54853ad057cc225072020.txt) |
| `call-cd9840166256459aa8ef17fad73ee822` | T04 / plan_checks | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': ['R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02'], 'check_ids': [], 'finding_ids': [], 'previous_fin… | 计划 11 项：R19, R19, R20, R21, R22, R23, R24, E01, E01, E02, E02 | [`artifact-a69c0425febd486fa5826393b3328453`](raw/call-cd9840166256459aa8ef17fad73ee822-artifact-a69c0425febd486fa5826393b3328453.txt) |
| `call-ee0366040bae4f2aa8f52e477ff8827e` | T04 / plan_checks | codex_cli/gpt-6.1-sol | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-3d4c403dc4794d3bab0e79664983aefe', 'src-567cbed11f7b459cb152f3c11ef997f3', 'src-2c868f36de824501a3793adc9019616c'], 'evidence_ids': ['ev-1a3b7f9fd5644fea902767d3c4979deb', 'ev-230a4d2615a6416087da60291209915d', 'ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'image_evidence_ids': ['ev-ff29fd5c1dc24b78982d6ecec63f3956'], 'check_refs': ['E03', 'E04', 'E05', 'E06'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap… | 计划 5 项：E03, E03, E04, E05, E06 | [`artifact-e18e8a8a3af3471dbf3c1d39ce00ce4d`](raw/call-ee0366040bae4f2aa8f52e477ff8827e-artifact-e18e8a8a3af3471dbf3c1d39ce00ce4d.txt) |

### call-b0c0085787344f5bbd3a38c868145352 · T03 understand

- 状态：validated；尝试：1；耗时：49359ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 30845, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 1729, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：目标 1；要求 3；意见 0；冲突 0
- 完整原始响应：[`artifact-b8f31491b7ea44e793adf421e34023e2`](raw/call-b0c0085787344f5bbd3a38c868145352-artifact-b8f31491b7ea44e793adf421e34023e2.txt)

### call-29272ad7b32e47f8a785a1f4b8e6af73 · T04 plan_checks

- 状态：validated；尝试：1；耗时：74156ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 39490, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 3243, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": ["G-N01-01", "REQ-N01-01", "REQ-N01-02", "REQ-N01-03", "E07", "E08", "R01", "R02"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 11 项：G-N01-01, G-N01-01, REQ-N01-01, REQ-N01-02, REQ-N01-03, E07, E07, E08, E08, R01, R02
- 完整原始响应：[`artifact-b59a922c8cc345b38e999e5ae1f60947`](raw/call-29272ad7b32e47f8a785a1f4b8e6af73-artifact-b59a922c8cc345b38e999e5ae1f60947.txt)

### call-8dcad002d7fe45b998b3eaa33d79d944 · T04 plan_checks

- 状态：validated；尝试：1；耗时：66969ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 41017, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 2778, 'reasoning_output_tokens': 135}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": ["R03", "R04", "R05", "R06", "R07", "R08", "R09", "R10"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 10 项：R03, R04, R04, R05, R06, R06, R07, R08, R09, R10
- 完整原始响应：[`artifact-683cb07c35894d2a845432f212e8dd79`](raw/call-8dcad002d7fe45b998b3eaa33d79d944-artifact-683cb07c35894d2a845432f212e8dd79.txt)

### call-3c80b1eb0dd748b390346a0181f5420e · T04 plan_checks

- 状态：validated；尝试：1；耗时：59047ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 40978, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 2361, 'reasoning_output_tokens': 94}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": ["R11", "R12", "R13", "R14", "R15", "R16", "R17", "R18"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 9 项：R11, R12, R13, R14, R15, R16, R17, R17, R18
- 完整原始响应：[`artifact-51fd8f5294b54853ad057cc225072020`](raw/call-3c80b1eb0dd748b390346a0181f5420e-artifact-51fd8f5294b54853ad057cc225072020.txt)

### call-cd9840166256459aa8ef17fad73ee822 · T04 plan_checks

- 状态：validated；尝试：1；耗时：72703ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 41002, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 3277, 'reasoning_output_tokens': 89}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": ["R19", "R20", "R21", "R22", "R23", "R24", "E01", "E02"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 11 项：R19, R19, R20, R21, R22, R23, R24, E01, E01, E02, E02
- 完整原始响应：[`artifact-a69c0425febd486fa5826393b3328453`](raw/call-cd9840166256459aa8ef17fad73ee822-artifact-a69c0425febd486fa5826393b3328453.txt)

### call-ee0366040bae4f2aa8f52e477ff8827e · T04 plan_checks

- 状态：validated；尝试：1；耗时：45141ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 38687, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 1673, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-3d4c403dc4794d3bab0e79664983aefe", "src-567cbed11f7b459cb152f3c11ef997f3", "src-2c868f36de824501a3793adc9019616c"], "evidence_ids": ["ev-1a3b7f9fd5644fea902767d3c4979deb", "ev-230a4d2615a6416087da60291209915d", "ev-ff29fd5c1dc24b78982d6ecec63f3956"], "image_evidence_ids": ["ev-ff29fd5c1dc24b78982d6ecec63f3956"], "check_refs": ["E03", "E04", "E05", "E06"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 5 项：E03, E03, E04, E05, E06
- 完整原始响应：[`artifact-e18e8a8a3af3471dbf3c1d39ce00ce4d`](raw/call-ee0366040bae4f2aa8f52e477ff8827e-artifact-e18e8a8a3af3471dbf3c1d39ce00ce4d.txt)

## 十一、复审、历史与限制

- 完整性：`partial`
- 当前运行限制：无
- 会话历史警告：无
- 本轮没有登记复审项。

## 十二、可复核文件

报告包应同时包含 `report.json`、`process.json`、`checks.json`、`evidence.json`、`findings.json`、`stages/T01.json`—`stages/T10.json`、`report-showcase.md`、`report-summary.md`、`method/` 方法原文与哈希以及原始响应附件。单独打开 Markdown 时，模型原始响应和证据画面仍可通过会话 artifact 接口按 ID 读取。

> 本报告引用模型调用 6 次；测试夹具否。