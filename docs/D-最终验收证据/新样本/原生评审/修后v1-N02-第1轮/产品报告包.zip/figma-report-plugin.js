const plan = {"source_root_node_id":"","source_title":"N02-器材借用清单","report_name":"N02-器材借用清单 · AI评审报告","title":"N02-器材借用清单 · AI评审报告","subtitle":"基于完整交互流程与逐屏技术审查","summary":{"checks_total":119,"executed":119,"design_met":0,"candidate_issues":11,"screen_candidate_issues":11,"insufficient_evidence":47,"screen_reviews":10,"screen_complete":10,"screen_partial":0,"screen_ui_elements":228,"screen_ocr_blocks":234},"screen_summary":[{"node_id":"","page_type":"器材借用清单生成器初始页","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":0},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单配置页","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":20,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单配置页","status":"completed","ui_element_count":23,"ocr_block_count":21,"issue_count":1},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":24,"ocr_block_count":29,"issue_count":1},{"node_id":"","page_type":"器材借用清单生成与预览","status":"completed","ui_element_count":27,"ocr_block_count":29,"issue_count":1},{"node_id":"","page_type":"器材借用清单","status":"completed","ui_element_count":19,"ocr_block_count":29,"issue_count":1}],"gaps":[{"text":"目标用户的专业程度及对任务必需器材术语的熟悉度，有哪些依据？"},{"text":"三类器材数量是否分别存在必填要求，以及数量上下限或其他有效值限制？"}],"annotations":[{"kind":"issue","scope":"screen+global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"借用汇总与当前选择、预览行互相矛盾","detail":"选择区及预览行均显示投影仪2件、无线麦克风3件、三脚架1件，而加粗汇总显示“借用总数量：3件”。同一清单提供两种互相冲突的状态表达，用户必须自行加总，无法可靠完成核对。这是界面内部状态一致性问题，不涉及商业数值是否合理。","action":"让“借用总数量”由当前预览行的件数统一汇总，并与行数据同步呈现；当前画面应显示6件。若另需展示器材种类数，应单独标注“器材种类”。","heuristic_ids":["H06"],"severity":"high","color":"#C62828","bbox_hint":{"x":0.528,"y":0.326,"width":0.292,"height":0.235}},{"kind":"issue","scope":"screen+global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"重复出现：已选择器材后仍显示未选择提示","detail":"投影仪已显示2件，操作区下方却仍提示“请先选择至少一件器材”。两处状态互相矛盾，使用户无法确认选择是否已被接受，可能重复增加数量或犹豫是否能够生成清单。","action":"将提示与当前数量同步：总数量为0时显示选择要求；大于0时改为“已选2件，可生成清单”等准确反馈。","heuristic_ids":["H06"],"severity":"medium","color":"#C62828","bbox_hint":{"x":0.18,"y":0.283,"width":0.292,"height":0.388}},{"kind":"issue","scope":"screen+global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"已选数量与选择提示相互矛盾","detail":"数量控件表明已有选择，邻近提示却表示尚未满足选择条件。用户无法确定这1件是否已被系统接受，可能重复增加数量或犹豫是否可以生成清单。该矛盾在当前截图中成立，无需推断后续行为。","action":"根据当前选择总量同步提示：总量为0时显示选择要求，大于0时移除该提示或改为“已选1件，可生成清单”；若为历史校验信息，在条件满足后清除。","heuristic_ids":["H06"],"severity":"medium","color":"#C62828","bbox_hint":{"x":0.18,"y":0.283,"width":0.292,"height":0.388}},{"kind":"issue","scope":"screen+global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"借用总数量与当前选择及预览行冲突","detail":"当前选择和预览三行均显示2、4、1，总数量却突出显示3件，同时提示“清单已更新”。用户无法直接信任汇总完成核对，必须自行相加并判断哪个状态有效。这是同一选择状态的呈现不一致，不涉及商业数值是否合理。","action":"使总数量与预览行共享同一数量状态，按各行件数求和；生成和后续数量调整时同步更新行与总计，当前应显示7件。","heuristic_ids":["H06"],"severity":"high","color":"#C62828","bbox_hint":{"x":0.528,"y":0.326,"width":0.292,"height":0.234}},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"借用总数量与当前选择及预览行冲突","detail":"当前选择和预览三行均显示2、4、1，总数量却突出显示3件，同时提示“清单已更新”。用户无法直接信任汇总完成核对，必须自行相加并判断哪个状态有效。这是同一选择状态的呈现不一致，不涉及商业数值是否合理。","action":"使总数量与预览行共享同一数量状态，按各行件数求和；生成和后续数量调整时同步更新行与总计，当前应显示7件。","heuristic_ids":[],"severity":"high","color":"#C62828","bbox_hint":null},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"首次生成及数量调整后的借用总数量错误","detail":"首次生成各行正确但汇总错误；增加无线麦克风后，该行更新为4件，结果总量仍显示3件。合并同版本同一汇总对象的异常，实现原因未知。","action":"按当前各行件数求和，生成及调整数量时同步重算；复核首次6件、调整后7件。","heuristic_ids":[],"severity":"high","color":"#C62828","bbox_hint":null},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"首次生成及数量调整后的借用总数量错误","detail":"N02-v1两次清单各行均与选择一致，但总数量均为3件。增加无线麦克风后，对应行及页面反馈发生变化，汇总未对应更新为7件。同版、同汇总对象及相同修改方向的异常合并记录，具体实现原因未知。","action":"按当前清单各行件数求和，并在生成及数量调整时同步更新总计；沿本次路径复核首次6件、调整后7件。","heuristic_ids":[],"severity":"high","color":"#C62828","bbox_hint":null},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"R17：生成前已有选择仍提示先选择器材","detail":"投影仪已为1件，以及三类器材已为2、3、1件时，仍显示“请先选择至少一件器材”。该提示与非零选择矛盾，可能使用户怀疑选择是否被接受；实际后续成功进入预览，未见此提示阻断生成。生成后提示改变不代表生成前问题已解决。","action":"总选择为0时显示选择要求；存在非零选择时移除该提示，或改为准确的已选数量及生成引导。","heuristic_ids":[],"severity":"medium","color":"#C62828","bbox_hint":null},{"kind":"issue","scope":"screen+global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"清单汇总与明细矛盾，成功反馈无法支持可靠核对","detail":"选择区与预览各行均为2、5、1，合计8件，但加粗汇总显示“借用总数量：3 件”，同时E17提示“清单已更新”。用户无法直接信任已完成的清单，需要自行相加判断哪处正确，可能依据错误汇总核对借用件数。这是同一选择状态的呈现矛盾，不涉及商业数值合理性。","action":"让总数量与预览各行使用同一份当前数量状态求和，并在生成及数量调整时同步刷新；只有明细与汇总完成同步后才显示已更新反馈。","heuristic_ids":["H01","H06"],"severity":"high","color":"#C62828","bbox_hint":{"x":0.528,"y":0.283,"width":0.292,"height":0.278}},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"首次生成及数量调整后的借用总数量错误","detail":"N02-v1首次生成及增加无线麦克风后的器材行均与选择一致，但汇总均为3件。调整动作使页面及无线麦克风行发生变化，汇总结果仍错误。两次异常属于同一汇总对象和修改动作，合并记录；实现原因未知。","action":"按当前清单各行件数求和，并在生成和数量调整时同步更新汇总；沿本次路径复核首次6件、调整后7件。","heuristic_ids":[],"severity":"high","color":"#C62828","bbox_hint":null},{"kind":"issue","scope":"global","target_node_id":"","target_name":"","target_x":0,"target_y":0,"target_width":1,"target_height":1,"title":"首次生成及数量调整后的借用总数量错误","detail":"N02-v1首次生成和增加1件后的清单，各行均与选择一致，但汇总均显示3件。增加动作已使无线麦克风行更新为4，页面也提示清单已更新；不能表述为整个页面没有变化。两次异常属于同一汇总对象，合并记录，具体实现原因未知。","action":"按当前清单各行件数求和生成总数量，并在首次生成及后续数量调整时同步更新；沿TASK-N02-01和TASK-N02-02复核应分别显示6件、7件。","heuristic_ids":[],"severity":"high","color":"#C62828","bbox_hint":null}],"heuristic_summary":{"H01":1,"H06":5},"colors":{"issue":"#C62828","gap":"#9A6700","review":"#0B63CE","pass":"#18794E","report_bg":"#F6F8FB","panel_bg":"#FFFFFF","text":"#172033","muted":"#56637A","border":"#C9D2E0"},"session_id":"session-167526da0aa34dac86a3b0f20a27eee1","run_id":"run-52c4ebf514d54edd9df2cb99631d639d"};
const reportFonts = {
  regular: { family: "Noto Sans SC", style: "Regular" },
  medium: { family: "Noto Sans SC", style: "Medium" },
  bold: { family: "Noto Sans SC", style: "Bold" }
};
await Promise.all(Object.values(reportFonts).map(font => figma.loadFontAsync(font)));

const original = await figma.getNodeByIdAsync(plan.source_root_node_id);
if (!original || original.type !== "FRAME") throw new Error("Source interaction frame not found");
const page = original.parent;
if (!page || page.type !== "PAGE") throw new Error("Source frame must be on a page");
await figma.setCurrentPageAsync(page);

const duplicateName = `${plan.source_title} · AI审查标注副本`;
const reuseWrapper = page.findOne(n =>
  n.type === "FRAME" &&
  n.name.includes(plan.source_title) &&
  n.name.includes("AI审查标注稿")
);
let duplicate = reuseWrapper
  ? reuseWrapper.findOne(n => n.name.includes("AI审查标注副本"))
  : page.findOne(n => n.name === duplicateName);
if (!duplicate) {
  duplicate = original.clone();
  duplicate.name = duplicateName;
  duplicate.x = original.x + original.width + 320;
  duplicate.y = original.y;
  page.appendChild(duplicate);
}
if (duplicate.type !== "FRAME") throw new Error("Annotated copy must be a frame");
if (duplicate.layoutMode !== "NONE") {
  duplicate.primaryAxisSizingMode = "FIXED";
  duplicate.counterAxisSizingMode = "FIXED";
}
duplicate.resize(original.width, original.height);
const reviewWrapper = duplicate.parent && duplicate.parent.type === "FRAME"
  ? duplicate.parent : null;
const reviewBounds = duplicate.absoluteBoundingBox || {
  x: duplicate.x,
  y: duplicate.y,
  width: duplicate.width,
  height: duplicate.height
};
const wrapperBounds = reviewWrapper && reviewWrapper.absoluteBoundingBox
  ? reviewWrapper.absoluteBoundingBox
  : { x: reviewBounds.x, y: reviewBounds.y, width: reviewBounds.width, height: reviewBounds.height };

const oldPanel = page.findOne(n => n.name === "交互案 · AI审查说明栏");
if (oldPanel) oldPanel.remove();
const oldLayer = reviewWrapper
  ? reviewWrapper.findOne(n => n.name.includes("AI彩色标注层"))
  : null;
if (oldLayer) oldLayer.remove();
const annotationPrefix = `AI审查批注 · ${plan.source_title} · `;
for (const child of [...duplicate.children]) {
  if (child.name.startsWith(annotationPrefix)) child.remove();
}
for (const child of [...page.children]) {
  if (child.name.startsWith(annotationPrefix)) child.remove();
}

function rgba(hex, opacity = 1) {
  const clean = hex.replace("#", "");
  return {
    type: "SOLID",
    color: {
      r: parseInt(clean.slice(0, 2), 16) / 255,
      g: parseInt(clean.slice(2, 4), 16) / 255,
      b: parseInt(clean.slice(4, 6), 16) / 255
    },
    opacity
  };
}

function addText(parent, content, font, size, color, width) {
  const node = figma.createText();
  node.fontName = font;
  node.fontSize = size;
  node.fills = [rgba(color)];
  node.characters = content;
  node.resize(width, node.height);
  node.textAutoResize = "HEIGHT";
  parent.appendChild(node);
  node.layoutSizingHorizontal = "FILL";
  return node;
}

function shortText(value, limit = 220) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > limit ? text.slice(0, limit - 1) + "…" : text;
}

const occupiedNotes = [];
function overlaps(first, second) {
  return !(
    first.x + first.width <= second.x ||
    second.x + second.width <= first.x ||
    first.y + first.height <= second.y ||
    second.y + second.height <= first.y
  );
}
const numberedNodes = duplicate.findAll(node =>
  node.type === "TEXT" &&
  node.visible &&
  /^\s*\d+[.、]/.test(node.characters || "")
);
function nearestNumbered(highlightAbs) {
  let best = null;
  let bestDistance = Infinity;
  const hx = highlightAbs.x + highlightAbs.width / 2;
  const hy = highlightAbs.y + highlightAbs.height / 2;
  for (const node of numberedNodes) {
    const box = node.absoluteBoundingBox;
    if (!box) continue;
    const nx = box.x + box.width / 2;
    const ny = box.y + box.height / 2;
    const distance = Math.hypot(nx - hx, ny - hy);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = { node, box };
    }
  }
  return best;
}
const annotationNodeIds = [];
for (let index = 0; index < plan.annotations.length; index++) {
  const annotation = plan.annotations[index];
  const target = {
    x: annotation.target_x,
    y: annotation.target_y,
    width: annotation.target_width,
    height: annotation.target_height
  };
  let highlight = target;
  if (annotation.bbox_hint) {
    highlight = {
      x: target.x + target.width * Number(annotation.bbox_hint.x || 0),
      y: target.y + target.height * Number(annotation.bbox_hint.y || 0),
      width: Math.max(18, target.width * Number(annotation.bbox_hint.width || 0)),
      height: Math.max(18, target.height * Number(annotation.bbox_hint.height || 0))
    };
  }
  const outline = figma.createRectangle();
  outline.name = `${annotationPrefix}目标框 ${index + 1} · ${annotation.title}`;
  outline.x = reviewBounds.x + highlight.x;
  outline.y = reviewBounds.y + highlight.y;
  outline.resize(highlight.width, highlight.height);
  outline.fills = [rgba(annotation.color, 0.05)];
  outline.strokes = [rgba(annotation.color)];
  outline.strokeWeight = 4;
  outline.strokeAlign = "INSIDE";
  page.appendChild(outline);
  annotationNodeIds.push(outline.id);

  const highlightAbs = {
    x: reviewBounds.x + highlight.x,
    y: reviewBounds.y + highlight.y,
    width: highlight.width,
    height: highlight.height
  };
  const nearest = nearestNumbered(highlightAbs);
  const anchorBox = nearest ? nearest.box : highlightAbs;
  let noteX = anchorBox.x;
  let noteY = anchorBox.y + anchorBox.height + 8;
  const noteWidth = 360;
  if (noteX + noteWidth > reviewBounds.x + reviewBounds.width - 20) {
    noteX = Math.max(
      reviewBounds.x + 20,
      reviewBounds.x + reviewBounds.width - noteWidth - 20
    );
  }
  const noteBg = figma.createRectangle();
  noteBg.name = `${annotationPrefix}底色 ${index + 1} · ${annotation.title}`;
  noteBg.cornerRadius = 8;
  noteBg.fills = [rgba(plan.colors.panel_bg, 0.96)];
  noteBg.strokes = [rgba(annotation.color)];
  noteBg.strokeWeight = 2;
  noteBg.strokeAlign = "INSIDE";
  page.appendChild(noteBg);
  annotationNodeIds.push(noteBg.id);
  const header = figma.createText();
  header.name = `${annotationPrefix}标题 ${index + 1} · ${annotation.title}`;
  header.fontName = reportFonts.bold;
  header.fontSize = 18;
  header.fills = [rgba(annotation.color)];
  header.characters = `AI${String(index + 1).padStart(2, "0")} · ${annotation.heuristic_ids.join("/") || "无判据"}`;
  header.resize(noteWidth, header.height);
  header.textAutoResize = "HEIGHT";
  page.appendChild(header);
  annotationNodeIds.push(header.id);

  const body = figma.createText();
  body.name = `${annotationPrefix}正文 ${index + 1} · ${annotation.title}`;
  body.fontName = reportFonts.medium;
  body.fontSize = 15;
  body.fills = [rgba(plan.colors.text)];
  body.characters = `${annotation.title}
${annotation.detail}`;
  body.resize(noteWidth, body.height);
  body.textAutoResize = "HEIGHT";
  page.appendChild(body);
  annotationNodeIds.push(body.id);

  const action = figma.createText();
  action.name = `${annotationPrefix}建议 ${index + 1} · ${annotation.title}`;
  action.fontName = reportFonts.regular;
  action.fontSize = 13;
  action.fills = [rgba(plan.colors.muted)];
  action.characters = `建议：${shortText(annotation.action, 120)}`;
  action.resize(noteWidth, action.height);
  action.textAutoResize = "HEIGHT";
  page.appendChild(action);
  annotationNodeIds.push(action.id);

  const noteHeight = header.height + body.height + action.height + 18;
  for (let attempt = 0; attempt < 30; attempt++) {
    const box = { x: noteX, y: noteY, width: noteWidth, height: noteHeight };
    const hit = occupiedNotes.find(item => overlaps(item, box));
    if (!hit) break;
    noteY = hit.y + hit.height + 12;
  }
  if (noteY + noteHeight > reviewBounds.y + reviewBounds.height - 20) {
    noteY = Math.max(
      reviewBounds.y + 20,
      reviewBounds.y + reviewBounds.height - noteHeight - 20
    );
  }
  noteBg.x = noteX - 8;
  noteBg.y = noteY - 8;
  noteBg.resize(noteWidth + 16, noteHeight + 12);
  header.x = noteX;
  header.y = noteY;
  body.x = noteX;
  body.y = noteY + header.height + 4;
  action.x = noteX;
  action.y = body.y + body.height + 4;
  occupiedNotes.push({ x: noteX, y: noteY, width: noteWidth, height: noteHeight });
}

const existingReport = page.findOne(n => n.name === plan.report_name);
if (existingReport) existingReport.remove();

const report = figma.createAutoLayout("VERTICAL", {
  name: plan.report_name,
  itemSpacing: 22
});
report.resize(1080, 100);
report.paddingTop = 44;
report.paddingBottom = 44;
report.paddingLeft = 44;
report.paddingRight = 44;
report.cornerRadius = 24;
report.fills = [rgba(plan.colors.report_bg)];
report.strokes = [rgba(plan.colors.border)];
report.strokeWeight = 2;
report.x = reviewBounds.x;
report.y = wrapperBounds.y + wrapperBounds.height + 420;

function section(title, accent) {
  const frame = figma.createAutoLayout("VERTICAL", { name: title, itemSpacing: 14 });
  frame.paddingTop = 22;
  frame.paddingBottom = 22;
  frame.paddingLeft = 24;
  frame.paddingRight = 24;
  frame.cornerRadius = 12;
  frame.fills = [rgba(plan.colors.panel_bg)];
  frame.strokes = [rgba(accent, 0.8)];
  frame.strokeWeight = 2;
  report.appendChild(frame);
  frame.layoutSizingHorizontal = "FILL";
  addText(frame, title, reportFonts.bold, 24, accent, 980);
  return frame;
}

addText(report, plan.title, reportFonts.bold, 42, plan.colors.text, 980);
addText(report, plan.subtitle, reportFonts.regular, 18, plan.colors.muted, 980);
addText(
  report,
  `评审完成 · 检查 ${plan.summary.executed}/${plan.summary.checks_total} · 跨项发现 ${plan.summary.candidate_issues} · 系统性问题 ${plan.summary.screen_candidate_issues} · 证据不足 ${plan.summary.insufficient_evidence}`,
  reportFonts.medium, 18, plan.colors.review, 980
);

const overview = section("01 · 评审摘要", plan.colors.review);
addText(
  overview,
  `逐屏技术审查 ${plan.summary.screen_reviews} 个完整界面，其中完整完成 ${plan.summary.screen_complete} 个、部分完成 ${plan.summary.screen_partial} 个；累计识别 UI 元素 ${plan.summary.screen_ui_elements} 个、OCR 文本块 ${plan.summary.screen_ocr_blocks} 个。`,
  reportFonts.regular, 17, plan.colors.text, 980
);
addText(
  overview,
  "完整完成表示 OCR、元素、统计和屏内规则审查均已产出；部分完成会保留具体限制，不把空元素结果当作通过。",
  reportFonts.regular, 15, plan.colors.muted, 980
);
const heuristicRows = Object.entries(plan.heuristic_summary || {});
addText(
  overview,
  heuristicRows.length
    ? `命中启发式维度：${heuristicRows.map(([id, count]) => `${id} × ${count}`).join(" · ")}`
    : "本轮候选问题未绑定可识别的启发式维度，不能把流程缺项冒充交互结论。",
  reportFonts.regular, 16, plan.colors.text, 980
);

const findingsSection = section("02 · 候选问题", plan.colors.issue);
for (let i = 0; i < plan.annotations.length; i++) {
  const item = plan.annotations[i];
  addText(findingsSection, `F${String(i + 1).padStart(3, "0")} · ${item.title}`, reportFonts.bold, 20, plan.colors.issue, 940);
  addText(findingsSection, shortText(item.detail, 360), reportFonts.regular, 16, plan.colors.text, 940);
  addText(findingsSection, `建议：${shortText(item.action, 220)}`, reportFonts.medium, 15, plan.colors.muted, 940);
}

const screensSection = section("03 · 逐屏技术审查", plan.colors.review);
for (const screen of plan.screen_summary) {
  addText(
    screensSection,
    `${screen.page_type || screen.node_id} · ${screen.status === "completed" ? "完整完成" : "部分完成"} · UI ${screen.ui_element_count} · OCR ${screen.ocr_block_count} · 屏内问题 ${screen.issue_count}`,
    reportFonts.regular, 16, screen.status === "completed" ? plan.colors.text : plan.colors.gap, 940
  );
}

const gapsSection = section("04 · 待补证据与业务确认", plan.colors.gap);
for (let i = 0; i < plan.gaps.length; i++) {
  addText(
    gapsSection,
    `G${String(i + 1).padStart(2, "0")} · ${shortText(plan.gaps[i].text, 300)}`,
    reportFonts.regular, 16, plan.colors.text, 940
  );
}

const legendSection = section("05 · 标注说明", plan.colors.pass);
addText(legendSection, "红色：副本编号、目标框与系统性问题；黄色与青色：仅用于报告中的证据缺口和审查统计。", reportFonts.regular, 16, plan.colors.text, 940);
addText(legendSection, "标注位于原交互案的独立副本上，原稿未修改。", reportFonts.medium, 16, plan.colors.pass, 940);
addText(legendSection, `会话：${plan.session_id} · 运行：${plan.run_id}`, reportFonts.regular, 13, plan.colors.muted, 940);

return {
  success: true,
  reportId: report.id,
  duplicateId: duplicate.id,
  annotationCount: plan.annotations.length,
  reportBounds: { x: report.x, y: report.y, width: report.width, height: report.height },
  createdNodeIds: [report.id, ...annotationNodeIds]
};
