# 协同交互方案评审报告

> 会话：`session-ccb7f036875f4677a97976d431365c80`  
> 运行：`run-29982767d0e346f0b18c04fe46cf62e4`  
> 报告版本：`3`  
> 状态 / 完整性：`completed` / `partial`  
> 技术路径：`A 0.2-method-draft / T01–T10`  
> 判据版本：`0.2-method-draft`  
> 证据模式：`materials`

## 一、结论摘要

本次围绕“检查保存设置”执行 32 项检查。执行状态：not_executed=32；判断状态：无。`complete` 仅表示计划项均有可追溯处置，不代表产品全部通过。

当前没有通过证据核验的候选发现；请结合未决项理解范围。

## 二、版本、路径与复现

| 字段 | 当前值 |
| --- | --- |
| 会话 / 运行 | `session-ccb7f036875f4677a97976d431365c80` / `run-29982767d0e346f0b18c04fe46cf62e4` |
| 上下文 / 报告版本 | 2 / 3 |
| 会话契约 | `session-1.0` |
| 判据 / 方法 | `0.2-method-draft` / A T01–T10 |
| 方法目录 | C:\Users\nozomi222333\Documents\Codex\2026-10-02\wo\design-research-skill\方法专家开发交付-v0.2 |
| 判据来源 | {'name': "Jakob Nielsen's 10 Usability Heuristics for User Interface Design", 'url': 'https://www.nngroup.com/articles/ten-usability-heuristics/', 'relationship': '以下条目由小组据宽泛原则操作化，并非源文逐条摘录或正式规范符合性声明'} |
| 模型 | test-fixture/contract-fixture |
| 是否测试夹具 | 是 |
| 方法文件指纹 | `{'00先看这个！！！！-阅读与开发交接.md': '6dca7b14918a08d65e40362bfec2fc40a1f8f1d0492e4f356b2ac9b8f00d051e', '01-04-场景输入流程与技术路径.md': 'fe432cf3851ad10528e53d6fecc14e9ffaba0a4fafd96a1b6ee61c4007c28347', '05-24条判据修订与变更对照.md': 'bd2f82f8d8e539d2011b0b684d77de775b0149ec0e14736717944f2057847c99', '05-判据库-v0.2.json': 'b785eb9c6b64b5d9ceb87ca76430af4a2658c944c9aff99a97ce9298bdf54af7', '05-判据执行补充-v0.2.json': '8e502b943023c7e39a8da6a479c1cc09f621c9474520e4f116cae0553bc9c24d', '05-逐字段变更对照.csv': 'd0b1d25442662ecf10150e923b98b8049ad7291e2bf56653690a138392d8307d', '06-新场景方法-v0.2.json': '1702aa0350c41ced0363a41d73c46aeb547d60d7299616964875b51ce8fd689c', '06-新场景方法与正反例.md': 'e21e0996cc25bc218f5e24e2c3a7aa66649001eb58ad00e84fcb5fc88b48ca26', '07-会话变更重查与复审规则.md': 'c9a5f573648a20094f4b0c4602043979b33ea3cb935a6976b641cf57b539f025', '08-问题表达严重度与评价验收.md': '4d92cfcfdb8417a20678995528ea0180f6182eb52b0b2becbb3a7fc44886eead', '09-开发验收用例.json': 'fc85e0bd301b081d393ab4764f0f0b59003e2462d842ebee91bc990eb9f41f60', '09-开发验收用例.md': 'e2ca3487871026558697e1283734849af2ef94de25b984ade9ae8334a73a2fd3', '10-来源索引.json': 'e6147e42231bb4602cb506caa7a2d6ff69812b2d7d1289731a33220db667017a', '11-交付校验结果.json': '3ec123147dae0c46a6bd2a473a0c5f0bbe5f1d311f42bc2568e41b63b5694cad'}` |

复现依据是本次保存的原始材料、证据、模型原始响应、检查计划与判断记录；不得用新运行结果覆盖本版本。

判定口径：R/E01–E06 使用 `candidate_issue`、`no_visible_issue`、`insufficient_evidence`、`not_applicable`；G/REQ/E07 使用 `met`、`observed_violation`、`insufficient_evidence`；E08 使用 `open`、`no_conflict`、`needs_clarification`、`resolved`。`complete` 只表示计划项均有处置，不表示问题数为零或运行效果已验证。

## 三、输入材料

| 来源 | 类型/角色 | 版本 | 读取状态 | 证据数 | 入口 |
| --- | --- | --- | --- | ---: | --- |
| `src-a9863169e999466a8e9a122eddc19290` 回归夹具要求 | document / product_spec | 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365 | success | 1 |  |
| `src-05b8470854a74eeeba4afdfd5e34d946` initial_purpose | document / review_instruction | context-1 | success | 1 | user://initial_purpose |
| `src-b12060689dba442a8cde27785598c6db` reply | document / user_statement | context-2 | success | 1 | user://reply |

## 四、T01–T10 逐步输入输出

| 阶段 | 状态 | 输入摘要 | 输出摘要 | 模型调用 | 模型耗时 |
| --- | --- | --- | --- | --- | ---: |
| T01 接收与能力检查 | completed | {'purpose': '检查保存设置', 'source_count': 3} | {'session_id': 'session-ccb7f036875f4677a97976d431365c80', 'capabilities': {'schema_version': 'session-1.0', 'methods_version': '0.2-method-draft', 'technical_path_version': 'A-0.2/T01-T10', 'method_root': 'C:\\Users\\nozomi222333\\Documents\\Codex\\2026-10-02\\wo\\design-research-skill\\方法专家开发交付-v0.2', 'method_validation': {'delivery_version': '0.2-method-draft', 'checked_files': 12, 'mismatches': 0}, 'rules': 24, '… | 无 | 0ms |
| T02 材料读取与证据登记 | completed | {'sources': [{'source_id': 'src-a9863169e999466a8e9a122eddc19290', 'kind': 'document', 'reference': '', 'role': 'product_spec', 'version': 'unknown'}, {'source_id': 'src-05b8470854a74eeeba4afdfd5e34d946', 'kind': 'document', 'reference': 'user://initial_purpose', 'role': 'review_instruction', 'version': 'context-1'}, {'source_id': 'src-b12060689dba442a8cde27… | {'evidence_count': 3, 'evidence_ids': ['ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8', 'ev-10c3fbe07e904b6a9d4d971206c80463'], 'source_status': {'src-a9863169e999466a8e9a122eddc19290': 'success', 'src-05b8470854a74eeeba4afdfd5e34d946': 'success', 'src-b12060689dba442a8cde27785598c6db': 'success'}, 'warnings': []} | 无 | 0ms |
| T03 任务与材料理解 | completed | {'evidence_ids': ['ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8', 'ev-10c3fbe07e904b6a9d4d971206c80463'], 'context_version': 2} | {'task_summary': '检查保存设置', 'target_user_summary': '', 'review_tasks': [], 'goals': [], 'requirements': [], 'opinions': [], 'conflicts': [], 'relationships': [], 'unknowns': [], 'assumptions': [], 'excluded_workflow_items': []} | call-b35c752dae3d45bea57022a2af8861f8 | 1ms |
| T04 检查规划与适用性筛选 | completed | {'goal_refs': [], 'requirement_refs': [], 'evidence_ids': ['ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8', 'ev-10c3fbe07e904b6a9d4d971206c80463']} | {'check_count': 32, 'applicability': {'applicable': 32, 'needs_context': 0, 'not_applicable': 0, 'not_assessed': 0}, 'check_refs': ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08']} | call-cebc7ec858bc4fe1bb1a212b5d36042c, call-43f58b0dd3314fef97001d81c9d96656, call-6eefbcd39f044dd9b86649297bc8fae0, call-6bbabc3de7394985943a6c392fe945cc | 4ms |
| T05 执行、取证与逐屏技术审查 | completed | {'authorized_interaction': False, 'planned_check_refs': ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08']} | {'action_count': 0, 'actions': [], 'action_outcomes': [], 'transition_count': 0} | call-4a1db98272374b0a97ef38fdb47f5d5c | 1ms |
| T06 逐项判断 | partial | {'check_ids': ['check-339cb0b4844aa2d8', 'check-b85b2ec612172d8f', 'check-22e1815a410df230', 'check-76c244fc659400a1', 'check-2bb5fe73f34155f4', 'check-664782108908aa64', 'check-4257c7d5d482da68', 'check-d804658e61f11379', 'check-4d7bed2833a63de6', 'check-84a05727f19fc061', 'check-51c656a3ed6ba95c', 'check-fdaa38d7f4a47526', 'check-8b5063e4d265f630', 'check-… | {'decisions': {}, 'judgments': [{'check_id': 'check-339cb0b4844aa2d8', 'ref': 'R01', 'decision': None, 'reason': '当前运行未执行/未完成此检查；继续时可重新安排。', 'evidence_ids': []}, {'check_id': 'check-b85b2ec612172d8f', 'ref': 'R02', 'decision': None, 'reason': '当前运行未执行/未完成此检查；继续时可重新安排。', 'evidence_ids': []}, {'check_id': 'check-22e1815a410df230', 'ref': 'R03', 'decision': None, 'reason': '当前运行未执行/未完成此检查；继续时可重新安排。', 'evidence_ids': []}… | 无 | 0ms |
| T07 证据核验与发现归并 | not_needed | {'candidate_finding_count': 0} | {'verified_finding_ids': [], 'rejected': []} | 无 | 0ms |
| T08 讨论、变更与重查 | waiting | {'context_version': 2, 'events': [{'at': '2026-11-04T00:22:35.696817+00:00', 'actor_type': 'ai', 'actor': 'AI回归-D', 'type': 'purpose', 'content': '检查保存设置'}, {'at': '2026-11-04T00:22:38.158414+00:00', 'actor_type': 'program', 'type': 'run_started', 'run_id': 'run-29982767d0e346f0b18c04fe46cf62e4', 'warning_count': 6}, {'at': '2026-11-04T00:22:38.567317+00:00'… | {'questions': [{'question_id': 'question-72293e54a16f4b7382f3914c26cc3664', 'text': '请说明目标用户', 'reason': '影响术语适用性', 'check_ids': [], 'blocking': True, 'answered': True, 'answer': 'AI回归答复，目标用户是课程案例中的设置页使用者。', 'kind': 'context', 'source_id': None, 'action_id': None, 'answer_actor': 'ai'}, {'question_id': 'question-0a900729dd434cdf93738a46266fd7ee', 'text': '请说明目标用户', 'reason': '影响术语适用性', 'check_ids': [], 'blocking': Tr… | 无 | 0ms |
| T09 报告与保存 | completed | {'run_id': 'run-29982767d0e346f0b18c04fe46cf62e4', 'check_count': 32} | {'report_version': 3, 'report_completeness': 'partial', 'status': 'completed'} | 无 | 0ms |
| T10 修改后复审 | not_needed | {'previous_finding_ids': []} | {'rechecks': []} | 无 | 0ms |

```mermaid
flowchart LR
    T01["T01 接收与能力检查<br/>completed"]
    T02["T02 材料读取与证据登记<br/>completed"]
    T03["T03 任务与材料理解<br/>completed"]
    T04["T04 检查规划与适用性筛选<br/>completed"]
    T05["T05 执行、取证与逐屏技术审查<br/>completed"]
    T06["T06 逐项判断<br/>partial"]
    T07["T07 证据核验与发现归并<br/>not_needed"]
    T08["T08 讨论、变更与重查<br/>waiting"]
    T09["T09 报告与保存<br/>completed"]
    T10["T10 修改后复审<br/>not_needed"]
    T01 --> T02
    T02 --> T03
    T03 --> T04
    T04 --> T05
    T05 --> T06
    T06 --> T07
    T07 --> T08
    T08 --> T09
    T09 --> T10
```


### T01 · 接收与能力检查

- 状态：`completed`
- 输入：评审目的 1 条；来源 3 项
- 输出：契约 session-1.0；方法 0.2-method-draft；R=24；E=8
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T02 · 材料读取与证据登记

- 状态：`completed`
- 输入：来源 3 项
- 输出：证据 3 条；来源状态 读取成功=3
- 模型调用：无
- 模型耗时：0ms
- 关联证据：ev-1de5dd91a2a74736b54f879692909666, ev-2aed182361c4411ea51b304f599bf5b8, ev-10c3fbe07e904b6a9d4d971206c80463

### T03 · 任务与材料理解

- 状态：`completed`
- 输入：用于理解的材料证据 3 条
- 输出：目标 0；要求 0；意见 0；冲突 0；未知 0
- 模型调用：call-b35c752dae3d45bea57022a2af8861f8
- 模型耗时：1ms
- 关联证据：ev-1de5dd91a2a74736b54f879692909666, ev-2aed182361c4411ea51b304f599bf5b8, ev-10c3fbe07e904b6a9d4d971206c80463

### T04 · 检查规划与适用性筛选

- 状态：`completed`
- 输入：目标 0；要求 0；可用证据 3
- 输出：检查 32 项；不适用=0；待补上下文=0；未评估=0；适用=32
- 模型调用：call-cebc7ec858bc4fe1bb1a212b5d36042c, call-43f58b0dd3314fef97001d81c9d96656, call-6eefbcd39f044dd9b86649297bc8fae0, call-6bbabc3de7394985943a6c392fe945cc
- 模型耗时：4ms
- 关联证据：ev-1de5dd91a2a74736b54f879692909666, ev-2aed182361c4411ea51b304f599bf5b8, ev-10c3fbe07e904b6a9d4d971206c80463

### T05 · 执行、取证与逐屏技术审查

- 状态：`completed`
- 输入：交互授权 否；计划检查 32
- 输出：动作 0；状态变化 0；结果 无
- 模型调用：call-4a1db98272374b0a97ef38fdb47f5d5c
- 模型耗时：1ms
- 关联证据：无

### T06 · 逐项判断

- 状态：`partial`
- 输入：检查 32；计划证据 1
- 输出：无
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T07 · 证据核验与发现归并

- 状态：`not_needed`
- 输入：候选发现 0
- 输出：通过核验 0；退回 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T08 · 讨论、变更与重查

- 状态：`waiting`
- 输入：上下文版本 2
- 输出：问题 2；业务决定 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T09 · 报告与保存

- 状态：`completed`
- 输入：运行 run-29982767d0e346f0b18c04fe46cf62e4；检查 32
- 输出：报告 v3；完整性 部分；状态 已完成
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T10 · 修改后复审

- 状态：`not_needed`
- 输入：旧问题 0
- 输出：复审记录 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

## 五、目标要求对应与材料理解

- 任务理解：检查保存设置
- 目标用户：未明确

### 必需覆盖矩阵

| 覆盖单元 | 任务 | 状态 | 来源 | 已覆盖 | 缺证类型 |
| --- | --- | --- | --- | --- | --- |
| `coverage-321462a6160af2a1` | TASK01 | 任务级 | src-a9863169e999466a8e9a122eddc19290 | 否 | unobserved_branch |
| `coverage-f49929bfbcc31137` | TASK01 | 任务级 | src-a9863169e999466a8e9a122eddc19290 | 否 | task_not_planned |

## 六、证据链总表

| 证据 | 来源 / 类型 | 版本 | 定位 | 内容摘要 | 被哪些检查/发现使用 |
| --- | --- | --- | --- | --- | --- |
| `ev-1de5dd91a2a74736b54f879692909666` | src-a9863169e999466a8e9a122eddc19290 / requirement | 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365 | 文档分块 0/1；行 1-1；字符 0-10 | 保存成功后显示结果。 | R01, R02, R03, R04, R05, R06, R07, R08, R09, R10, R11, R12, R13, R14, R15, R16, R17, R18, R19, R20, R21, R22, R23, R24, E01, E02, E03, E04, E05, E06, E07, E08 |

## 七、逐项检查与判断

| 编号 | 类型 | 适用性 | 执行 | 判断 | 证据 | 发现 |
| --- | --- | --- | --- | --- | --- | --- |
| `R01` 当前导航位置可见 | rule | applicable | not_executed | — | 无 | 无 |
| `R02` 多步骤任务显示当前步骤 | rule | applicable | not_executed | — | 无 | 无 |
| `R03` 等待状态说明系统正在做什么 | rule | applicable | not_executed | — | 无 | 无 |
| `R04` 完成状态说清结果 | rule | applicable | not_executed | — | 无 | 无 |
| `R05` 关键文案避免未解释的内部术语 | rule | applicable | not_executed | — | 无 | 无 |
| `R06` 操作名称说明预期结果 | rule | applicable | not_executed | — | 无 | 无 |
| `R07` 输入项名称说明所需信息 | rule | applicable | not_executed | — | 无 | 无 |
| `R08` 弹窗具有可见退出方式 | rule | applicable | not_executed | — | 无 | 无 |
| `R09` 多步骤页面具有可见返回方式 | rule | applicable | not_executed | — | 无 | 无 |
| `R10` 确认页允许取消高风险操作 | rule | applicable | not_executed | — | 无 | 无 |
| `R11` 同一动作使用一致名称 | rule | applicable | not_executed | — | 无 | 无 |
| `R12` 同类控件呈现一致的视觉规则 | rule | applicable | not_executed | — | 无 | 无 |
| `R13` 必填项在填写前可识别 | rule | applicable | not_executed | — | 无 | 无 |
| `R14` 受格式限制的字段提供输入提示 | rule | applicable | not_executed | — | 无 | 无 |
| `R15` 高后果操作确认页说明对象和动作 | rule | applicable | not_executed | — | 无 | 无 |
| `R16` 重要图标操作具有可见含义线索 | rule | applicable | not_executed | — | 无 | 无 |
| `R17` 当前选择状态可见 | rule | applicable | not_executed | — | 无 | 无 |
| `R18` 相关输入和选项形成可识别的组 | rule | applicable | not_executed | — | 无 | 无 |
| `R19` 主要任务操作易于定位 | rule | applicable | not_executed | — | 无 | 无 |
| `R20` 无关信息不压过主要任务 | rule | applicable | not_executed | — | 无 | 无 |
| `R21` 错误状态指明问题位置 | rule | applicable | not_executed | — | 无 | 无 |
| `R22` 错误提示给出修正办法 | rule | applicable | not_executed | — | 无 | 无 |
| `R23` 错误提示使用用户可理解的语言 | rule | applicable | not_executed | — | 无 | 无 |
| `R24` 复杂任务提供就近帮助入口 | rule | applicable | not_executed | — | 无 | 无 |
| `E01` 关键任务路径衔接 | method | applicable | not_executed | — | 无 | 无 |
| `E02` 跨页面对象与信息一致性 | method | applicable | not_executed | — | 无 | 无 |
| `E03` 操作与反馈状态对应 | method | applicable | not_executed | — | 无 | 无 |
| `E04` 返回取消后的任务恢复 | method | applicable | not_executed | — | 无 | 无 |
| `E05` 异常分支与恢复路径 | method | applicable | not_executed | — | 无 | 无 |
| `E06` 前置条件与操作开放状态 | method | applicable | not_executed | — | 无 | 无 |
| `E07` 目标与明确要求落实 | goal | applicable | not_executed | — | 无 | 无 |
| `E08` 跨职能要求冲突识别与处理 | conflict | applicable | not_executed | — | 无 | 无 |

### R01 · 当前导航位置可见

- 检查 ID / 类型：`check-339cb0b4844aa2d8` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：当前导航位置可见；适用：已确认当前页面且存在页面级导航。页面内筛选/单选交由R17。；检查：记录当前页面依据，比较页面级导航项及当前项标识；运行模式分别记录跳转前后导航。；触发：页面级导航及当前页面已知，可完整查看相关导航，但当前项无可辨选中标识或标识与当前页面冲突。；弃权：已知是无页面级导航的入口页时不适用；当前页面身份不明、导航被裁切或目标未加载完整时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R02 · 多步骤任务显示当前步骤

- 检查 ID / 类型：`check-b85b2ec612172d8f` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：多步骤任务显示当前步骤；适用：已由流程说明或实际路径确认是多步骤任务，当前页属于其中一步。；检查：记录步骤关系、当前步骤与可见进度线索，结合标题和上下文判断当前环节是否可辨。；触发：多步骤与当前位置已确认，但相关区域完整可查时仍无法从标题、进度或上下文辨认当前环节。；弃权：已确认独立单页时不适用；仅见一页且无法确认步骤关系，或进度区域未取得时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R03 · 等待状态说明系统正在做什么

- 检查 ID / 类型：`check-22e1815a410df230` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：等待状态说明系统正在做什么；适用：当前取得的画面已经呈现加载、上传或处理中等等待状态；可来自截图、原型或运行记录。；检查：记录等待对象、可见文案与进度线索；运行时记录触发动作、观察时长及前后状态。；触发：已确认处于等待，完整相关区域仅有无法解释的转圈/空白，结合上下文仍不能判断正在处理的任务。；弃权：已确认普通非等待状态时不适用；无法确认等待状态、区域不全或动作结果未取得时证据不足；不能由点击前截图推断无反馈。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R04 · 完成状态说清结果

- 检查 ID / 类型：`check-76c244fc659400a1` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：完成状态说清结果；适用：已取得某次操作完成/成功状态，完成对象与上下文可确认。；检查：检查成功表达是否能说明已完成的动作、对象及确有必要的后续操作。；触发：完成状态已确认，但只有泛化成功信息，结合上下文仍无法判断完成了什么，或遗漏任务必需的下一步线索。；弃权：明确非完成状态时不适用；只有完成前画面、对象不明或结果区域缺失时证据不足；没有后续任务不要求强加下一步。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R05 · 关键文案避免未解释的内部术语

- 检查 ID / 类型：`check-2bb5fe73f34155f4` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：关键文案避免未解释的内部术语；适用：已确认非领域专家用户，存在非错误状态的关键任务文案；错误文案转R23。；检查：逐词记录任务必要性、内部术语含义来源、目标用户熟悉度依据与可见解释；词表只能证明含义，不能证明熟悉度。；触发：有依据确认非专家完成主任务必须理解某内部术语，该用户群不熟悉该词，界面又未解释。；弃权：明确没有相关对象或目标用户为领域专家时不适用；用户、含义、必要性或熟悉度影响结论却未知时证据不足。已解释/有熟悉依据时不能报问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R06 · 操作名称说明预期结果

- 检查 ID / 类型：`check-664782108908aa64` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：操作名称说明预期结果；适用：当前状态有主要按钮/入口，用户任务和动作目的已知。；检查：核对按钮文字、邻近内容与预期动作；运行结果可用于确认动作，但不能替代文案清晰度检查。；触发：主要按钮使用泛词或含义不符，结合邻近说明仍不能理解预期结果，或与明确动作目的冲突。；弃权：无主操作对象时不适用；任务/动作目的不明或上下文缺失时证据不足；周围内容已清楚说明时，泛词本身不构成问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R07 · 输入项名称说明所需信息

- 检查 ID / 类型：`check-4257c7d5d482da68` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：输入项名称说明所需信息；适用：存在需要填写的重要表单字段，字段任务可确认。；检查：核对字段名称与紧邻说明；运行时分别查看输入前后，确认必要名称线索是否仍可获取。；触发：字段无名称或名称模糊，结合邻近内容仍无法知道应填什么；运行证据显示输入后唯一必要说明消失并产生含义不明。；弃权：无输入对象时不适用；字段说明区域裁切、业务含义未知或未取得输入后画面时，对相应判断记证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R08 · 弹窗具有可见退出方式

- 检查 ID / 类型：`check-d804658e61f11379` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：弹窗具有可见退出方式；适用：存在普通信息/输入弹窗，完整边界可取得；高风险确认归R10。；检查：检查可见关闭/取消/返回方式；只有实际执行后才描述是否成功退出，行为验证转E01/E04。；触发：普通可中断弹窗占据焦点，完整边界和相关说明可查，但没有任何可见退出方式。；弃权：高风险确认或已确认不可中断流程不适用；边缘被裁、弹窗性质不明时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R09 · 多步骤页面具有可见返回方式

- 检查 ID / 类型：`check-4d7bed2833a63de6` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：多步骤页面具有可见返回方式；适用：确认当前是多步骤任务非首步，且不是高风险确认页。；检查：检查可见返回/退出入口，说明系统/浏览器返回是否在本次观察范围内；执行结果交E01/E04。；触发：当前非首步已确认且相关区域完整，页面与可观察系统入口均无可见返回或退出方式。；弃权：已确认首步/独立页或高风险确认时不适用；步骤未知、系统导航未涵盖且可能承担功能、页面不全时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R10 · 确认页允许取消高风险操作

- 检查 ID / 类型：`check-84a05727f19fc061` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：确认页允许取消高风险操作；适用：已确认删除/清空/永久变更等高风险操作的确认界面。；检查：检查清楚可见的取消/返回入口；默认仅观察，不为验证本条而执行真实危险操作。；触发：高风险性质已确认，确认区域完整且仅能执行，没有可见取消/返回入口。；弃权：明确非高风险确认时不适用；风险性质未知或取消区未取得时证据不足；无授权不执行真实副作用。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R11 · 同一动作使用一致名称

- 检查 ID / 类型：`check-51c656a3ed6ba95c` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：同一动作使用一致名称；适用：在同一材料或已确认的同版本多页面中，至少两个入口明确指向同一动作。；检查：记录动作同一性的依据，比较入口名称与解释；不同对象的名称差异不据此判动作不一致。；触发：已证实同一动作、同一语境使用互相矛盾或无解释的不同名称。；弃权：仅一个相关入口时不适用；动作是否相同、版本或语境未知时证据不足；功能/对象/阶段确有差异且名称合理时未见问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R12 · 同类控件呈现一致的视觉规则

- 检查 ID / 类型：`check-fdaa38d7f4a47526` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：同类控件呈现一致的视觉规则；适用：存在至少两个功能、层级、状态和设计语境可比的控件，可跨同版本页面。；检查：先核对可比条件，再比较形状、颜色、文字、状态表达，记录差异造成的类别/状态歧义。；触发：同类同状态控件存在无解释的显著规则差异，具体导致操作类别或状态含义混淆。；弃权：只有一个可比对象时不适用；控件层级/状态/规范依据未知时证据不足；有明确状态或主题理由的差异不报问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R13 · 必填项在填写前可识别

- 检查 ID / 类型：`check-8b5063e4d265f630` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：必填项在填写前可识别；适用：存在已知必填要求的表单字段；要求有来源。；检查：在填写前查看字段标记和整体说明，与已确认必填清单对照。；触发：已知必填字段既无字段标记也无清楚整体说明，提交前无法辨认必填要求。；弃权：明确无必填字段时不适用；哪些必填未知时证据不足；全部必填且有整体说明时未见问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R14 · 受格式限制的字段提供输入提示

- 检查 ID / 类型：`check-f810802614149257` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：受格式限制的字段提供输入提示；适用：字段有已确认的格式、长度或有效值限制。；检查：对照限制来源，查看填写前可获得的字段名、提示与有效示例。；触发：限制已知，但填写前无可理解线索，用户必须猜测要求；或提示与已确认限制冲突。；弃权：确认无特定格式限制时不适用；限制未知或提示区域不可查时证据不足；有效示例已清楚表达时未见问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R15 · 高后果操作确认页说明对象和动作

- 检查 ID / 类型：`check-91cd8c19b052ca05` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：高后果操作确认页说明对象和动作；适用：已确认是后果较大的操作确认界面，动作、对象及必要后果要求可确定。；检查：检查确认文字与邻近内容能否支持核对动作、对象和必要后果。；触发：完整上下文仍只有泛化确认，无法核对具体对象/动作，或遗漏已明确会影响决定的后果。；弃权：确认不是高后果确认时不适用；后果、对象未知或说明裁切时证据不足；无需为观察而实际执行危险动作。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R16 · 重要图标操作具有可见含义线索

- 检查 ID / 类型：`check-62bdd661564210b5` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：重要图标操作具有可见含义线索；适用：有影响已知主任务的图标操作，目标用户和任务语境可确定。；检查：检查文字标签、邻近解释及有依据的通用含义；必要时查看可取得的悬停/聚焦说明，并注明设备条件。；触发：任务必需的自定义图标没有可见说明，且有依据表明其含义在本语境中不可辨认。；弃权：无重要图标对象时不适用；重要性或用户熟悉度影响结论但未知、辅助说明未取得时证据不足；不因无常驻文字自动报问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-759649c4cb5599fc` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R18 · 相关输入和选项形成可识别的组

- 检查 ID / 类型：`check-a02fa6467e73010d` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：相关输入和选项形成可识别的组；适用：已确认存在多个相关输入字段或成组选项，业务分组关系已知；纯展示卡不纳入。；检查：逐项记录输入/可选/纯展示角色及其证据，核对关系来源，再检查组标题、间距与边界。；触发：输入/选择角色和分组关系已确认，相关与无关项混排，造成具体归属歧义。；弃权：确认仅纯展示、单个字段或单个选项时不适用；交互角色或分组关系未知、相关区域不全时证据不足。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R19 · 主要任务操作易于定位

- 检查 ID / 类型：`check-d48310a7cb934434` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：主要任务操作易于定位；适用：已确认主任务及对应主操作，取得其所在区域和必要上下文。；检查：记录主操作、竞争元素、位置/遮挡/层级关系；计算显著性只作线索，真人识别另行验证。；触发：有具体可见证据表明主操作被遮挡、与任务脱离或层级混淆，难以从当前界面定位。；弃权：确认无本条操作对象时不适用；主任务未知、区域未取得或仅有代理分值时证据不足；不能因按钮不最大而直接报问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R20 · 无关信息不压过主要任务

- 检查 ID / 类型：`check-9bfdcaf5dc71350e` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：无关信息不压过主要任务；适用：主任务及内容相关性有依据，主要内容与竞争区域可取得。；检查：比较任务内容和装饰/推广/重复信息，说明具体干扰机制；高饱和或元素多不单独构成违反。；触发：有依据确认无关内容明显压制、遮挡或挤占关键任务内容，并指出具体区域与影响。；弃权：无相关比较对象时不适用；任务相关性未知或区域不全时证据不足；目标需要的角色展示/奖励说明不能仅凭面积大判无关。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R21 · 错误状态指明问题位置

- 检查 ID / 类型：`check-ab6689786c977c19` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：错误状态指明问题位置；适用：已取得明确错误状态及其相关任务/操作范围。；检查：查看错误提示与字段/操作关联，记录错误原文和位置；多错误逐项检查。；触发：错误状态已确认，相关区域完整却只有笼统提示，无法辨别应处理的字段或操作。；弃权：确认不是错误状态时不适用；错误范围在未取得区域或状态性质未知时证据不足；只缺字段高亮但提示已清楚定位时不报问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R22 · 错误提示给出修正办法

- 检查 ID / 类型：`check-46b976e4fad76c51` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：错误提示给出修正办法；适用：已确认错误状态，且存在用户可以执行的修正或后续处理。；检查：检查当前提示和明确关联的帮助/恢复入口，核对建议步骤是否可执行；执行结果由E05记录。；触发：错误及可行修正途径已知，但当前信息没有可执行线索，或所给线索与已确认处理方法冲突。；弃权：确认无用户可执行处理时本条不适用；可修正性未知或帮助入口内容未取得时证据不足；已有明确关联修正说明时未见问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R23 · 错误提示使用用户可理解的语言

- 检查 ID / 类型：`check-ed52d1af69334981` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：错误提示使用用户可理解的语言；适用：存在面向已知目标用户的错误提示。；检查：记录错误原文，结合已知用户背景检查是否有可理解说明；技术码可作为辅助。；触发：面向非技术用户的错误信息只有内部码/异常栈/开发术语，且无可理解解释。；弃权：无错误提示对象时不适用；用户背景影响理解却未知、文字不清时证据不足；技术码同时附清楚说明或目标开发者确可理解时未见问题。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### R24 · 复杂任务提供就近帮助入口

- 检查 ID / 类型：`check-5995ec39dc8f3dc1` / rule
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：复杂任务提供就近帮助入口；适用：已确认目标用户在某关键复杂/领域字段或步骤上需要解释才能完成任务。；检查：记录复杂性与用户需要的依据，查看邻近说明/示例/帮助入口及实际取得内容。；触发：解释需要已确认，当前可查范围既无可理解说明，也无清楚关联且可取得的帮助，必须脱离任务自行猜测含义。；弃权：确认无需要解释的对象时不适用；解释需要、用户知识或帮助内容未知时证据不足；专家也可能需特定业务解释，不自动排除。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E01 · 关键任务路径衔接

- 检查 ID / 类型：`check-2dffeacf4fb39420` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：关键任务路径衔接；对象：任务起点、动作入口、目标页面/状态和已声明终点。；适用：存在需要跨页或跨状态的任务，关系可由已确认要求、原型连接或实际路径建立。；触发：目标关系明确且入口条件满足，本次操作到达错误对象、陷入可复现死路或无法抵达明确必需的下一步，且已排除访问/工具阻断。；弃权：关系或目标未知、权限失败、工具未执行、原型未实现分支时证据不足；明确独立静态任务无连接对象时不适用。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E02 · 跨页面对象与信息一致性

- 检查 ID / 类型：`check-03f8e5d8b6b232a4` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：跨页面对象与信息一致性；对象：同一角色、订单、任务或其他对象在不同页面/状态中的名称、属性、数量和指代。；适用：至少两个材料位置已确认属于同一对象、可比版本与可比条件。；触发：同一对象与条件已确认，名称/属性/数量发生无依据矛盾或错误传递，且不是已确认的合法变化。；弃权：对象同一性、版本或允许变化条件未知时证据不足；只有一个对象位置时不适用。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E03 · 操作与反馈状态对应

- 检查 ID / 类型：`check-8840beb832cbd370` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：操作与反馈状态对应；对象：动作触发、等待/选择/完成/失败等反馈及其对应操作对象。；适用：存在可执行动作或明确的状态设计，且动作应产生的变化有任务依据。；触发：动作实际触发有证据，但反馈缺失/错误关联/与明确预期冲突，范围和观察条件足以支持本次结论。；弃权：动作未触发、工具失败、只有前状态、观察条件不足或异步完成条件未知时证据不足；无状态变化检查对象时不适用。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E04 · 返回取消后的任务恢复

- 检查 ID / 类型：`check-c1812913ad5e6667` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：返回取消后的任务恢复；对象：返回、取消、退出再进入时的数据、选择、进度及定位。；适用：任务包含返回/取消/恢复分支，且预期的保留或重置要求可确定。；触发：返回/取消后的状态与已确认要求矛盾，造成已证实的任务丢失、错误续接或不应保留的数据残留。；弃权：保留规则不明、未执行分支或新旧状态不可比时证据不足；无返回/取消分支时不适用；不默认所有进度都必须保留。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E05 · 异常分支与恢复路径

- 检查 ID / 类型：`check-7026ab0b1b64b958` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：异常分支与恢复路径；对象：已取得的网络/输入/业务异常状态及可执行恢复步骤。；适用：已观察异常或提供明确异常设计，并存在应向用户交付的处理/恢复方式。；触发：条件明确且实际可测，恢复入口失效、进入同一无解循环或恢复结果违反明确要求；静态设计缺已确认必需分支只报设计层遗漏。；弃权：不能安全触发异常、无恢复依据或实际结果未取得时证据不足；任务确认无本条异常对象时不适用，不以未遇错误证明无错误。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E06 · 前置条件与操作开放状态

- 检查 ID / 类型：`check-d6ef10c2b4cc43aa` / method
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：前置条件与操作开放状态；对象：任务前置条件、按钮可用/禁用状态及操作结果。；适用：项目明确规定某操作的前置条件，且有可比状态或测试方式。；触发：已确认条件与当前操作开放/拦截行为矛盾；仅凭按钮外观可疑只形成待验证线索，不声称业务已绕过。；弃权：前置条件、账号状态或实际执行未知时证据不足；明确无该类条件时不适用；需真实发奖等未授权动作保持阻断。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-07b5c27398f0da8a` / goal
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

### E08 · 跨职能要求冲突识别与处理

- 检查 ID / 类型：`check-2f63eb8e2a1b8c57` / conflict
- 计划：applicable；契约夹具计划，不证明模型效果
- 对象：['fixture']
- 必需证据类型：[]
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：当前运行未执行/未完成此检查；继续时可重新安排。
- 判据/方法定义：跨职能要求冲突识别与处理；对象：策划/产品、设计、开发材料或用户决定对同一对象的要求与限制。；适用：两项以上要求/约束指向同一对象，可能无法同时满足或存在证据描述矛盾。；触发：原文可定位且同范围，两项要求无法同时成立。输出conflict记录，不未经裁决转换为产品违规。已裁决正式要求被实现违反时转E07。；弃权：同一对象或版本关系未知则待澄清；只有单份要求、或解释后可同时满足则不构成冲突。
- 证据链：
- `ev-1de5dd91a2a74736b54f879692909666` / requirement / 来源 `src-a9863169e999466a8e9a122eddc19290` / 版本 00f7146a910a403b55d2f40b6745ef7d4be29b1071a13703893f78fb7601d365
  - 定位：文档分块 0/1；行 1-1；字符 0-10
  - 内容：保存成功后显示结果。
  - 原始记录：[`artifact-cb404251e42d4671ab24babcff9f9800`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-cb404251e42d4671ab24babcff9f9800.txt)
  - 原始文件：[`artifact-33ce4a6ba52d47df869e616474af20f9`](artifacts/ev-1de5dd91a2a74736b54f879692909666-artifact-33ce4a6ba52d47df869e616474af20f9.txt)

## 八、发现与修改建议

当前没有通过证据核验的候选发现。

## 九、问题、冲突与业务决定

- `question-72293e54a16f4b7382f3914c26cc3664` [已回答] 请说明目标用户；影响检查：未关联；答复：AI回归答复，目标用户是课程案例中的设置页使用者。
- `question-0a900729dd434cdf93738a46266fd7ee` [未回答] 请说明目标用户；影响检查：未关联；答复：无

## 十、模型调用、输入与原始输出

| 调用 | 阶段/操作 | 模型 | 输入索引 | 输出摘要 | 原始响应 |
| --- | --- | --- | --- | --- | --- |
| `call-b35c752dae3d45bea57022a2af8861f8` | T03 / understand | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 目标 0；要求 0；意见 0；冲突 0 | [`artifact-229011b61e4a4feda171140b0bb3c538`](raw/call-b35c752dae3d45bea57022a2af8861f8-artifact-229011b61e4a4feda171140b0bb3c538.txt) |
| `call-cebc7ec858bc4fe1bb1a212b5d36042c` | T04 / plan_checks | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': … | 计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08 | [`artifact-dbdc45819e694da5aca84c6a2a7becd4`](raw/call-cebc7ec858bc4fe1bb1a212b5d36042c-artifact-dbdc45819e694da5aca84c6a2a7becd4.txt) |
| `call-43f58b0dd3314fef97001d81c9d96656` | T04 / plan_checks | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': ['R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': … | 计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16 | [`artifact-e6a4db9eb2274ca69af9e6d818f2f464`](raw/call-43f58b0dd3314fef97001d81c9d96656-artifact-e6a4db9eb2274ca69af9e6d818f2f464.txt) |
| `call-6eefbcd39f044dd9b86649297bc8fae0` | T04 / plan_checks | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': ['R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': … | 计划 8 项：R17, R18, R19, R20, R21, R22, R23, R24 | [`artifact-efb706c02fa244ce81866d9198b1470a`](raw/call-6eefbcd39f044dd9b86649297bc8fae0-artifact-efb706c02fa244ce81866d9198b1470a.txt) |
| `call-6bbabc3de7394985943a6c392fe945cc` | T04 / plan_checks | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': ['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': … | 计划 8 项：E01, E02, E03, E04, E05, E06, E07, E08 | [`artifact-cc47f2b9187440a5b6b124969044effe`](raw/call-6bbabc3de7394985943a6c392fe945cc-artifact-cc47f2b9187440a5b6b124969044effe.txt) |
| `call-4a1db98272374b0a97ef38fdb47f5d5c` | T05 / plan | test-fixture/contract-fixture | 原始索引：{'context_version': 2, 'operation_mode': '', 'source_ids': ['src-a9863169e999466a8e9a122eddc19290', 'src-05b8470854a74eeeba4afdfd5e34d946', 'src-b12060689dba442a8cde27785598c6db'], 'evidence_ids': ['ev-10c3fbe07e904b6a9d4d971206c80463', 'ev-1de5dd91a2a74736b54f879692909666', 'ev-2aed182361c4411ea51b304f599bf5b8'], 'image_evidence_ids': [], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | ready_for_review=False；动作 无 | [`artifact-748e9f164f9243bd83f72f1a4922bb38`](raw/call-4a1db98272374b0a97ef38fdb47f5d5c-artifact-748e9f164f9243bd83f72f1a4922bb38.txt) |

### call-b35c752dae3d45bea57022a2af8861f8 · T03 understand

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：目标 0；要求 0；意见 0；冲突 0
- 完整原始响应：[`artifact-229011b61e4a4feda171140b0bb3c538`](raw/call-b35c752dae3d45bea57022a2af8861f8-artifact-229011b61e4a4feda171140b0bb3c538.txt)

### call-cebc7ec858bc4fe1bb1a212b5d36042c · T04 plan_checks

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": ["R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08
- 完整原始响应：[`artifact-dbdc45819e694da5aca84c6a2a7becd4`](raw/call-cebc7ec858bc4fe1bb1a212b5d36042c-artifact-dbdc45819e694da5aca84c6a2a7becd4.txt)

### call-43f58b0dd3314fef97001d81c9d96656 · T04 plan_checks

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": ["R09", "R10", "R11", "R12", "R13", "R14", "R15", "R16"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16
- 完整原始响应：[`artifact-e6a4db9eb2274ca69af9e6d818f2f464`](raw/call-43f58b0dd3314fef97001d81c9d96656-artifact-e6a4db9eb2274ca69af9e6d818f2f464.txt)

### call-6eefbcd39f044dd9b86649297bc8fae0 · T04 plan_checks

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": ["R17", "R18", "R19", "R20", "R21", "R22", "R23", "R24"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R17, R18, R19, R20, R21, R22, R23, R24
- 完整原始响应：[`artifact-efb706c02fa244ce81866d9198b1470a`](raw/call-6eefbcd39f044dd9b86649297bc8fae0-artifact-efb706c02fa244ce81866d9198b1470a.txt)

### call-6bbabc3de7394985943a6c392fe945cc · T04 plan_checks

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": ["E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：E01, E02, E03, E04, E05, E06, E07, E08
- 完整原始响应：[`artifact-cc47f2b9187440a5b6b124969044effe`](raw/call-6bbabc3de7394985943a6c392fe945cc-artifact-cc47f2b9187440a5b6b124969044effe.txt)

### call-4a1db98272374b0a97ef38fdb47f5d5c · T05 plan

- 状态：validated；尝试：1；耗时：1ms
- 运行范围 / 输入来源：current / recorded
- 用量：{}
- 输入索引：{"context_version": 2, "operation_mode": "", "source_ids": ["src-a9863169e999466a8e9a122eddc19290", "src-05b8470854a74eeeba4afdfd5e34d946", "src-b12060689dba442a8cde27785598c6db"], "evidence_ids": ["ev-10c3fbe07e904b6a9d4d971206c80463", "ev-1de5dd91a2a74736b54f879692909666", "ev-2aed182361c4411ea51b304f599bf5b8"], "image_evidence_ids": [], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：ready_for_review=False；动作 无
- 完整原始响应：[`artifact-748e9f164f9243bd83f72f1a4922bb38`](raw/call-4a1db98272374b0a97ef38fdb47f5d5c-artifact-748e9f164f9243bd83f72f1a4922bb38.txt)

## 十一、复审、历史与限制

- 完整性：`partial`
- 当前运行限制：无
- 会话历史警告：评审任务 TASK01 没有形成可执行检查覆盖；报告不能视为任务全覆盖。；必需覆盖单元 coverage-321462a6160af2a1 尚未由检查或逐屏审查覆盖；报告不能视为完整。；必需覆盖单元 coverage-f49929bfbcc31137 尚未由检查或逐屏审查覆盖；报告不能视为完整。；会话不变量：必需覆盖单元 coverage-321462a6160af2a1 尚未覆盖。；会话不变量：必需覆盖单元 coverage-f49929bfbcc31137 尚未覆盖。；变更使关联结论过期；影响范围不明确时保守重查任务范围。
- 本轮没有登记复审项。

## 十二、可复核文件

报告包应同时包含 `report.json`、`process.json`、`checks.json`、`evidence.json`、`findings.json`、`stages/T01.json`—`stages/T10.json`、`report-showcase.md`、`report-summary.md`、`method/` 方法原文与哈希以及原始响应附件。单独打开 Markdown 时，模型原始响应和证据画面仍可通过会话 artifact 接口按 ID 读取。

> 本报告引用模型调用 6 次；测试夹具是。