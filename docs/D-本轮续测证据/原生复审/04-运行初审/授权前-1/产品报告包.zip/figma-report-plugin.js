const plan = {"source_root_node_id":"","source_title":"修书咨询登记","report_name":"修书咨询登记 · AI评审报告","title":"修书咨询登记 · AI评审报告","subtitle":"基于完整交互流程与逐屏技术审查","summary":{"checks_total":87,"executed":87,"design_met":2,"candidate_issues":0,"screen_candidate_issues":0,"insufficient_evidence":44,"screen_reviews":0,"screen_complete":0,"screen_partial":0,"screen_ui_elements":0,"screen_ocr_blocks":0},"screen_summary":[],"gaps":[{"text":"是否授权动作：ev-5bb645c490a9466e9d64fd29d0c2d8ab显示返回后再次核对的信息为周五14:00–14:30、二层服务台，“提交登记”可用。点击后取得完成页，与该最终核对信息对照，检查TASK1/BR2、REQ3及E01—E03、R04；尚未判定提交成功。任务卡明确登记仅在当前页面生效，且…"},{"text":"时段是否明确要求必选，且默认选中的时段是否已满足该要求？"},{"text":"目标用户对登记流程的熟悉程度如何，是否有已知必须解释才能完成的字段或步骤？"},{"text":"除已有三条设计要求外，提交登记是否存在明确的资格或拦截条件？如有，请提供规则。"}],"annotations":[],"heuristic_summary":{},"colors":{"issue":"#C62828","gap":"#9A6700","review":"#0B63CE","pass":"#18794E","report_bg":"#F6F8FB","panel_bg":"#FFFFFF","text":"#172033","muted":"#56637A","border":"#C9D2E0"},"session_id":"session-8e92a333d79d4678bac0b330efcd3e94","run_id":"run-563e5636979549029e54786e942b1416"};
const reportFonts = {
  regular: { family: "Noto Sans SC", style: "Regular" },
  medium: { family: "Noto Sans SC", style: "Medium" },
  bold: { family: "Noto Sans SC", style: "Bold" }
};
await Promise.all(Object.values(reportFonts).map(font => figma.loadFontAsync(font)));

const original = await figma.getNodeByIdAsync(plan.source_root_node_id);
if (!original || original.type !== "FRAME") throw new Error("Source interaction frame not found");
const page = original.parent;
if (!page || page.type !== "PAGE") throw new Error("Source frame must be on a page");
await figma.setCurrentPageAsync(page);

const duplicateName = `${plan.source_title} · AI审查标注副本`;
const reuseWrapper = page.findOne(n =>
  n.type === "FRAME" &&
  n.name.includes(plan.source_title) &&
  n.name.includes("AI审查标注稿")
);
let duplicate = reuseWrapper
  ? reuseWrapper.findOne(n => n.name.includes("AI审查标注副本"))
  : page.findOne(n => n.name === duplicateName);
if (!duplicate) {
  duplicate = original.clone();
  duplicate.name = duplicateName;
  duplicate.x = original.x + original.width + 320;
  duplicate.y = original.y;
  page.appendChild(duplicate);
}
if (duplicate.type !== "FRAME") throw new Error("Annotated copy must be a frame");
if (duplicate.layoutMode !== "NONE") {
  duplicate.primaryAxisSizingMode = "FIXED";
  duplicate.counterAxisSizingMode = "FIXED";
}
duplicate.resize(original.width, original.height);
const reviewWrapper = duplicate.parent && duplicate.parent.type === "FRAME"
  ? duplicate.parent : null;
const reviewBounds = duplicate.absoluteBoundingBox || {
  x: duplicate.x,
  y: duplicate.y,
  width: duplicate.width,
  height: duplicate.height
};
const wrapperBounds = reviewWrapper && reviewWrapper.absoluteBoundingBox
  ? reviewWrapper.absoluteBoundingBox
  : { x: reviewBounds.x, y: reviewBounds.y, width: reviewBounds.width, height: reviewBounds.height };

const oldPanel = page.findOne(n => n.name === "交互案 · AI审查说明栏");
if (oldPanel) oldPanel.remove();
const oldLayer = reviewWrapper
  ? reviewWrapper.findOne(n => n.name.includes("AI彩色标注层"))
  : null;
if (oldLayer) oldLayer.remove();
const annotationPrefix = `AI审查批注 · ${plan.source_title} · `;
for (const child of [...duplicate.children]) {
  if (child.name.startsWith(annotationPrefix)) child.remove();
}
for (const child of [...page.children]) {
  if (child.name.startsWith(annotationPrefix)) child.remove();
}

function rgba(hex, opacity = 1) {
  const clean = hex.replace("#", "");
  return {
    type: "SOLID",
    color: {
      r: parseInt(clean.slice(0, 2), 16) / 255,
      g: parseInt(clean.slice(2, 4), 16) / 255,
      b: parseInt(clean.slice(4, 6), 16) / 255
    },
    opacity
  };
}

function addText(parent, content, font, size, color, width) {
  const node = figma.createText();
  node.fontName = font;
  node.fontSize = size;
  node.fills = [rgba(color)];
  node.characters = content;
  node.resize(width, node.height);
  node.textAutoResize = "HEIGHT";
  parent.appendChild(node);
  node.layoutSizingHorizontal = "FILL";
  return node;
}

function shortText(value, limit = 220) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > limit ? text.slice(0, limit - 1) + "…" : text;
}

const occupiedNotes = [];
function overlaps(first, second) {
  return !(
    first.x + first.width <= second.x ||
    second.x + second.width <= first.x ||
    first.y + first.height <= second.y ||
    second.y + second.height <= first.y
  );
}
const numberedNodes = duplicate.findAll(node =>
  node.type === "TEXT" &&
  node.visible &&
  /^\s*\d+[.、]/.test(node.characters || "")
);
function nearestNumbered(highlightAbs) {
  let best = null;
  let bestDistance = Infinity;
  const hx = highlightAbs.x + highlightAbs.width / 2;
  const hy = highlightAbs.y + highlightAbs.height / 2;
  for (const node of numberedNodes) {
    const box = node.absoluteBoundingBox;
    if (!box) continue;
    const nx = box.x + box.width / 2;
    const ny = box.y + box.height / 2;
    const distance = Math.hypot(nx - hx, ny - hy);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = { node, box };
    }
  }
  return best;
}
const annotationNodeIds = [];
for (let index = 0; index < plan.annotations.length; index++) {
  const annotation = plan.annotations[index];
  const target = {
    x: annotation.target_x,
    y: annotation.target_y,
    width: annotation.target_width,
    height: annotation.target_height
  };
  let highlight = target;
  if (annotation.bbox_hint) {
    highlight = {
      x: target.x + target.width * Number(annotation.bbox_hint.x || 0),
      y: target.y + target.height * Number(annotation.bbox_hint.y || 0),
      width: Math.max(18, target.width * Number(annotation.bbox_hint.width || 0)),
      height: Math.max(18, target.height * Number(annotation.bbox_hint.height || 0))
    };
  }
  const outline = figma.createRectangle();
  outline.name = `${annotationPrefix}目标框 ${index + 1} · ${annotation.title}`;
  outline.x = reviewBounds.x + highlight.x;
  outline.y = reviewBounds.y + highlight.y;
  outline.resize(highlight.width, highlight.height);
  outline.fills = [rgba(annotation.color, 0.05)];
  outline.strokes = [rgba(annotation.color)];
  outline.strokeWeight = 4;
  outline.strokeAlign = "INSIDE";
  page.appendChild(outline);
  annotationNodeIds.push(outline.id);

  const highlightAbs = {
    x: reviewBounds.x + highlight.x,
    y: reviewBounds.y + highlight.y,
    width: highlight.width,
    height: highlight.height
  };
  const nearest = nearestNumbered(highlightAbs);
  const anchorBox = nearest ? nearest.box : highlightAbs;
  let noteX = anchorBox.x;
  let noteY = anchorBox.y + anchorBox.height + 8;
  const noteWidth = 360;
  if (noteX + noteWidth > reviewBounds.x + reviewBounds.width - 20) {
    noteX = Math.max(
      reviewBounds.x + 20,
      reviewBounds.x + reviewBounds.width - noteWidth - 20
    );
  }
  const noteBg = figma.createRectangle();
  noteBg.name = `${annotationPrefix}底色 ${index + 1} · ${annotation.title}`;
  noteBg.cornerRadius = 8;
  noteBg.fills = [rgba(plan.colors.panel_bg, 0.96)];
  noteBg.strokes = [rgba(annotation.color)];
  noteBg.strokeWeight = 2;
  noteBg.strokeAlign = "INSIDE";
  page.appendChild(noteBg);
  annotationNodeIds.push(noteBg.id);
  const header = figma.createText();
  header.name = `${annotationPrefix}标题 ${index + 1} · ${annotation.title}`;
  header.fontName = reportFonts.bold;
  header.fontSize = 18;
  header.fills = [rgba(annotation.color)];
  header.characters = `AI${String(index + 1).padStart(2, "0")} · ${annotation.heuristic_ids.join("/") || "无判据"}`;
  header.resize(noteWidth, header.height);
  header.textAutoResize = "HEIGHT";
  page.appendChild(header);
  annotationNodeIds.push(header.id);

  const body = figma.createText();
  body.name = `${annotationPrefix}正文 ${index + 1} · ${annotation.title}`;
  body.fontName = reportFonts.medium;
  body.fontSize = 15;
  body.fills = [rgba(plan.colors.text)];
  body.characters = `${annotation.title}
${annotation.detail}`;
  body.resize(noteWidth, body.height);
  body.textAutoResize = "HEIGHT";
  page.appendChild(body);
  annotationNodeIds.push(body.id);

  const action = figma.createText();
  action.name = `${annotationPrefix}建议 ${index + 1} · ${annotation.title}`;
  action.fontName = reportFonts.regular;
  action.fontSize = 13;
  action.fills = [rgba(plan.colors.muted)];
  action.characters = `建议：${shortText(annotation.action, 120)}`;
  action.resize(noteWidth, action.height);
  action.textAutoResize = "HEIGHT";
  page.appendChild(action);
  annotationNodeIds.push(action.id);

  const noteHeight = header.height + body.height + action.height + 18;
  for (let attempt = 0; attempt < 30; attempt++) {
    const box = { x: noteX, y: noteY, width: noteWidth, height: noteHeight };
    const hit = occupiedNotes.find(item => overlaps(item, box));
    if (!hit) break;
    noteY = hit.y + hit.height + 12;
  }
  if (noteY + noteHeight > reviewBounds.y + reviewBounds.height - 20) {
    noteY = Math.max(
      reviewBounds.y + 20,
      reviewBounds.y + reviewBounds.height - noteHeight - 20
    );
  }
  noteBg.x = noteX - 8;
  noteBg.y = noteY - 8;
  noteBg.resize(noteWidth + 16, noteHeight + 12);
  header.x = noteX;
  header.y = noteY;
  body.x = noteX;
  body.y = noteY + header.height + 4;
  action.x = noteX;
  action.y = body.y + body.height + 4;
  occupiedNotes.push({ x: noteX, y: noteY, width: noteWidth, height: noteHeight });
}

const existingReport = page.findOne(n => n.name === plan.report_name);
if (existingReport) existingReport.remove();

const report = figma.createAutoLayout("VERTICAL", {
  name: plan.report_name,
  itemSpacing: 22
});
report.resize(1080, 100);
report.paddingTop = 44;
report.paddingBottom = 44;
report.paddingLeft = 44;
report.paddingRight = 44;
report.cornerRadius = 24;
report.fills = [rgba(plan.colors.report_bg)];
report.strokes = [rgba(plan.colors.border)];
report.strokeWeight = 2;
report.x = reviewBounds.x;
report.y = wrapperBounds.y + wrapperBounds.height + 420;

function section(title, accent) {
  const frame = figma.createAutoLayout("VERTICAL", { name: title, itemSpacing: 14 });
  frame.paddingTop = 22;
  frame.paddingBottom = 22;
  frame.paddingLeft = 24;
  frame.paddingRight = 24;
  frame.cornerRadius = 12;
  frame.fills = [rgba(plan.colors.panel_bg)];
  frame.strokes = [rgba(accent, 0.8)];
  frame.strokeWeight = 2;
  report.appendChild(frame);
  frame.layoutSizingHorizontal = "FILL";
  addText(frame, title, reportFonts.bold, 24, accent, 980);
  return frame;
}

addText(report, plan.title, reportFonts.bold, 42, plan.colors.text, 980);
addText(report, plan.subtitle, reportFonts.regular, 18, plan.colors.muted, 980);
addText(
  report,
  `评审完成 · 检查 ${plan.summary.executed}/${plan.summary.checks_total} · 跨项发现 ${plan.summary.candidate_issues} · 系统性问题 ${plan.summary.screen_candidate_issues} · 证据不足 ${plan.summary.insufficient_evidence}`,
  reportFonts.medium, 18, plan.colors.review, 980
);

const overview = section("01 · 评审摘要", plan.colors.review);
addText(
  overview,
  `逐屏技术审查 ${plan.summary.screen_reviews} 个完整界面，其中完整完成 ${plan.summary.screen_complete} 个、部分完成 ${plan.summary.screen_partial} 个；累计识别 UI 元素 ${plan.summary.screen_ui_elements} 个、OCR 文本块 ${plan.summary.screen_ocr_blocks} 个。`,
  reportFonts.regular, 17, plan.colors.text, 980
);
addText(
  overview,
  "完整完成表示 OCR、元素、统计和屏内规则审查均已产出；部分完成会保留具体限制，不把空元素结果当作通过。",
  reportFonts.regular, 15, plan.colors.muted, 980
);
const heuristicRows = Object.entries(plan.heuristic_summary || {});
addText(
  overview,
  heuristicRows.length
    ? `命中启发式维度：${heuristicRows.map(([id, count]) => `${id} × ${count}`).join(" · ")}`
    : "本轮候选问题未绑定可识别的启发式维度，不能把流程缺项冒充交互结论。",
  reportFonts.regular, 16, plan.colors.text, 980
);

const findingsSection = section("02 · 候选问题", plan.colors.issue);
for (let i = 0; i < plan.annotations.length; i++) {
  const item = plan.annotations[i];
  addText(findingsSection, `F${String(i + 1).padStart(3, "0")} · ${item.title}`, reportFonts.bold, 20, plan.colors.issue, 940);
  addText(findingsSection, shortText(item.detail, 360), reportFonts.regular, 16, plan.colors.text, 940);
  addText(findingsSection, `建议：${shortText(item.action, 220)}`, reportFonts.medium, 15, plan.colors.muted, 940);
}

const screensSection = section("03 · 逐屏技术审查", plan.colors.review);
for (const screen of plan.screen_summary) {
  addText(
    screensSection,
    `${screen.page_type || screen.node_id} · ${screen.status === "completed" ? "完整完成" : "部分完成"} · UI ${screen.ui_element_count} · OCR ${screen.ocr_block_count} · 屏内问题 ${screen.issue_count}`,
    reportFonts.regular, 16, screen.status === "completed" ? plan.colors.text : plan.colors.gap, 940
  );
}

const gapsSection = section("04 · 待补证据与业务确认", plan.colors.gap);
for (let i = 0; i < plan.gaps.length; i++) {
  addText(
    gapsSection,
    `G${String(i + 1).padStart(2, "0")} · ${shortText(plan.gaps[i].text, 300)}`,
    reportFonts.regular, 16, plan.colors.text, 940
  );
}

const legendSection = section("05 · 标注说明", plan.colors.pass);
addText(legendSection, "红色：副本编号、目标框与系统性问题；黄色与青色：仅用于报告中的证据缺口和审查统计。", reportFonts.regular, 16, plan.colors.text, 940);
addText(legendSection, "标注位于原交互案的独立副本上，原稿未修改。", reportFonts.medium, 16, plan.colors.pass, 940);
addText(legendSection, `会话：${plan.session_id} · 运行：${plan.run_id}`, reportFonts.regular, 13, plan.colors.muted, 940);

return {
  success: true,
  reportId: report.id,
  duplicateId: duplicate.id,
  annotationCount: plan.annotations.length,
  reportBounds: { x: report.x, y: report.y, width: report.width, height: report.height },
  createdNodeIds: [report.id, ...annotationNodeIds]
};
