# 协同交互方案评审报告

> 会话：`session-a91d9c8434ac4fffa36cb5c073913825`  
> 运行：`run-c4817bddd6224468b72ff9e903424f13`  
> 报告版本：`1`  
> 状态 / 完整性：`completed` / `partial`  
> 技术路径：`A 0.2-method-draft / T01–T10`  
> 判据版本：`0.2-method-draft`  
> 证据模式：`design`

## 一、结论摘要

本次围绕“从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。”执行 33 项检查。执行状态：executed=4；not_executed=29；判断状态：insufficient_evidence=3；no_visible_issue=1。`complete` 仅表示计划项均有可追溯处置，不代表产品全部通过。

当前没有通过证据核验的候选发现；请结合未决项理解范围。

## 二、版本、路径与复现

| 字段 | 当前值 |
| --- | --- |
| 会话 / 运行 | `session-a91d9c8434ac4fffa36cb5c073913825` / `run-c4817bddd6224468b72ff9e903424f13` |
| 上下文 / 报告版本 | 1 / 1 |
| 会话契约 | `session-1.0` |
| 判据 / 方法 | `0.2-method-draft` / A T01–T10 |
| 方法目录 | 方法专家开发交付-v0.2 |
| 判据来源 | {'name': "Jakob Nielsen's 10 Usability Heuristics for User Interface Design", 'url': 'https://www.nngroup.com/articles/ten-usability-heuristics/', 'relationship': '以下条目由小组据宽泛原则操作化，并非源文逐条摘录或正式规范符合性声明'} |
| 模型 | codex_cli/gpt-6-astra |
| 是否测试夹具 | 否 |
| 方法文件指纹 | `{'00先看这个！！！！-阅读与开发交接.md': '6dca7b14918a08d65e40362bfec2fc40a1f8f1d0492e4f356b2ac9b8f00d051e', '01-04-场景输入流程与技术路径.md': 'fe432cf3851ad10528e53d6fecc14e9ffaba0a4fafd96a1b6ee61c4007c28347', '05-24条判据修订与变更对照.md': 'bd2f82f8d8e539d2011b0b684d77de775b0149ec0e14736717944f2057847c99', '05-判据库-v0.2.json': 'b785eb9c6b64b5d9ceb87ca76430af4a2658c944c9aff99a97ce9298bdf54af7', '05-判据执行补充-v0.2.json': '8e502b943023c7e39a8da6a479c1cc09f621c9474520e4f116cae0553bc9c24d', '05-逐字段变更对照.csv': 'd0b1d25442662ecf10150e923b98b8049ad7291e2bf56653690a138392d8307d', '06-新场景方法-v0.2.json': '1702aa0350c41ced0363a41d73c46aeb547d60d7299616964875b51ce8fd689c', '06-新场景方法与正反例.md': 'e21e0996cc25bc218f5e24e2c3a7aa66649001eb58ad00e84fcb5fc88b48ca26', '07-会话变更重查与复审规则.md': 'c9a5f573648a20094f4b0c4602043979b33ea3cb935a6976b641cf57b539f025', '08-问题表达严重度与评价验收.md': '4d92cfcfdb8417a20678995528ea0180f6182eb52b0b2becbb3a7fc44886eead', '09-开发验收用例.json': 'fc85e0bd301b081d393ab4764f0f0b59003e2462d842ebee91bc990eb9f41f60', '09-开发验收用例.md': 'e2ca3487871026558697e1283734849af2ef94de25b984ade9ae8334a73a2fd3', '10-来源索引.json': 'e6147e42231bb4602cb506caa7a2d6ff69812b2d7d1289731a33220db667017a', '11-交付校验结果.json': '3ec123147dae0c46a6bd2a473a0c5f0bbe5f1d311f42bc2568e41b63b5694cad'}` |

复现依据是本次保存的原始材料、证据、模型原始响应、检查计划与判断记录；不得用新运行结果覆盖本版本。

判定口径：R/E01–E06 使用 `candidate_issue`、`no_visible_issue`、`insufficient_evidence`、`not_applicable`；G/REQ/E07 使用 `met`、`observed_violation`、`insufficient_evidence`；E08 使用 `open`、`no_conflict`、`needs_clarification`、`resolved`。`complete` 只表示计划项均有处置，不表示问题数为零或运行效果已验证。

## 三、输入材料

| 来源 | 类型/角色 | 版本 | 读取状态 | 证据数 | 入口 |
| --- | --- | --- | --- | ---: | --- |
| `src-fe841475860b4216bf7f688815b71d77` 通知设置 | image / design | 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7 | success | 1 |  |
| `src-a7375bb4159844cf9033852eb50f1de1` initial_purpose | document / review_instruction | context-1 | success | 1 | user://initial_purpose |

<img src="artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin" alt="通知设置" style="display:block;max-width:100%;width:640px;height:auto;margin:12px 0;border:1px solid #ddd;border-radius:4px;" loading="lazy">

## 四、T01–T10 逐步输入输出

| 阶段 | 状态 | 输入摘要 | 输出摘要 | 模型调用 | 模型耗时 |
| --- | --- | --- | --- | --- | ---: |
| T01 接收与能力检查 | completed | {'purpose': '从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。', 'source_count': 2} | {'session_id': 'session-a91d9c8434ac4fffa36cb5c073913825', 'capabilities': {'schema_version': 'session-1.0', 'methods_version': '0.2-method-draft', 'technical_path_version': 'A-0.2/T01-T10', 'method_root': '方法专家开发交付-v0.2', 'method_validation': {'delivery_version': '0.2-method-draft', 'checked_files': 12, 'mismatches': 0}, 'rules': 24, '… | 无 | 0ms |
| T02 材料读取与证据登记 | completed | {'sources': [{'source_id': 'src-fe841475860b4216bf7f688815b71d77', 'kind': 'image', 'reference': '', 'role': 'design', 'version': '490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7'}, {'source_id': 'src-a7375bb4159844cf9033852eb50f1de1', 'kind': 'document', 'reference': 'user://initial_purpose', 'role': 'review_instruction', 'version': 'contex… | {'evidence_count': 2, 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'source_status': {'src-fe841475860b4216bf7f688815b71d77': 'success', 'src-a7375bb4159844cf9033852eb50f1de1': 'success'}, 'warnings': ['逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.', '评审任务 TASK02 没有形成… | 无 | 0ms |
| T03 任务与材料理解 | completed | {'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'context_version': 1} | {'task_summary': '根据「个人设置」中的「通知偏好」截图，梳理如何查看提醒状态、找到调整选项和保存入口。评审范围限于静态画面。', 'target_user_summary': '', 'review_tasks': [{'task_id': 'TASK01', 'text': '查看课程提醒和作业到期提醒各自的当前状态。', 'success_criteria': '能区分每行提供的选项与当前选择。「课程提醒」的「开启」为蓝底，「关闭」为白底；「作业到期」并列显示 ON 和 OFF，画面未明确区分当前选项。', 'evidence_ids': ['ev-940de4c4949d4daf908fff976890d19b', 'ev-675baa5e1eb44545853a2a89c5588cc2'], 'source_ids': ['src-a7375bb4159844cf9033852eb50f1de1', '… | call-da546992d52140819ef26af13268c3fb | 17766ms |
| T04 检查规划与适用性筛选 | completed | {'goal_refs': [], 'requirement_refs': [], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b']} | {'check_count': 33, 'applicability': {'applicable': 7, 'needs_context': 13, 'not_applicable': 13, 'not_assessed': 0}, 'check_refs': ['E03', 'R17', 'R17', 'R12', 'R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R13', 'R14', 'R15', 'R16', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E04', 'E05', 'E06', 'E07', 'E08']} | call-4ac64329174e442faeaa1f903df01212, call-ee2592f7cba149afaa779e3b97ca7be6, call-d0279e5492674398b0708326d7364695, call-bd054e21a9554d949ccee0b2da3097f7 | 135796ms |
| T05 执行、取证与逐屏技术审查 | completed | {'authorized_interaction': False, 'planned_check_refs': ['E03', 'R17', 'R17', 'R12', 'R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08', 'R09', 'R10', 'R11', 'R13', 'R14', 'R15', 'R16', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E04', 'E05', 'E06', 'E07', 'E08']} | {'action_count': 0, 'actions': [], 'action_outcomes': [], 'transition_count': 0} | call-ff0b6e338e624c9882f328325cc22a73, call-6b331ee71efb45ea9f73740a587d0446 | 15406ms |
| T06 逐项判断 | partial | {'check_ids': ['check-c7e35f858aff083c', 'check-a272e2026ec8dc89', 'check-ec7d904b7b853abf', 'check-aa692394b0c7730a', 'check-63ac85d885b14585', 'check-d6ed41463b8d835b', 'check-5cc375d9fe46f469', 'check-d809183ae225ebc4', 'check-8c4214d27328a886', 'check-e08fd137085283b8', 'check-5aa0cdad59cfc8f8', 'check-8bb4821aa0e16e5e', 'check-fa7c19163c03fdcd', 'check-… | {'decisions': {'insufficient_evidence': 3, 'no_visible_issue': 1}, 'judgments': [{'check_id': 'check-c7e35f858aff083c', 'ref': 'E03', 'decision': 'insufficient_evidence', 'reason': 'E03 静态检查两行提醒的当前状态表达。「课程提醒」用蓝底突出「开启」；「作业到期」的 ON 和 OFF 共用浅色底，没有可辨认的标记说明当前状态。；没有通过证据核验的完整发现，保留为证据不足。', 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2']}, {'check_id': 'check-a272e2026ec8dc89', 'ref': 'R17', 'decision': 'no_visible_iss… | call-a824cf45df6b49508ae4317a41ddf71a | 22344ms |
| T07 证据核验与发现归并 | not_needed | {'candidate_finding_count': 0} | {'verified_finding_ids': [], 'rejected': ['发现退回补证：「作业到期」行可见 ON／OFF，当前状态难以辨认；结构/状态 claim 缺少 OCR、元素或结构数据。']} | 无 | 0ms |
| T08 讨论、变更与重查 | completed | {'context_version': 1, 'events': [{'at': '2026-11-03T18:56:48.353413+00:00', 'actor_type': 'human', 'type': 'purpose', 'content': '从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。'}, {'at': '2026-11-03T18:56:48.369093+00:00', 'actor_type': 'program', 'type': 'run_started', 'run_id': 'run-c4817bddd6224468b72ff9e903424f13', 'warning_count': 0}, {'at': '2026-11-03T19:00:00… | {'questions': [{'question_id': 'question-a210086ed5f442c1bc8ec07086b6d72a', 'text': '这张设计图中，「作业到期」预期呈现哪种状态：ON、OFF，还是尚未选择？', 'reason': '预期取值可用于判断选中标记是否缺失，以及两行的选中样式能否直接比较。', 'check_ids': ['check-ec7d904b7b853abf', 'check-aa692394b0c7730a'], 'blocking': False, 'answered': False, 'answer': '', 'kind': 'context', 'source_id': None, 'action_id': None, 'answer_actor': 'unknown'}], 'conflict_dispositions': []} | 无 | 0ms |
| T09 报告与保存 | completed | {'run_id': 'run-c4817bddd6224468b72ff9e903424f13', 'check_count': 33} | {'report_version': 1, 'report_completeness': 'partial', 'status': 'completed'} | 无 | 0ms |
| T10 修改后复审 | not_needed | {'previous_finding_ids': []} | {'rechecks': []} | 无 | 0ms |

```mermaid
flowchart LR
    T01["T01 接收与能力检查<br/>completed"]
    T02["T02 材料读取与证据登记<br/>completed"]
    T03["T03 任务与材料理解<br/>completed"]
    T04["T04 检查规划与适用性筛选<br/>completed"]
    T05["T05 执行、取证与逐屏技术审查<br/>completed"]
    T06["T06 逐项判断<br/>partial"]
    T07["T07 证据核验与发现归并<br/>not_needed"]
    T08["T08 讨论、变更与重查<br/>completed"]
    T09["T09 报告与保存<br/>completed"]
    T10["T10 修改后复审<br/>not_needed"]
    T01 --> T02
    T02 --> T03
    T03 --> T04
    T04 --> T05
    T05 --> T06
    T06 --> T07
    T07 --> T08
    T08 --> T09
    T09 --> T10
```


### T01 · 接收与能力检查

- 状态：`completed`
- 输入：评审目的 1 条；来源 2 项
- 输出：契约 session-1.0；方法 0.2-method-draft；R=24；E=8
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T02 · 材料读取与证据登记

- 状态：`completed`
- 输入：来源 2 项
- 输出：证据 2 条；来源状态 读取成功=2
- 模型调用：无
- 模型耗时：0ms
- 关联证据：ev-675baa5e1eb44545853a2a89c5588cc2, ev-940de4c4949d4daf908fff976890d19b

### T03 · 任务与材料理解

- 状态：`completed`
- 输入：用于理解的材料证据 2 条
- 输出：目标 0；要求 0；意见 0；冲突 0；未知 3
- 模型调用：call-da546992d52140819ef26af13268c3fb
- 模型耗时：17766ms
- 关联证据：ev-675baa5e1eb44545853a2a89c5588cc2, ev-940de4c4949d4daf908fff976890d19b

### T04 · 检查规划与适用性筛选

- 状态：`completed`
- 输入：目标 0；要求 0；可用证据 2
- 输出：检查 33 项；不适用=13；待补上下文=13；未评估=0；适用=7
- 模型调用：call-4ac64329174e442faeaa1f903df01212, call-ee2592f7cba149afaa779e3b97ca7be6, call-d0279e5492674398b0708326d7364695, call-bd054e21a9554d949ccee0b2da3097f7
- 模型耗时：135796ms
- 关联证据：ev-675baa5e1eb44545853a2a89c5588cc2, ev-940de4c4949d4daf908fff976890d19b

### T05 · 执行、取证与逐屏技术审查

- 状态：`completed`
- 输入：交互授权 否；计划检查 33
- 输出：动作 0；状态变化 0；结果 无
- 模型调用：call-ff0b6e338e624c9882f328325cc22a73, call-6b331ee71efb45ea9f73740a587d0446
- 模型耗时：15406ms
- 关联证据：无

### T06 · 逐项判断

- 状态：`partial`
- 输入：检查 33；计划证据 2
- 输出：未发现可见问题=1；证据不足=3
- 模型调用：call-a824cf45df6b49508ae4317a41ddf71a
- 模型耗时：22344ms
- 关联证据：ev-675baa5e1eb44545853a2a89c5588cc2

### T07 · 证据核验与发现归并

- 状态：`not_needed`
- 输入：候选发现 0
- 输出：通过核验 0；退回 1
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T08 · 讨论、变更与重查

- 状态：`completed`
- 输入：上下文版本 1
- 输出：问题 1；业务决定 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T09 · 报告与保存

- 状态：`completed`
- 输入：运行 run-c4817bddd6224468b72ff9e903424f13；检查 33
- 输出：报告 v1；完整性 部分；状态 已完成
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T10 · 修改后复审

- 状态：`not_needed`
- 输入：旧问题 0
- 输出：复审记录 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

## 五、目标要求对应与材料理解

- 任务理解：根据「个人设置」中的「通知偏好」截图，梳理如何查看提醒状态、找到调整选项和保存入口。评审范围限于静态画面。
- 目标用户：未明确
- 未知：材料未说明产品原始目标或正式业务验收条件。
- 未知：「界面主题」和「文字大小」各有两个选项，截图未明确标出各自的当前选择。「消息工具」的三个图标也没有可见的文字说明，其用途未知。
- 未知：材料未说明选择是否立即生效、是否必须保存，以及保存后的反馈和持久化结果。

### 已观察状态与动作迁移

| 状态 | 来源 | 定位 | 入/出 | 已接入检查 |
| --- | --- | --- | ---: | --- |
| `490a35029c5a2cd09ff58635` | src-fe841475860b4216bf7f688815b71d77 | {"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900} | 0/0 | 是 |

### 必需覆盖矩阵

| 覆盖单元 | 任务 | 状态 | 来源 | 已覆盖 | 缺证类型 |
| --- | --- | --- | --- | --- | --- |
| `coverage-f65a5f393ba15ec3` | TASK01 | 490a35029c5a2cd09ff58635 | src-fe841475860b4216bf7f688815b71d77 | 是 | — |
| `coverage-14e5e808f9eb902d` | TASK02 | 490a35029c5a2cd09ff58635 | src-fe841475860b4216bf7f688815b71d77 | 否 | state_not_reviewed |

## 六、证据链总表

| 证据 | 来源 / 类型 | 版本 | 定位 | 内容摘要 | 被哪些检查/发现使用 |
| --- | --- | --- | --- | --- | --- |
| `ev-675baa5e1eb44545853a2a89c5588cc2` | src-fe841475860b4216bf7f688815b71d77 / design | 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7 | {"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false} | 用户提供的静态界面，不证明点击后行为。 | E03, R17, R17, R12, R01, R02, R03, R04, R05, R06, R07, R08, R09, R10, R11, R13, R14, R15, R16, R18, R19, R20, R21, R22, R23, R24, E01, E02, E04, E06, E07, E08 |
| `ev-940de4c4949d4daf908fff976890d19b` | src-a7375bb4159844cf9033852eb50f1de1 / statement | context-1 | 文档分块 0/1；行 1-1；字符 0-36 | 从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。 | E03, R05, R06, R16, R18, R19, R20, R24, E01, E04, E05, E07, E08 |

## 七、逐项检查与判断

| 编号 | 类型 | 适用性 | 执行 | 判断 | 证据 | 发现 |
| --- | --- | --- | --- | --- | --- | --- |
| `E03` 操作与反馈状态对应 | method | applicable | executed | insufficient_evidence | ev-675baa5e1eb44545853a2a89c5588cc2 | 无 |
| `R17` 当前选择状态可见 | rule | applicable | executed | no_visible_issue | ev-675baa5e1eb44545853a2a89c5588cc2 | 无 |
| `R17` 当前选择状态可见 | rule | needs_context | executed | insufficient_evidence | ev-675baa5e1eb44545853a2a89c5588cc2 | 无 |
| `R12` 同类控件呈现一致的视觉规则 | rule | applicable | executed | insufficient_evidence | ev-675baa5e1eb44545853a2a89c5588cc2 | 无 |
| `R01` 当前导航位置可见 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R02` 多步骤任务显示当前步骤 | rule | needs_context | not_executed | — | 无 | 无 |
| `R03` 等待状态说明系统正在做什么 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R04` 完成状态说清结果 | rule | needs_context | not_executed | — | 无 | 无 |
| `R05` 关键文案避免未解释的内部术语 | rule | needs_context | not_executed | — | 无 | 无 |
| `R06` 操作名称说明预期结果 | rule | applicable | not_executed | — | 无 | 无 |
| `R07` 输入项名称说明所需信息 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R08` 弹窗具有可见退出方式 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R09` 多步骤页面具有可见返回方式 | rule | needs_context | not_executed | — | 无 | 无 |
| `R10` 确认页允许取消高风险操作 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R11` 同一动作使用一致名称 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R13` 必填项在填写前可识别 | rule | needs_context | not_executed | — | 无 | 无 |
| `R14` 受格式限制的字段提供输入提示 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R15` 高后果操作确认页说明对象和动作 | rule | not_applicable | not_executed | — | 无 | 无 |
| `R16` 重要图标操作具有可见含义线索 | rule | needs_context | not_executed | — | 无 | 无 |
| `R18` 相关输入和选项形成可识别的组 | rule | applicable | not_executed | — | 无 | 无 |
| `R19` 主要任务操作易于定位 | rule | applicable | not_executed | — | 无 | 无 |
| `R20` 无关信息不压过主要任务 | rule | applicable | not_executed | — | 无 | 无 |
| `R21` 错误状态指明问题位置 | rule | needs_context | not_executed | — | 无 | 无 |
| `R22` 错误提示给出修正办法 | rule | needs_context | not_executed | — | 无 | 无 |
| `R23` 错误提示使用用户可理解的语言 | rule | needs_context | not_executed | — | 无 | 无 |
| `R24` 复杂任务提供就近帮助入口 | rule | needs_context | not_executed | — | 无 | 无 |
| `E01` 关键任务路径衔接 | method | not_applicable | not_executed | — | 无 | 无 |
| `E02` 跨页面对象与信息一致性 | method | not_applicable | not_executed | — | 无 | 无 |
| `E04` 返回取消后的任务恢复 | method | not_applicable | not_executed | — | 无 | 无 |
| `E05` 异常分支与恢复路径 | method | not_applicable | not_executed | — | 无 | 无 |
| `E06` 前置条件与操作开放状态 | method | needs_context | not_executed | — | 无 | 无 |
| `E07` 目标与明确要求落实 | goal | needs_context | not_executed | — | 无 | 无 |
| `E08` 跨职能要求冲突识别与处理 | conflict | not_applicable | not_executed | — | 无 | 无 |

### E03 · 操作与反馈状态对应

- 检查 ID / 类型：`check-c7e35f858aff083c` / method
- 计划：applicable；两行都有明确的开关选项。核对课程提醒的蓝底「开启」与白底「关闭」，再检查作业到期的 ON／OFF 有无区分当前项的标记。
- 对象：['课程提醒行的开启／关闭', '作业到期行的 ON／OFF']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：E03 静态检查两行提醒的当前状态表达。「课程提醒」用蓝底突出「开启」；「作业到期」的 ON 和 OFF 共用浅色底，没有可辨认的标记说明当前状态。；没有通过证据核验的完整发现，保留为证据不足。
- 判据/方法定义：操作与反馈状态对应；对象：动作触发、等待/选择/完成/失败等反馈及其对应操作对象。；适用：存在可执行动作或明确的状态设计，且动作应产生的变化有任务依据。；触发：动作实际触发有证据，但反馈缺失/错误关联/与明确预期冲突，范围和观察条件足以支持本次结论。；弃权：动作未触发、工具失败、只有前状态、观察条件不足或异步完成条件未知时证据不足；无状态变化检查对象时不适用。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-a272e2026ec8dc89` / rule
- 计划：applicable；「开启」为蓝底、「关闭」为白底，可比较同一行的选中与未选样式，核对截图表达的当前选择。
- 对象：['课程提醒行的「开启／关闭」']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：R17 适用于「课程提醒」行的二选一设置。「开启」为蓝底白字，「关闭」为白底深色字，两者的区别足以辨认画面中的当前选择为「开启」。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-ec7d904b7b853abf` / rule
- 计划：needs_context；ON 和 OFF 并列在同一浅色底上，可定位两个选项，但无法确认此状态下是否已有一项被选中。
- 对象：['作业到期行的 ON／OFF']
- 必需证据类型：['design']
- 缺项：['说明该画面中是否已有选中项及其取值的状态标注']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R17 需先确认已有选中项。「作业到期」行可见 ON 和 OFF，但材料没有标注是否已选，也没有给出当前值。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R12 · 同类控件呈现一致的视觉规则

- 检查 ID / 类型：`check-aa692394b0c7730a` / rule
- 计划：applicable；两行均在同一卡片内表达二选一提醒设置。可对照「开启」的蓝底与 ON／OFF 的选中线索，无需假定两项提醒当前都已开启。
- 对象：['课程提醒的开启／关闭', '作业到期的 ON／OFF']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R12 可对照同一卡片内的两组提醒控件。「课程提醒」用两个独立按钮，「作业到期」将 ON／OFF 放在同一浅色区域。后者的选中状态未知，无法确认同状态控件采用了不同的选中规则。
- 判据/方法定义：同类控件呈现一致的视觉规则；适用：存在至少两个功能、层级、状态和设计语境可比的控件，可跨同版本页面。；检查：先核对可比条件，再比较形状、颜色、文字、状态表达，记录差异造成的类别/状态歧义。；触发：同类同状态控件存在无解释的显著规则差异，具体导致操作类别或状态含义混淆。；弃权：只有一个可比对象时不适用；控件层级/状态/规范依据未知时证据不足；有明确状态或主题理由的差异不报问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R01 · 当前导航位置可见

- 检查 ID / 类型：`check-63ac85d885b14585` / rule
- 计划：not_applicable；完整画面以「个人设置」标明页面；顶栏没有包含当前页的并列导航项，两行提醒选项属于页内设置。
- 对象：['个人设置页标题与顶栏']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：当前导航位置可见；适用：已确认当前页面且存在页面级导航。页面内筛选/单选交由R17。；检查：记录当前页面依据，比较页面级导航项及当前项标识；运行模式分别记录跳转前后导航。；触发：页面级导航及当前页面已知，可完整查看相关导航，但当前项无可辨选中标识或标识与当前页面冲突。；弃权：已知是无页面级导航的入口页时不适用；当前页面身份不明、导航被裁切或目标未加载完整时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R02 · 多步骤任务显示当前步骤

- 检查 ID / 类型：`check-d6ed41463b8d835b` / rule
- 计划：needs_context；提醒选项和「保存设置」同页可见；先选后存的动作顺序不能证明该页属于分步流程。
- 对象：['通知偏好卡片', '保存设置']
- 必需证据类型：['design', 'statement']
- 缺项：['说明该页是独立设置页，还是某一流程中的一步']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：多步骤任务显示当前步骤；适用：已由流程说明或实际路径确认是多步骤任务，当前页属于其中一步。；检查：记录步骤关系、当前步骤与可见进度线索，结合标题和上下文判断当前环节是否可辨。；触发：多步骤与当前位置已确认，但相关区域完整可查时仍无法从标题、进度或上下文辨认当前环节。；弃权：已确认独立单页时不适用；仅见一页且无法确认步骤关系，或进度区域未取得时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R03 · 等待状态说明系统正在做什么

- 检查 ID / 类型：`check-5cc375d9fe46f469` / rule
- 计划：not_applicable；附图呈现已展开的设置项和保存入口，是普通设置画面；本状态没有待解释的处理进度。
- 对象：['通知偏好卡片当前画面']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：等待状态说明系统正在做什么；适用：当前取得的画面已经呈现加载、上传或处理中等等待状态；可来自截图、原型或运行记录。；检查：记录等待对象、可见文案与进度线索；运行时记录触发动作、观察时长及前后状态。；触发：已确认处于等待，完整相关区域仅有无法解释的转圈/空白，结合上下文仍不能判断正在处理的任务。；弃权：已确认普通非等待状态时不适用；无法确认等待状态、区域不全或动作结果未取得时证据不足；不能由点击前截图推断无反馈。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R04 · 完成状态说清结果

- 检查 ID / 类型：`check-d809183ae225ebc4` / rule
- 计划：needs_context；「保存设置」标示动作入口，不能当作完成提示；现有材料没有提供保存后的结果表达。
- 对象：['保存设置']
- 必需证据类型：['design']
- 缺项：['标明对应保存动作的完成态设计画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：完成状态说清结果；适用：已取得某次操作完成/成功状态，完成对象与上下文可确认。；检查：检查成功表达是否能说明已完成的动作、对象及确有必要的后续操作。；触发：完成状态已确认，但只有泛化成功信息，结合上下文仍无法判断完成了什么，或遗漏任务必需的下一步线索。；弃权：明确非完成状态时不适用；只有完成前画面、对象不明或结果区域缺失时证据不足；没有后续任务不要求强加下一步。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R05 · 关键文案避免未解释的内部术语

- 检查 ID / 类型：`check-8c4214d27328a886` / rule
- 计划：needs_context；辨认两行状态需要理解选项，但中英文差异本身不能证明 ON／OFF 是内部术语，也不能证明用户不熟悉。
- 对象：['课程提醒：开启／关闭', '作业到期：ON／OFF']
- 必需证据类型：['design', 'statement']
- 缺项：['目标用户及其专业背景', '这些标签是否具有产品特定含义', '目标用户对任务所需标签的熟悉度依据']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：关键文案避免未解释的内部术语；适用：已确认非领域专家用户，存在非错误状态的关键任务文案；错误文案转R23。；检查：逐词记录任务必要性、内部术语含义来源、目标用户熟悉度依据与可见解释；词表只能证明含义，不能证明熟悉度。；触发：有依据确认非专家完成主任务必须理解某内部术语，该用户群不熟悉该词，界面又未解释。；弃权：明确没有相关对象或目标用户为领域专家时不适用；用户、含义、必要性或熟悉度影响结论却未知时证据不足。已解释/有熟悉依据时不能报问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R06 · 操作名称说明预期结果

- 检查 ID / 类型：`check-e08fd137085283b8` / rule
- 计划：applicable；调整对象与入口定位任务明确，可结合两行名称、对应选项和卡片右下角的保存按钮检查预期动作是否清楚。
- 对象：['课程提醒：开启／关闭', '作业到期：ON／OFF', '保存设置']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：操作名称说明预期结果；适用：当前状态有主要按钮/入口，用户任务和动作目的已知。；检查：核对按钮文字、邻近内容与预期动作；运行结果可用于确认动作，但不能替代文案清晰度检查。；触发：主要按钮使用泛词或含义不符，结合邻近说明仍不能理解预期结果，或与明确动作目的冲突。；弃权：无主操作对象时不适用；任务/动作目的不明或上下文缺失时证据不足；周围内容已清楚说明时，泛词本身不构成问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R07 · 输入项名称说明所需信息

- 检查 ID / 类型：`check-5aa0cdad59cfc8f8` / rule
- 计划：not_applicable；两项提醒均以行名和成对的固定选项呈现；本任务对应的是选择控件，没有需要填写内容的字段。
- 对象：['课程提醒选项', '作业到期选项']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：输入项名称说明所需信息；适用：存在需要填写的重要表单字段，字段任务可确认。；检查：核对字段名称与紧邻说明；运行时分别查看输入前后，确认必要名称线索是否仍可获取。；触发：字段无名称或名称模糊，结合邻近内容仍无法知道应填什么；运行证据显示输入后唯一必要说明消失并产生含义不明。；弃权：无输入对象时不适用；字段说明区域裁切、业务含义未知或未取得输入后画面时，对相应判断记证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R08 · 弹窗具有可见退出方式

- 检查 ID / 类型：`check-8bb4821aa0e16e5e` / rule
- 计划：not_applicable；待定位的控件位于「个人设置」页正文的「通知偏好」卡片内；当前任务对象是页内卡片，没有弹窗退出入口需要检查。
- 对象：['通知偏好卡片及其完整边界']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：弹窗具有可见退出方式；适用：存在普通信息/输入弹窗，完整边界可取得；高风险确认归R10。；检查：检查可见关闭/取消/返回方式；只有实际执行后才描述是否成功退出，行为验证转E01/E04。；触发：普通可中断弹窗占据焦点，完整边界和相关说明可查，但没有任何可见退出方式。；弃权：高风险确认或已确认不可中断流程不适用；边缘被裁、弹窗性质不明时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R09 · 多步骤页面具有可见返回方式

- 检查 ID / 类型：`check-fa7c19163c03fdcd` / rule
- 计划：needs_context；截图显示个人设置页，但无法确定它是否属于多步骤任务的非首步，也未涵盖浏览器导航。
- 对象：['个人设置页']
- 必需证据类型：['design']
- 缺项：['设置页在任务流程中的位置', '若为非首步，需明确可用的返回或退出入口']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：多步骤页面具有可见返回方式；适用：确认当前是多步骤任务非首步，且不是高风险确认页。；检查：检查可见返回/退出入口，说明系统/浏览器返回是否在本次观察范围内；执行结果交E01/E04。；触发：当前非首步已确认且相关区域完整，页面与可观察系统入口均无可见返回或退出方式。；弃权：已确认首步/独立页或高风险确认时不适用；步骤未知、系统导航未涵盖且可能承担功能、页面不全时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R10 · 确认页允许取消高风险操作

- 检查 ID / 类型：`check-cb60b734122a0669` / rule
- 计划：not_applicable；当前画面用于选择偏好并提供「保存设置」入口，所示状态是设置编辑页，没有正在确认的高风险操作。
- 对象：['通知偏好卡片', '保存设置']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：确认页允许取消高风险操作；适用：已确认删除/清空/永久变更等高风险操作的确认界面。；检查：检查清楚可见的取消/返回入口；默认仅观察，不为验证本条而执行真实危险操作。；触发：高风险性质已确认，确认区域完整且仅能执行，没有可见取消/返回入口。；弃权：明确非高风险确认时不适用；风险性质未知或取消区未取得时证据不足；无授权不执行真实副作用。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R11 · 同一动作使用一致名称

- 检查 ID / 类型：`check-8747e47321c9f676` / rule
- 计划：not_applicable；「开启／关闭」和 ON／OFF 分别调整课程提醒和作业到期提醒，各自作用于不同设置。当前画面只有一个「保存设置」入口。
- 对象：['课程提醒的开启／关闭', '作业到期的 ON／OFF', '保存设置']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：同一动作使用一致名称；适用：在同一材料或已确认的同版本多页面中，至少两个入口明确指向同一动作。；检查：记录动作同一性的依据，比较入口名称与解释；不同对象的名称差异不据此判动作不一致。；触发：已证实同一动作、同一语境使用互相矛盾或无解释的不同名称。；弃权：仅一个相关入口时不适用；动作是否相同、版本或语境未知时证据不足；功能/对象/阶段确有差异且名称合理时未见问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R13 · 必填项在填写前可识别

- 检查 ID / 类型：`check-702b3a15815cd795` / rule
- 计划：needs_context；页面提供预设选项和保存入口，材料未说明用户是否必须作出选择才能保存。
- 对象：['课程提醒', '作业到期', '保存设置']
- 必需证据类型：['requirement', 'design']
- 缺项：['是否存在必选项及其范围']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：必填项在填写前可识别；适用：存在已知必填要求的表单字段；要求有来源。；检查：在填写前查看字段标记和整体说明，与已确认必填清单对照。；触发：已知必填字段既无字段标记也无清楚整体说明，提交前无法辨认必填要求。；弃权：明确无必填字段时不适用；哪些必填未知时证据不足；全部必填且有整体说明时未见问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R14 · 受格式限制的字段提供输入提示

- 检查 ID / 类型：`check-99117f92a173a267` / rule
- 计划：not_applicable；两行都直接列出开关选项，调整这两项提醒无需自行录入具有格式或长度要求的值。
- 对象：['课程提醒的开启／关闭', '作业到期的 ON／OFF']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：受格式限制的字段提供输入提示；适用：字段有已确认的格式、长度或有效值限制。；检查：对照限制来源，查看填写前可获得的字段名、提示与有效示例。；触发：限制已知，但填写前无可理解线索，用户必须猜测要求；或提示与已确认限制冲突。；弃权：确认无特定格式限制时不适用；限制未知或提示区域不可查时证据不足；有效示例已清楚表达时未见问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R15 · 高后果操作确认页说明对象和动作

- 检查 ID / 类型：`check-3969614a4db738f3` / rule
- 计划：not_applicable；当前画面是偏好编辑页，未处于高后果操作确认阶段。「消息工具」中的叉形图标也没有对象损失或不可逆后果的说明。
- 对象：['通知偏好卡片', '保存设置', '消息工具中的叉形图标']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：高后果操作确认页说明对象和动作；适用：已确认是后果较大的操作确认界面，动作、对象及必要后果要求可确定。；检查：检查确认文字与邻近内容能否支持核对动作、对象和必要后果。；触发：完整上下文仍只有泛化确认，无法核对具体对象/动作，或遗漏已明确会影响决定的后果。；弃权：确认不是高后果确认时不适用；后果、对象未知或说明裁切时证据不足；无需为观察而实际执行危险动作。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R16 · 重要图标操作具有可见含义线索

- 检查 ID / 类型：`check-107256bdab20bd1c` / rule
- 计划：needs_context；提醒选项和保存入口均有文字。「消息工具」另有三个图标，其用途、对该任务的重要性及目标用户的熟悉程度未知。
- 对象：['消息工具行的折线、矩形和叉形图标']
- 必需证据类型：['design', 'statement']
- 缺项：['三个图标的用途及任务必要性', '若任务需要图标，需目标用户的熟悉度依据', '若有悬停或聚焦说明，需对应设计画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：重要图标操作具有可见含义线索；适用：有影响已知主任务的图标操作，目标用户和任务语境可确定。；检查：检查文字标签、邻近解释及有依据的通用含义；必要时查看可取得的悬停/聚焦说明，并注明设备条件。；触发：任务必需的自定义图标没有可见说明，且有依据表明其含义在本语境中不可辨认。；弃权：无重要图标对象时不适用；重要性或用户熟悉度影响结论但未知、辅助说明未取得时证据不足；不因无常驻文字自动报问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R18 · 相关输入和选项形成可识别的组

- 检查 ID / 类型：`check-2deac3cd01d9fc11` / rule
- 计划：applicable；TASK02 明确了两组选项的归属，可核对行标题、对齐和分隔线是否把每组选项与对应提醒关联起来。
- 对象：['课程提醒行及「开启／关闭」', '作业到期行及 ON／OFF']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：相关输入和选项形成可识别的组；适用：已确认存在多个相关输入字段或成组选项，业务分组关系已知；纯展示卡不纳入。；检查：逐项记录输入/可选/纯展示角色及其证据，核对关系来源，再检查组标题、间距与边界。；触发：输入/选择角色和分组关系已确认，相关与无关项混排，造成具体归属歧义。；弃权：确认仅纯展示、单个字段或单个选项时不适用；交互角色或分组关系未知、相关区域不全时证据不足。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R19 · 主要任务操作易于定位

- 检查 ID / 类型：`check-8152f99adb79c5bd` / rule
- 计划：applicable；任务指定了调整选项和保存入口，可核对两行右侧选项与卡片右下角按钮的位置、文字及遮挡情况。
- 对象：['课程提醒选项', '作业到期选项', '保存设置按钮']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：主要任务操作易于定位；适用：已确认主任务及对应主操作，取得其所在区域和必要上下文。；检查：记录主操作、竞争元素、位置/遮挡/层级关系；计算显著性只作线索，真人识别另行验证。；触发：有具体可见证据表明主操作被遮挡、与任务脱离或层级混淆，难以从当前界面定位。；弃权：确认无本条操作对象时不适用；主任务未知、区域未取得或仅有代理分值时证据不足；不能因按钮不最大而直接报问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R20 · 无关信息不压过主要任务

- 检查 ID / 类型：`check-bd200b73fbfb059a` / rule
- 计划：applicable；卡片同时展示主题、字号和消息工具，可对照本次任务检查这些行是否挤占或遮挡提醒选项和保存入口。
- 对象：['通知偏好卡片', '界面主题、文字大小和消息工具行', '提醒选项及保存设置按钮']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：无关信息不压过主要任务；适用：主任务及内容相关性有依据，主要内容与竞争区域可取得。；检查：比较任务内容和装饰/推广/重复信息，说明具体干扰机制；高饱和或元素多不单独构成违反。；触发：有依据确认无关内容明显压制、遮挡或挤占关键任务内容，并指出具体区域与影响。；弃权：无相关比较对象时不适用；任务相关性未知或区域不全时证据不足；目标需要的角色展示/奖励说明不能仅凭面积大判无关。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### R21 · 错误状态指明问题位置

- 检查 ID / 类型：`check-203b50ef70a6c669` / rule
- 计划：needs_context；仅有设置页静态画面，材料未确认调整或保存的错误状态，无法核对提示指向哪一行或哪项操作。
- 对象：['提醒调整或保存的错误提示（待确认）']
- 必需证据类型：['design']
- 缺项：['如有错误状态，需含完整提示及对应设置项或操作的设计画面']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：错误状态指明问题位置；适用：已取得明确错误状态及其相关任务/操作范围。；检查：查看错误提示与字段/操作关联，记录错误原文和位置；多错误逐项检查。；触发：错误状态已确认，相关区域完整却只有笼统提示，无法辨别应处理的字段或操作。；弃权：确认不是错误状态时不适用；错误范围在未取得区域或状态性质未知时证据不足；只缺字段高亮但提示已清楚定位时不报问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R22 · 错误提示给出修正办法

- 检查 ID / 类型：`check-58529af2d6d128de` / rule
- 计划：needs_context；材料未确认具体错误及用户能采取的修正动作，不能据页首「帮助中心」判断是否给出了处理步骤。
- 对象：['提醒调整或保存的修正说明（待确认）']
- 必需证据类型：['design', 'statement']
- 缺项：['错误状态及用户可执行的处理方式', '该状态的提示或直接关联的修正说明']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：错误提示给出修正办法；适用：已确认错误状态，且存在用户可以执行的修正或后续处理。；检查：检查当前提示和明确关联的帮助/恢复入口，核对建议步骤是否可执行；执行结果由E05记录。；触发：错误及可行修正途径已知，但当前信息没有可执行线索，或所给线索与已确认处理方法冲突。；弃权：确认无用户可执行处理时本条不适用；可修正性未知或帮助入口内容未取得时证据不足；已有明确关联修正说明时未见问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R23 · 错误提示使用用户可理解的语言

- 检查 ID / 类型：`check-0cc9ae94477d70f4` / rule
- 计划：needs_context；材料未提供已确认的错误文案或目标用户背景。作业到期行的 ON／OFF 是选项文字，不能作为错误提示检查。
- 对象：['提醒调整或保存的错误文案（待确认）']
- 必需证据类型：['design', 'statement']
- 缺项：['面向用户的完整错误提示原文', '目标用户及其对提示用语的熟悉程度']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：错误提示使用用户可理解的语言；适用：存在面向已知目标用户的错误提示。；检查：记录错误原文，结合已知用户背景检查是否有可理解说明；技术码可作为辅助。；触发：面向非技术用户的错误信息只有内部码/异常栈/开发术语，且无可理解解释。；弃权：无错误提示对象时不适用；用户背景影响理解却未知、文字不清时证据不足；技术码同时附清楚说明或目标开发者确可理解时未见问题。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### R24 · 复杂任务提供就近帮助入口

- 检查 ID / 类型：`check-c6c5a432bfe9774d` / rule
- 计划：needs_context；材料未说明哪一步需要目标用户借助解释才能完成，也未提供「帮助中心」中与提醒设置关联的内容。
- 对象：['提醒选项', '保存设置', '帮助中心']
- 必需证据类型：['statement', 'design']
- 缺项：['目标用户在哪个步骤需要解释及原因', '若确需解释，该步骤附近的说明或关联帮助内容']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：复杂任务提供就近帮助入口；适用：已确认目标用户在某关键复杂/领域字段或步骤上需要解释才能完成任务。；检查：记录复杂性与用户需要的依据，查看邻近说明/示例/帮助入口及实际取得内容。；触发：解释需要已确认，当前可查范围既无可理解说明，也无清楚关联且可取得的帮助，必须脱离任务自行猜测含义。；弃权：确认无需要解释的对象时不适用；解释需要、用户知识或帮助内容未知时证据不足；专家也可能需特定业务解释，不自动排除。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### E01 · 关键任务路径衔接

- 检查 ID / 类型：`check-2cb62fe70bfe4a0a` / method
- 计划：not_applicable；任务终点是指出本页两行选项和右下角「保存设置」，没有需要抵达的下一页面或状态。
- 对象：['课程提醒行的开启／关闭', '作业到期行的 ON／OFF', '卡片右下角的保存设置']
- 必需证据类型：['statement', 'design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：关键任务路径衔接；对象：任务起点、动作入口、目标页面/状态和已声明终点。；适用：存在需要跨页或跨状态的任务，关系可由已确认要求、原型连接或实际路径建立。；触发：目标关系明确且入口条件满足，本次操作到达错误对象、陷入可复现死路或无法抵达明确必需的下一步，且已排除访问/工具阻断。；弃权：关系或目标未知、权限失败、工具未执行、原型未实现分支时证据不足；明确独立静态任务无连接对象时不适用。
- 证据链：
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### E02 · 跨页面对象与信息一致性

- 检查 ID / 类型：`check-f17033f2cb68b0f1` / method
- 计划：not_applicable；两行分别表示两种提醒，本轮各有一处状态展示，没有同一提醒在另一位置的值可供核对。
- 对象：['课程提醒', '作业到期']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：跨页面对象与信息一致性；对象：同一角色、订单、任务或其他对象在不同页面/状态中的名称、属性、数量和指代。；适用：至少两个材料位置已确认属于同一对象、可比版本与可比条件。；触发：同一对象与条件已确认，名称/属性/数量发生无依据矛盾或错误传递，且不是已确认的合法变化。；弃权：对象同一性、版本或允许变化条件未知时证据不足；只有一个对象位置时不适用。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### E04 · 返回取消后的任务恢复

- 检查 ID / 类型：`check-804c83b987cdb423` / method
- 计划：not_applicable；本轮任务止于定位保存入口，未包含返回、取消或重进后恢复选择的分支。
- 对象：['保存设置入口']
- 必需证据类型：['statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：返回取消后的任务恢复；对象：返回、取消、退出再进入时的数据、选择、进度及定位。；适用：任务包含返回/取消/恢复分支，且预期的保留或重置要求可确定。；触发：返回/取消后的状态与已确认要求矛盾，造成已证实的任务丢失、错误续接或不应保留的数据残留。；弃权：保留规则不明、未执行分支或新旧状态不可比时证据不足；无返回/取消分支时不适用；不默认所有进度都必须保留。
- 证据链：
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### E05 · 异常分支与恢复路径

- 检查 ID / 类型：`check-9a86fa3f214f52f2` / method
- 计划：not_applicable；委托限定在当前静态画面识别选项和操作入口，任务不包含触发保存失败或从异常中恢复。
- 对象：['提醒选项和保存入口的定位任务']
- 必需证据类型：['statement']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：异常分支与恢复路径；对象：已取得的网络/输入/业务异常状态及可执行恢复步骤。；适用：已观察异常或提供明确异常设计，并存在应向用户交付的处理/恢复方式。；触发：条件明确且实际可测，恢复入口失效、进入同一无解循环或恢复结果违反明确要求；静态设计缺已确认必需分支只报设计层遗漏。；弃权：不能安全触发异常、无恢复依据或实际结果未取得时证据不足；任务确认无本条异常对象时不适用，不以未遇错误证明无错误。
- 证据链：
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)

### E06 · 前置条件与操作开放状态

- 检查 ID / 类型：`check-f68be1c1550d3f61` / method
- 计划：needs_context；截图可定位「保存设置」，材料未说明保存有无前置条件，也未说明当前是否有待保存的变更。
- 对象：['保存设置按钮']
- 必需证据类型：['requirement', 'design']
- 缺项：['保存开放条件的项目说明', '若有条件，标明条件满足情况的对应设计状态']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：前置条件与操作开放状态；对象：任务前置条件、按钮可用/禁用状态及操作结果。；适用：项目明确规定某操作的前置条件，且有可比状态或测试方式。；触发：已确认条件与当前操作开放/拦截行为矛盾；仅凭按钮外观可疑只形成待验证线索，不声称业务已绕过。；弃权：前置条件、账号状态或实际执行未知时证据不足；明确无该类条件时不适用；需真实发奖等未授权动作保持阻断。
- 证据链：
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-7a70e79c775b8e9b` / goal
- 计划：needs_context；委托说明了要检查什么，未提供产品对提醒状态表达的正式目标或验收条件。
- 对象：['课程提醒和作业到期的当前选择']
- 必需证据类型：['requirement', 'design']
- 缺项：['适用于该版两类提醒状态表达的已确认要求原文']
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

### E08 · 跨职能要求冲突识别与处理

- 检查 ID / 类型：`check-43369b4b15ced1f4` / conflict
- 计划：not_applicable；给定来源分别是评审委托和设置页截图，没有两项针对调整或保存方式的职能要求可作冲突比较。
- 对象：['评审委托', '提醒调整选项与保存设置']
- 必需证据类型：['statement', 'design']
- 缺项：[]
- 执行 / 判断：not_executed / 未判断
- 判断理由：本轮检查资源限制，未执行。
- 判据/方法定义：跨职能要求冲突识别与处理；对象：策划/产品、设计、开发材料或用户决定对同一对象的要求与限制。；适用：两项以上要求/约束指向同一对象，可能无法同时满足或存在证据描述矛盾。；触发：原文可定位且同范围，两项要求无法同时成立。输出conflict记录，不未经裁决转换为产品违规。已裁决正式要求被实现违反时转E07。；弃权：同一对象或版本关系未知则待澄清；只有单份要求、或解释后可同时满足则不构成冲突。
- 证据链：
- `ev-940de4c4949d4daf908fff976890d19b` / statement / 来源 `src-a7375bb4159844cf9033852eb50f1de1` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-07fdb93742b646bbaffbfada20055b84`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-07fdb93742b646bbaffbfada20055b84.txt)
  - 原始文件：[`artifact-3474ff7f567047e694e5cf0cf957cb6d`](artifacts/ev-940de4c4949d4daf908fff976890d19b-artifact-3474ff7f567047e694e5cf0cf957cb6d.txt)
- `ev-675baa5e1eb44545853a2a89c5588cc2` / design / 来源 `src-fe841475860b4216bf7f688815b71d77` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-b84496f15f4d4e39b3b3a40dd7256a1d`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-b84496f15f4d4e39b3b3a40dd7256a1d.bin)
  - 视觉分析：[`artifact-aa7b28d5978e46e2a3ca6741aa03af37`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-aa7b28d5978e46e2a3ca6741aa03af37.json)
  - 叠加图 overlay-elements.png：[`artifact-1bfe837430b94270ae601aab4afe684a`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-1bfe837430b94270ae601aab4afe684a.png)
  - 叠加图 overlay-focus.png：[`artifact-59aa1e4186ed48ba915b21091808dece`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-59aa1e4186ed48ba915b21091808dece.png)
  - 叠加图 overlay-flow.png：[`artifact-3b54d8d0de76452bae344f31f194d880`](artifacts/ev-675baa5e1eb44545853a2a89c5588cc2-artifact-3b54d8d0de76452bae344f31f194d880.png)

## 八、发现与修改建议

当前没有通过证据核验的候选发现。

## 九、问题、冲突与业务决定

- `question-a210086ed5f442c1bc8ec07086b6d72a` [未回答] 这张设计图中，「作业到期」预期呈现哪种状态：ON、OFF，还是尚未选择？；影响检查：check-ec7d904b7b853abf, check-aa692394b0c7730a；答复：无

## 十、模型调用、输入与原始输出

| 调用 | 阶段/操作 | 模型 | 输入索引 | 输出摘要 | 原始响应 |
| --- | --- | --- | --- | --- | --- |
| `call-da546992d52140819ef26af13268c3fb` | T03 / understand | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 目标 0；要求 0；意见 0；冲突 0 | [`artifact-a817055946aa47e39d87c9fbad019430`](raw/call-da546992d52140819ef26af13268c3fb-artifact-a817055946aa47e39d87c9fbad019430.txt) |
| `call-4ac64329174e442faeaa1f903df01212` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08 | [`artifact-017a846e2f644fa38c44317115ff4146`](raw/call-4ac64329174e442faeaa1f903df01212-artifact-017a846e2f644fa38c44317115ff4146.txt) |
| `call-ee2592f7cba149afaa779e3b97ca7be6` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': ['R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16 | [`artifact-5b65ce70300944188b1015b10002d65f`](raw/call-ee2592f7cba149afaa779e3b97ca7be6-artifact-5b65ce70300944188b1015b10002d65f.txt) |
| `call-d0279e5492674398b0708326d7364695` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': ['R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 9 项：R17, R17, R18, R19, R20, R21, R22, R23, R24 | [`artifact-98afc974a34f4b2a8ead013f592f9657`](raw/call-d0279e5492674398b0708326d7364695-artifact-98afc974a34f4b2a8ead013f592f9657.txt) |
| `call-bd054e21a9554d949ccee0b2da3097f7` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': ['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 8 项：E01, E02, E03, E04, E05, E06, E07, E08 | [`artifact-465ab8d379444ab9b049a79714d10ea3`](raw/call-bd054e21a9554d949ccee0b2da3097f7-artifact-465ab8d379444ab9b049a79714d10ea3.txt) |
| `call-ff0b6e338e624c9882f328325cc22a73` | T05 / plan | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | ready_for_review=True；动作 无 | [`artifact-b6264ea9435c402aad6aaa50217b012b`](raw/call-ff0b6e338e624c9882f328325cc22a73-artifact-b6264ea9435c402aad6aaa50217b012b.txt) |
| `call-a824cf45df6b49508ae4317a41ddf71a` | T06 / judge | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': ['E03', 'R17', 'R17', 'R12'], 'check_ids': ['check-c7e35f858aff083c', 'check-a272e2026ec8dc89', 'check-ec7d904b7b853abf', 'check-aa692394b0c7730a'], 'finding_ids': [], 'previous_finding_… | 判断 4；发现 1；状态 candidate_issue, insufficient_evidence, no_visible_issue | [`artifact-331ed27d0d824579a763696f01eee602`](raw/call-a824cf45df6b49508ae4317a41ddf71a-artifact-331ed27d0d824579a763696f01eee602.txt) |
| `call-6b331ee71efb45ea9f73740a587d0446` | T05 / plan | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': 'evidence_gap', 'source_ids': ['src-fe841475860b4216bf7f688815b71d77', 'src-a7375bb4159844cf9033852eb50f1de1'], 'evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2', 'ev-940de4c4949d4daf908fff976890d19b'], 'image_evidence_ids': ['ev-675baa5e1eb44545853a2a89c5588cc2'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 3, 'evidence_gap_refs': ['coverage-f65a5f393ba15ec3', 'coverage-f65a5f393ba15ec3/作业到… | ready_for_review=True；动作 无 | [`artifact-d2010300747c4edc801c89890a9a50e8`](raw/call-6b331ee71efb45ea9f73740a587d0446-artifact-d2010300747c4edc801c89890a9a50e8.txt) |

### call-da546992d52140819ef26af13268c3fb · T03 understand

- 状态：validated；尝试：1；耗时：17766ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 26057, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 589, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：目标 0；要求 0；意见 0；冲突 0
- 完整原始响应：[`artifact-a817055946aa47e39d87c9fbad019430`](raw/call-da546992d52140819ef26af13268c3fb-artifact-a817055946aa47e39d87c9fbad019430.txt)

### call-4ac64329174e442faeaa1f903df01212 · T04 plan_checks

- 状态：validated；尝试：1；耗时：34469ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28133, 'cached_input_tokens': 0, 'cache_write_input_tokens': 0, 'output_tokens': 1919, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": ["R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08
- 完整原始响应：[`artifact-017a846e2f644fa38c44317115ff4146`](raw/call-4ac64329174e442faeaa1f903df01212-artifact-017a846e2f644fa38c44317115ff4146.txt)

### call-ee2592f7cba149afaa779e3b97ca7be6 · T04 plan_checks

- 状态：validated；尝试：1；耗时：32187ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28046, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1904, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": ["R09", "R10", "R11", "R12", "R13", "R14", "R15", "R16"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16
- 完整原始响应：[`artifact-5b65ce70300944188b1015b10002d65f`](raw/call-ee2592f7cba149afaa779e3b97ca7be6-artifact-5b65ce70300944188b1015b10002d65f.txt)

### call-d0279e5492674398b0708326d7364695 · T04 plan_checks

- 状态：validated；尝试：1；耗时：36953ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28180, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 2251, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": ["R17", "R18", "R19", "R20", "R21", "R22", "R23", "R24"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 9 项：R17, R17, R18, R19, R20, R21, R22, R23, R24
- 完整原始响应：[`artifact-98afc974a34f4b2a8ead013f592f9657`](raw/call-d0279e5492674398b0708326d7364695-artifact-98afc974a34f4b2a8ead013f592f9657.txt)

### call-bd054e21a9554d949ccee0b2da3097f7 · T04 plan_checks

- 状态：validated；尝试：1；耗时：32187ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28120, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1992, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": ["E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：E01, E02, E03, E04, E05, E06, E07, E08
- 完整原始响应：[`artifact-465ab8d379444ab9b049a79714d10ea3`](raw/call-bd054e21a9554d949ccee0b2da3097f7-artifact-465ab8d379444ab9b049a79714d10ea3.txt)

### call-ff0b6e338e624c9882f328325cc22a73 · T05 plan

- 状态：validated；尝试：1；耗时：8828ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 30934, 'cached_input_tokens': 0, 'cache_write_input_tokens': 0, 'output_tokens': 202, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：ready_for_review=True；动作 无
- 完整原始响应：[`artifact-b6264ea9435c402aad6aaa50217b012b`](raw/call-ff0b6e338e624c9882f328325cc22a73-artifact-b6264ea9435c402aad6aaa50217b012b.txt)

### call-a824cf45df6b49508ae4317a41ddf71a · T06 judge

- 状态：validated；尝试：1；耗时：22344ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 27771, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1071, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": ["E03", "R17", "R17", "R12"], "check_ids": ["check-c7e35f858aff083c", "check-a272e2026ec8dc89", "check-ec7d904b7b853abf", "check-aa692394b0c7730a"], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：判断 4；发现 1；状态 candidate_issue, insufficient_evidence, no_visible_issue
- 完整原始响应：[`artifact-331ed27d0d824579a763696f01eee602`](raw/call-a824cf45df6b49508ae4317a41ddf71a-artifact-331ed27d0d824579a763696f01eee602.txt)

### call-6b331ee71efb45ea9f73740a587d0446 · T05 plan

- 状态：validated；尝试：1；耗时：6578ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 25929, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 132, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "evidence_gap", "source_ids": ["src-fe841475860b4216bf7f688815b71d77", "src-a7375bb4159844cf9033852eb50f1de1"], "evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2", "ev-940de4c4949d4daf908fff976890d19b"], "image_evidence_ids": ["ev-675baa5e1eb44545853a2a89c5588cc2"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 3, "evidence_gap_refs": ["coverage-f65a5f393ba15ec3", "coverage-f65a5f393ba15ec3/作业到期", "coverage-f65a5f393ba15ec3"]}
- 输出来源：ready_for_review=True；动作 无
- 完整原始响应：[`artifact-d2010300747c4edc801c89890a9a50e8`](raw/call-6b331ee71efb45ea9f73740a587d0446-artifact-d2010300747c4edc801c89890a9a50e8.txt)

## 十一、复审、历史与限制

- 完整性：`partial`
- 当前运行限制：逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.；评审任务 TASK02 没有形成可执行检查覆盖；报告不能视为任务全覆盖。；必需覆盖单元 coverage-14e5e808f9eb902d 尚未由检查或逐屏审查覆盖；报告不能视为完整。
- 会话历史警告：逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.；发现退回补证：「作业到期」行可见 ON／OFF，当前状态难以辨认；结构/状态 claim 缺少 OCR、元素或结构数据。；评审任务 TASK02 没有形成可执行检查覆盖；报告不能视为任务全覆盖。；必需覆盖单元 coverage-14e5e808f9eb902d 尚未由检查或逐屏审查覆盖；报告不能视为完整。；会话不变量：必需覆盖单元 coverage-14e5e808f9eb902d 尚未覆盖。
- 本轮没有登记复审项。

## 十二、可复核文件

报告包应同时包含 `report.json`、`process.json`、`checks.json`、`evidence.json`、`findings.json`、`stages/T01.json`—`stages/T10.json`、`report-showcase.md`、`report-summary.md`、`method/` 方法原文与哈希以及原始响应附件。单独打开 Markdown 时，模型原始响应和证据画面仍可通过会话 artifact 接口按 ID 读取。

> 本报告引用模型调用 8 次；测试夹具否。