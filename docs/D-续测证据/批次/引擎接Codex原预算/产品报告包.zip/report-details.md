# 协同交互方案评审报告

> 会话：`session-19b406b55d364f1ebd40c709039af7c8`  
> 运行：`run-b81ad247799347429f9b9680d82788af`  
> 报告版本：`1`  
> 状态 / 完整性：`awaiting_input` / `partial`  
> 技术路径：`A 0.2-method-draft / T01–T10`  
> 判据版本：`0.2-method-draft`  
> 证据模式：`design`

## 一、结论摘要

本次围绕“从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。”执行 34 项检查。执行状态：executed=34；判断状态：insufficient_evidence=18；needs_clarification=1；no_visible_issue=5；not_applicable=10。`complete` 仅表示计划项均有可追溯处置，不代表产品全部通过。

当前没有通过证据核验的候选发现；请结合未决项理解范围。

## 二、版本、路径与复现

| 字段 | 当前值 |
| --- | --- |
| 会话 / 运行 | `session-19b406b55d364f1ebd40c709039af7c8` / `run-b81ad247799347429f9b9680d82788af` |
| 上下文 / 报告版本 | 1 / 1 |
| 会话契约 | `session-1.0` |
| 判据 / 方法 | `0.2-method-draft` / A T01–T10 |
| 方法目录 | 方法专家开发交付-v0.2 |
| 判据来源 | {'name': "Jakob Nielsen's 10 Usability Heuristics for User Interface Design", 'url': 'https://www.nngroup.com/articles/ten-usability-heuristics/', 'relationship': '以下条目由小组据宽泛原则操作化，并非源文逐条摘录或正式规范符合性声明'} |
| 模型 | codex_cli/gpt-6-astra |
| 是否测试夹具 | 否 |
| 方法文件指纹 | `{'00先看这个！！！！-阅读与开发交接.md': '6dca7b14918a08d65e40362bfec2fc40a1f8f1d0492e4f356b2ac9b8f00d051e', '01-04-场景输入流程与技术路径.md': 'fe432cf3851ad10528e53d6fecc14e9ffaba0a4fafd96a1b6ee61c4007c28347', '05-24条判据修订与变更对照.md': 'bd2f82f8d8e539d2011b0b684d77de775b0149ec0e14736717944f2057847c99', '05-判据库-v0.2.json': 'b785eb9c6b64b5d9ceb87ca76430af4a2658c944c9aff99a97ce9298bdf54af7', '05-判据执行补充-v0.2.json': '8e502b943023c7e39a8da6a479c1cc09f621c9474520e4f116cae0553bc9c24d', '05-逐字段变更对照.csv': 'd0b1d25442662ecf10150e923b98b8049ad7291e2bf56653690a138392d8307d', '06-新场景方法-v0.2.json': '1702aa0350c41ced0363a41d73c46aeb547d60d7299616964875b51ce8fd689c', '06-新场景方法与正反例.md': 'e21e0996cc25bc218f5e24e2c3a7aa66649001eb58ad00e84fcb5fc88b48ca26', '07-会话变更重查与复审规则.md': 'c9a5f573648a20094f4b0c4602043979b33ea3cb935a6976b641cf57b539f025', '08-问题表达严重度与评价验收.md': '4d92cfcfdb8417a20678995528ea0180f6182eb52b0b2becbb3a7fc44886eead', '09-开发验收用例.json': 'fc85e0bd301b081d393ab4764f0f0b59003e2462d842ebee91bc990eb9f41f60', '09-开发验收用例.md': 'e2ca3487871026558697e1283734849af2ef94de25b984ade9ae8334a73a2fd3', '10-来源索引.json': 'e6147e42231bb4602cb506caa7a2d6ff69812b2d7d1289731a33220db667017a', '11-交付校验结果.json': '3ec123147dae0c46a6bd2a473a0c5f0bbe5f1d311f42bc2568e41b63b5694cad'}` |

复现依据是本次保存的原始材料、证据、模型原始响应、检查计划与判断记录；不得用新运行结果覆盖本版本。

判定口径：R/E01–E06 使用 `candidate_issue`、`no_visible_issue`、`insufficient_evidence`、`not_applicable`；G/REQ/E07 使用 `met`、`observed_violation`、`insufficient_evidence`；E08 使用 `open`、`no_conflict`、`needs_clarification`、`resolved`。`complete` 只表示计划项均有处置，不表示问题数为零或运行效果已验证。

## 三、输入材料

| 来源 | 类型/角色 | 版本 | 读取状态 | 证据数 | 入口 |
| --- | --- | --- | --- | ---: | --- |
| `src-da076a3af03d4740afa0d4552a1aef4a` 通知设置 | image / design | 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7 | success | 1 |  |
| `src-9e806f11666a4996a5284eeba516d441` initial_purpose | document / review_instruction | context-1 | success | 1 | user://initial_purpose |

<img src="artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin" alt="通知设置" style="display:block;max-width:100%;width:640px;height:auto;margin:12px 0;border:1px solid #ddd;border-radius:4px;" loading="lazy">

## 四、T01–T10 逐步输入输出

| 阶段 | 状态 | 输入摘要 | 输出摘要 | 模型调用 | 模型耗时 |
| --- | --- | --- | --- | --- | ---: |
| T01 接收与能力检查 | completed | {'purpose': '从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。', 'source_count': 2} | {'session_id': 'session-19b406b55d364f1ebd40c709039af7c8', 'capabilities': {'schema_version': 'session-1.0', 'methods_version': '0.2-method-draft', 'technical_path_version': 'A-0.2/T01-T10', 'method_root': '方法专家开发交付-v0.2', 'method_validation': {'delivery_version': '0.2-method-draft', 'checked_files': 12, 'mismatches': 0}, 'rules': 24, '… | 无 | 0ms |
| T02 材料读取与证据登记 | completed | {'sources': [{'source_id': 'src-da076a3af03d4740afa0d4552a1aef4a', 'kind': 'image', 'reference': '', 'role': 'design', 'version': '490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7'}, {'source_id': 'src-9e806f11666a4996a5284eeba516d441', 'kind': 'document', 'reference': 'user://initial_purpose', 'role': 'review_instruction', 'version': 'contex… | {'evidence_count': 2, 'evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258', 'ev-0505f5c1a4a14b61b1364d9b21983f16'], 'source_status': {'src-da076a3af03d4740afa0d4552a1aef4a': 'success', 'src-9e806f11666a4996a5284eeba516d441': 'success'}, 'warnings': ['逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.']} | 无 | 0ms |
| T03 任务与材料理解 | completed | {'evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258', 'ev-0505f5c1a4a14b61b1364d9b21983f16'], 'context_version': 1} | {'task_summary': '根据静态设置页，辨认通知偏好的可选项、当前状态，以及调整和保存的入口。', 'target_user_summary': '', 'review_tasks': [{'task_id': 'TASK01', 'text': '在“个人设置”的“通知偏好”中，查看课程提醒和作业到期提醒的选项，辨认各自的当前状态。', 'success_criteria': '能分别指出两项提醒有哪些选项，并说明画面中哪些标记可用于辨认当前选择。', 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'source_ids': ['src-9e806f11666a4996a5284eeba516d441', 'src-da076a3af03d4740afa0d4552a1a… | call-bc8f990805184d8caa6b07f1dd9f1bbb | 19610ms |
| T04 检查规划与适用性筛选 | completed | {'goal_refs': [], 'requirement_refs': [], 'evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258', 'ev-0505f5c1a4a14b61b1364d9b21983f16']} | {'check_count': 34, 'applicability': {'applicable': 7, 'needs_context': 16, 'not_applicable': 11, 'not_assessed': 0}, 'check_refs': ['R17', 'R17', 'E03', 'R18', 'R19', 'R06', 'R12', 'R01', 'R02', 'R03', 'R04', 'R05', 'R07', 'R08', 'R09', 'R10', 'R11', 'R13', 'R14', 'R15', 'R16', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E04', 'E05', 'E06', 'E07', 'E07', 'E08']} | call-a36671dc9905480abd7205b8cf96402a, call-1a5fb90c52a34bb28c7fb093eb1d2161, call-2894d51bb7c741daa260e966335c655d, call-6285d28c6ed04164ad2e3ede9dcc34ee | 143452ms |
| T05 执行、取证与逐屏技术审查 | partial | {'authorized_interaction': False, 'planned_check_refs': ['R17', 'R17', 'E03', 'R18', 'R19', 'R06', 'R12', 'R01', 'R02', 'R03', 'R04', 'R05', 'R07', 'R08', 'R09', 'R10', 'R11', 'R13', 'R14', 'R15', 'R16', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E04', 'E05', 'E06', 'E07', 'E07', 'E08']} | {'action_count': 1, 'actions': [{'action_id': 'action-f1af2d71a84e4612b8c7d99c0ec7763a', 'source_id': 'src-da076a3af03d4740afa0d4552a1aef4a', 'kind': 'observe', 'node_id': '', 'chunk_index': 0, 'selector': '', 'value': '', 'url': '', 'x': None, 'y': None, 'scroll_x': 0, 'scroll_y': 0, 'expected_state_id': '490a35029c5a2cd09ff58635', 'reason': '在同一张截图中对照“开启”的蓝底与“关闭”的白底，检查 ON 和 OFF 是否也有可区分的选中标记，并核对各组选项与行标签、保存入口的位置。', '… | call-ec8b509087024302b49a72e59cc8f8d0 | 13969ms |
| T06 逐项判断 | completed | {'check_ids': ['check-7de4b434ec81105e', 'check-0af2ad49d3698698', 'check-415dd13a3cbe551e', 'check-71234159b928ef65', 'check-ae6d7f132427e23c', 'check-61ea34a0297f3bed', 'check-ec74622a8c0def8a', 'check-0a9e41533c8cdeb1', 'check-95903e428c6c287f', 'check-41092d8e37c0af4e', 'check-53c2ba44ff91d3c1', 'check-68a85fab8bacc5d1', 'check-963e46c5f11f0623', 'check-… | {'decisions': {'no_visible_issue': 5, 'insufficient_evidence': 18, 'not_applicable': 10, 'needs_clarification': 1}, 'judgments': [{'check_id': 'check-7de4b434ec81105e', 'ref': 'R17', 'decision': 'no_visible_issue', 'reason': '“课程提醒”行右侧的“开启”为蓝底白字，“关闭”为白底深字。两项可直接对照，画面标出当前选择为“开启”。', 'evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258']}, {'check_id': 'check-0af2ad49d3698698', 'ref': 'R17', 'decision': 'insufficient_ev… | call-c2b6f0bf93b44dfeb5ad671ed9f54167, call-4ccf5bd95a2c47658259351968ad6c7c, call-050cfc0d105c4b9492b39b8536f74318 | 86969ms |
| T07 证据核验与发现归并 | not_needed | {'candidate_finding_count': 0} | {'verified_finding_ids': [], 'rejected': []} | 无 | 0ms |
| T08 讨论、变更与重查 | waiting | {'context_version': 1, 'events': [{'at': '2026-11-03T19:00:55.691856+00:00', 'actor_type': 'human', 'type': 'purpose', 'content': '从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。'}, {'at': '2026-11-03T19:00:55.708906+00:00', 'actor_type': 'program', 'type': 'run_started', 'run_id': 'run-b81ad247799347429f9b9680d82788af', 'warning_count': 0}, {'at': '2026-11-03T19:05:20… | {'questions': [{'question_id': 'question-3d86375ef6a44effb006544f33ed915b', 'text': '是否授权动作：在同一张截图中对照“开启”的蓝底与“关闭”的白底，检查 ON 和 OFF 是否也有可区分的选中标记，并核对各组选项与行标签、保存入口的位置。', 'reason': '来源 src-da076a3af03d4740afa0d4552a1aef4a，动作 observe；尚未执行。', 'check_ids': [], 'blocking': True, 'answered': False, 'answer': '', 'kind': 'authorization', 'source_id': 'src-da076a3af03d4740afa0d4552a1aef4a', 'action_id': 'action-f1af2d71a84e4612b8… | 无 | 0ms |
| T09 报告与保存 | completed | {'run_id': 'run-b81ad247799347429f9b9680d82788af', 'check_count': 34} | {'report_version': 1, 'report_completeness': 'partial', 'status': 'awaiting_input'} | 无 | 0ms |
| T10 修改后复审 | not_needed | {'previous_finding_ids': []} | {'rechecks': []} | 无 | 0ms |

```mermaid
flowchart LR
    T01["T01 接收与能力检查<br/>completed"]
    T02["T02 材料读取与证据登记<br/>completed"]
    T03["T03 任务与材料理解<br/>completed"]
    T04["T04 检查规划与适用性筛选<br/>completed"]
    T05["T05 执行、取证与逐屏技术审查<br/>partial"]
    T06["T06 逐项判断<br/>completed"]
    T07["T07 证据核验与发现归并<br/>not_needed"]
    T08["T08 讨论、变更与重查<br/>waiting"]
    T09["T09 报告与保存<br/>completed"]
    T10["T10 修改后复审<br/>not_needed"]
    T01 --> T02
    T02 --> T03
    T03 --> T04
    T04 --> T05
    T05 --> T06
    T06 --> T07
    T07 --> T08
    T08 --> T09
    T09 --> T10
```


### T01 · 接收与能力检查

- 状态：`completed`
- 输入：评审目的 1 条；来源 2 项
- 输出：契约 session-1.0；方法 0.2-method-draft；R=24；E=8
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T02 · 材料读取与证据登记

- 状态：`completed`
- 输入：来源 2 项
- 输出：证据 2 条；来源状态 读取成功=2
- 模型调用：无
- 模型耗时：0ms
- 关联证据：ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16

### T03 · 任务与材料理解

- 状态：`completed`
- 输入：用于理解的材料证据 2 条
- 输出：目标 0；要求 0；意见 0；冲突 0；未知 4
- 模型调用：call-bc8f990805184d8caa6b07f1dd9f1bbb
- 模型耗时：19610ms
- 关联证据：ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16

### T04 · 检查规划与适用性筛选

- 状态：`completed`
- 输入：目标 0；要求 0；可用证据 2
- 输出：检查 34 项；不适用=11；待补上下文=16；未评估=0；适用=7
- 模型调用：call-a36671dc9905480abd7205b8cf96402a, call-1a5fb90c52a34bb28c7fb093eb1d2161, call-2894d51bb7c741daa260e966335c655d, call-6285d28c6ed04164ad2e3ede9dcc34ee
- 模型耗时：143452ms
- 关联证据：ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16

### T05 · 执行、取证与逐屏技术审查

- 状态：`partial`
- 输入：交互授权 否；计划检查 34
- 输出：动作 1；状态变化 0；结果 尚无可靠结果=1
- 模型调用：call-ec8b509087024302b49a72e59cc8f8d0
- 模型耗时：13969ms
- 关联证据：ev-6feecfb26247416bab7e0910276f6258

### T06 · 逐项判断

- 状态：`completed`
- 输入：检查 34；计划证据 2
- 输出：不适用=10；待澄清=1；未发现可见问题=5；证据不足=18
- 模型调用：call-c2b6f0bf93b44dfeb5ad671ed9f54167, call-4ccf5bd95a2c47658259351968ad6c7c, call-050cfc0d105c4b9492b39b8536f74318
- 模型耗时：86969ms
- 关联证据：ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16

### T07 · 证据核验与发现归并

- 状态：`not_needed`
- 输入：候选发现 0
- 输出：通过核验 0；退回 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T08 · 讨论、变更与重查

- 状态：`waiting`
- 输入：上下文版本 1
- 输出：问题 2；业务决定 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T09 · 报告与保存

- 状态：`completed`
- 输入：运行 run-b81ad247799347429f9b9680d82788af；检查 34
- 输出：报告 v1；完整性 部分；状态 awaiting_input
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

### T10 · 修改后复审

- 状态：`not_needed`
- 输入：旧问题 0
- 输出：复审记录 0
- 模型调用：无
- 模型耗时：0ms
- 关联证据：无

## 五、目标要求对应与材料理解

- 任务理解：根据静态设置页，辨认通知偏好的可选项、当前状态，以及调整和保存的入口。
- 目标用户：未明确
- 未知：材料未说明目标用户、产品原始目标或正式验收条件。
- 未知：“课程提醒”的“开启”为蓝底，“关闭”为白底；“作业到期”的 ON 和 OFF 位于同一浅色底上。材料未说明选中样式与已保存值的对应规则。
- 未知：“界面主题”和“文字大小”各有两个文字选项，“消息工具”有三个无文字图标。材料未说明三个图标各自的作用，也未说明这些设置与提醒的关系。
- 未知：静态画面未展示选择后的状态变化、修改何时生效、保存反馈或再次打开页面后的值。

### 已观察状态与动作迁移

| 状态 | 来源 | 定位 | 入/出 | 已接入检查 |
| --- | --- | --- | ---: | --- |
| `490a35029c5a2cd09ff58635` | src-da076a3af03d4740afa0d4552a1aef4a | {"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900} | 0/0 | 是 |

### 必需覆盖矩阵

| 覆盖单元 | 任务 | 状态 | 来源 | 已覆盖 | 缺证类型 |
| --- | --- | --- | --- | --- | --- |
| `coverage-98d9ffd1b8239003` | TASK01 | 490a35029c5a2cd09ff58635 | src-da076a3af03d4740afa0d4552a1aef4a | 是 | — |
| `coverage-f99744bdbff88a94` | TASK02 | 490a35029c5a2cd09ff58635 | src-da076a3af03d4740afa0d4552a1aef4a | 是 | — |

## 六、证据链总表

| 证据 | 来源 / 类型 | 版本 | 定位 | 内容摘要 | 被哪些检查/发现使用 |
| --- | --- | --- | --- | --- | --- |
| `ev-6feecfb26247416bab7e0910276f6258` | src-da076a3af03d4740afa0d4552a1aef4a / design | 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7 | {"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false} | 用户提供的静态界面，不证明点击后行为。 | R17, R17, E03, R18, R19, R06, R12, R01, R02, R03, R04, R05, R07, R08, R09, R10, R11, R13, R14, R15, R16, R20, R21, R22, R23, R24, E01, E02, E04, E05, E06, E07, E07, E08 |
| `ev-0505f5c1a4a14b61b1364d9b21983f16` | src-9e806f11666a4996a5284eeba516d441 / statement | context-1 | 文档分块 0/1；行 1-1；字符 0-36 | 从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。 | R18, R19, R06, R05, R16, R20, R23, R24, E01, E04, E05, E07, E07, E08 |

## 七、逐项检查与判断

| 编号 | 类型 | 适用性 | 执行 | 判断 | 证据 | 发现 |
| --- | --- | --- | --- | --- | --- | --- |
| `R17` 当前选择状态可见 | rule | applicable | executed | no_visible_issue | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R17` 当前选择状态可见 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `E03` 操作与反馈状态对应 | method | applicable | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R18` 相关输入和选项形成可识别的组 | rule | applicable | executed | no_visible_issue | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R19` 主要任务操作易于定位 | rule | applicable | executed | no_visible_issue | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R06` 操作名称说明预期结果 | rule | applicable | executed | no_visible_issue | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R12` 同类控件呈现一致的视觉规则 | rule | applicable | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R01` 当前导航位置可见 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R02` 多步骤任务显示当前步骤 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R03` 等待状态说明系统正在做什么 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R04` 完成状态说清结果 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R05` 关键文案避免未解释的内部术语 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R07` 输入项名称说明所需信息 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R08` 弹窗具有可见退出方式 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R09` 多步骤页面具有可见返回方式 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R10` 确认页允许取消高风险操作 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R11` 同一动作使用一致名称 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R13` 必填项在填写前可识别 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R14` 受格式限制的字段提供输入提示 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R15` 高后果操作确认页说明对象和动作 | rule | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R16` 重要图标操作具有可见含义线索 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R20` 无关信息不压过主要任务 | rule | applicable | executed | no_visible_issue | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `R21` 错误状态指明问题位置 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R22` 错误提示给出修正办法 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R23` 错误提示使用用户可理解的语言 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `R24` 复杂任务提供就近帮助入口 | rule | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `E01` 关键任务路径衔接 | method | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |
| `E02` 跨页面对象与信息一致性 | method | not_applicable | executed | not_applicable | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `E04` 返回取消后的任务恢复 | method | not_applicable | executed | not_applicable | ev-0505f5c1a4a14b61b1364d9b21983f16, ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `E05` 异常分支与恢复路径 | method | not_applicable | executed | not_applicable | ev-0505f5c1a4a14b61b1364d9b21983f16, ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `E06` 前置条件与操作开放状态 | method | needs_context | executed | insufficient_evidence | ev-6feecfb26247416bab7e0910276f6258 | 无 |
| `E07` 目标与明确要求落实 | goal | needs_context | executed | insufficient_evidence | 无 | 无 |
| `E07` 目标与明确要求落实 | goal | needs_context | executed | insufficient_evidence | 无 | 无 |
| `E08` 跨职能要求冲突识别与处理 | conflict | not_applicable | executed | needs_clarification | ev-6feecfb26247416bab7e0910276f6258, ev-0505f5c1a4a14b61b1364d9b21983f16 | 无 |

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-7de4b434ec81105e` / rule
- 计划：applicable；同一行中“开启”为蓝底白字，“关闭”为白底深字，可比较设计中的选中标记。已保存值不在本项检查范围内。
- 对象：['课程提醒行的“开启”和“关闭”']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：“课程提醒”行右侧的“开启”为蓝底白字，“关闭”为白底深字。两项可直接对照，画面标出当前选择为“开启”。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R17 · 当前选择状态可见

- 检查 ID / 类型：`check-0af2ad49d3698698` / rule
- 计划：needs_context；ON 与 OFF 共用浅色底。需先确认此状态是否已有选中项，再核对相应标记。
- 对象：['作业到期行的 ON 和 OFF']
- 必需证据类型：['design']
- 缺项：['注明本画面是否已选、若已选则选中哪一项的设计说明']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：“作业到期”行的 ON 和 OFF 共用浅色底，未见单独高亮、勾选或滑块指向其中一项。仅凭画面无法辨认当前值，也未确认此状态已有选中项，尚不满足 R17 的报问题条件。
- 判据/方法定义：当前选择状态可见；适用：存在页面内单选/多选/筛选且已确认至少一项处于选中状态；页面级导航归R01。；检查：核对选中状态依据，比较选中与未选项；运行时记录选择前后，不从点击行为单独推断已选。；触发：选中事实已知且区域完整，但无法辨认当前选项或显示与已确认状态冲突。；弃权：无此控件或确认尚未选择时不适用；是否已选未知、分辨率不足或状态未取得时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E03 · 操作与反馈状态对应

- 检查 ID / 类型：`check-415dd13a3cbe551e` / method
- 计划：applicable；课程提醒的“开启”为蓝底、“关闭”为白底；作业到期的 ON 和 OFF 共用浅底。逐行核对能将当前选择与另一选项区分的标记。
- 对象：['课程提醒的“开启”和“关闭”', '作业到期的 ON 和 OFF']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：静态对照可辨认“课程提醒”的蓝底“开启”，但“作业到期”的 ON 和 OFF 没有可辨的选中标记，也缺少该行应呈现何种状态的依据。两行的当前状态只能确认其一。
- 判据/方法定义：操作与反馈状态对应；对象：动作触发、等待/选择/完成/失败等反馈及其对应操作对象。；适用：存在可执行动作或明确的状态设计，且动作应产生的变化有任务依据。；触发：动作实际触发有证据，但反馈缺失/错误关联/与明确预期冲突，范围和观察条件足以支持本次结论。；弃权：动作未触发、工具失败、只有前状态、观察条件不足或异步完成条件未知时证据不足；无状态变化检查对象时不适用。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R18 · 相关输入和选项形成可识别的组

- 检查 ID / 类型：`check-71234159b928ef65` / rule
- 计划：applicable；任务明确要求调整两类提醒，可沿行标题、对齐和分隔线核对“开启／关闭”和“ON／OFF”各属哪项设置。
- 对象：['通知偏好卡片', '课程提醒行', '作业到期行', '两行之间的界面主题设置']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：两组提醒均有行标签。第一行右侧的“开启／关闭”对应“课程提醒”，第三行右侧的 ON／OFF 对应“作业到期”。水平对齐与行间分隔线明确了各组选项的归属。
- 判据/方法定义：相关输入和选项形成可识别的组；适用：已确认存在多个相关输入字段或成组选项，业务分组关系已知；纯展示卡不纳入。；检查：逐项记录输入/可选/纯展示角色及其证据，核对关系来源，再检查组标题、间距与边界。；触发：输入/选择角色和分组关系已确认，相关与无关项混排，造成具体归属歧义。；弃权：确认仅纯展示、单个字段或单个选项时不适用；交互角色或分组关系未知、相关区域不全时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R19 · 主要任务操作易于定位

- 检查 ID / 类型：`check-ae6d7f132427e23c` / rule
- 计划：applicable；可检查两行右侧的选项及卡片右下角“保存设置”的文字、位置和遮挡情况。静态图只支持检查入口。
- 对象：['课程提醒行', '作业到期行', '保存设置按钮']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：两项提醒的调整入口都在各自行的右侧。“保存设置”蓝色按钮单独位于卡片右下角，文字完整，未见遮挡。
- 判据/方法定义：主要任务操作易于定位；适用：已确认主任务及对应主操作，取得其所在区域和必要上下文。；检查：记录主操作、竞争元素、位置/遮挡/层级关系；计算显著性只作线索，真人识别另行验证。；触发：有具体可见证据表明主操作被遮挡、与任务脱离或层级混淆，难以从当前界面定位。；弃权：确认无本条操作对象时不适用；主任务未知、区域未取得或仅有代理分值时证据不足；不能因按钮不最大而直接报问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R06 · 操作名称说明预期结果

- 检查 ID / 类型：`check-61ea34a0297f3bed` / rule
- 计划：applicable；调整对象和保存目的已知。可逐行核对选项文字是否说明要切换到的状态，再核对卡片右下角按钮是否说明保存动作。
- 对象：['课程提醒行的“开启／关闭”', '作业到期行的“ON／OFF”', '“保存设置”按钮']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：结合行标签，“开启／关闭”和 ON／OFF 分别给出两项提醒可选的目标状态。“保存设置”写明了动作及对象。ON／OFF 的当前选择难以辨认，属于状态标记问题，与选项名称分开判断。
- 判据/方法定义：操作名称说明预期结果；适用：当前状态有主要按钮/入口，用户任务和动作目的已知。；检查：核对按钮文字、邻近内容与预期动作；运行结果可用于确认动作，但不能替代文案清晰度检查。；触发：主要按钮使用泛词或含义不符，结合邻近说明仍不能理解预期结果，或与明确动作目的冲突。；弃权：无主操作对象时不适用；任务/动作目的不明或上下文缺失时证据不足；周围内容已清楚说明时，泛词本身不构成问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R12 · 同类控件呈现一致的视觉规则

- 检查 ID / 类型：`check-ec74622a8c0def8a` / rule
- 计划：applicable；两行均在同一卡片提供开关选择。可对照“开启”的独立蓝底与ON/OFF的共用浅底，检查各组如何区分选项，不预设两项都已开启。
- 对象：['课程提醒：开启、关闭', '作业到期：ON、OFF']
- 必需证据类型：['design']
- 缺项：['若要判定同状态样式是否一致，需两组控件的选中、未选中及禁用态标注']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：两行都是提醒开关，但“课程提醒”以独立蓝底突出“开启”，“作业到期”两项共用浅底。后者的选择状态和启用状态均未标注，无法判断同状态控件是否使用了不一致的标记。
- 判据/方法定义：同类控件呈现一致的视觉规则；适用：存在至少两个功能、层级、状态和设计语境可比的控件，可跨同版本页面。；检查：先核对可比条件，再比较形状、颜色、文字、状态表达，记录差异造成的类别/状态歧义。；触发：同类同状态控件存在无解释的显著规则差异，具体导致操作类别或状态含义混淆。；弃权：只有一个可比对象时不适用；控件层级/状态/规范依据未知时证据不足；有明确状态或主题理由的差异不报问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R01 · 当前导航位置可见

- 检查 ID / 类型：`check-0a9e41533c8cdeb1` / rule
- 计划：needs_context；“个人设置”标题可确认页面身份，但页首未说明该页是否对应某个导航项。提醒行内的开关属于偏好选项。
- 对象：['“个人设置”标题及页首导航区域']
- 必需证据类型：['design']
- 缺项：['页面级导航结构及“个人设置”与导航项的对应关系']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：标题可确认当前页为“个人设置”，但材料未建立该页与页首某个导航项的对应关系，无法核对当前导航标记。
- 判据/方法定义：当前导航位置可见；适用：已确认当前页面且存在页面级导航。页面内筛选/单选交由R17。；检查：记录当前页面依据，比较页面级导航项及当前项标识；运行模式分别记录跳转前后导航。；触发：页面级导航及当前页面已知，可完整查看相关导航，但当前项无可辨选中标识或标识与当前页面冲突。；弃权：已知是无页面级导航的入口页时不适用；当前页面身份不明、导航被裁切或目标未加载完整时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R02 · 多步骤任务显示当前步骤

- 检查 ID / 类型：`check-95903e428c6c287f` / rule
- 计划：needs_context；提醒选项与“保存设置”同页可见；先选择再保存的操作顺序不足以确认该页属于分步流程。
- 对象：['通知偏好卡片及“保存设置”入口']
- 必需证据类型：['design']
- 缺项：['说明该页是否独立，以及它在分步流程中所处位置的设计材料']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：提醒选项与保存入口同页可见。材料未说明该页属于多步骤流程，无法核对当前步骤。
- 判据/方法定义：多步骤任务显示当前步骤；适用：已由流程说明或实际路径确认是多步骤任务，当前页属于其中一步。；检查：记录步骤关系、当前步骤与可见进度线索，结合标题和上下文判断当前环节是否可辨。；触发：多步骤与当前位置已确认，但相关区域完整可查时仍无法从标题、进度或上下文辨认当前环节。；弃权：已确认独立单页时不适用；仅见一页且无法确认步骤关系，或进度区域未取得时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R03 · 等待状态说明系统正在做什么

- 检查 ID / 类型：`check-41092d8e37c0af4e` / rule
- 计划：not_applicable；本状态完整呈现偏好选项和保存入口，是供选择的常态设置画面。等待说明只适用于已呈现的处理状态。
- 对象：['通知偏好卡片当前画面']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：当前画面完整呈现常态设置选项和保存入口，没有正在加载、上传或处理的等待状态可评价。
- 判据/方法定义：等待状态说明系统正在做什么；适用：当前取得的画面已经呈现加载、上传或处理中等等待状态；可来自截图、原型或运行记录。；检查：记录等待对象、可见文案与进度线索；运行时记录触发动作、观察时长及前后状态。；触发：已确认处于等待，完整相关区域仅有无法解释的转圈/空白，结合上下文仍不能判断正在处理的任务。；弃权：已确认普通非等待状态时不适用；无法确认等待状态、区域不全或动作结果未取得时证据不足；不能由点击前截图推断无反馈。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R04 · 完成状态说清结果

- 检查 ID / 类型：`check-53c2ba44ff91d3c1` / rule
- 计划：needs_context；“保存设置”标出动作入口；检查结果文案是否说清保存对象，需要取得与该动作对应的完成画面。
- 对象：['“保存设置”入口及其对应的完成状态']
- 必需证据类型：['design']
- 缺项：['标明由“保存设置”触发的完成态设计画面']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：画面仅显示“保存设置”入口。保存后的完成态和结果文案超出本次范围，无法评价其是否说清保存对象。
- 判据/方法定义：完成状态说清结果；适用：已取得某次操作完成/成功状态，完成对象与上下文可确认。；检查：检查成功表达是否能说明已完成的动作、对象及确有必要的后续操作。；触发：完成状态已确认，但只有泛化成功信息，结合上下文仍无法判断完成了什么，或遗漏任务必需的下一步线索。；弃权：明确非完成状态时不适用；只有完成前画面、对象不明或结果区域缺失时证据不足；没有后续任务不要求强加下一步。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R05 · 关键文案避免未解释的内部术语

- 检查 ID / 类型：`check-68a85fab8bacc5d1` / rule
- 计划：needs_context；辨认选项需理解“开启／关闭”和“ON／OFF”。材料未说明目标用户、专业程度或熟悉度，使用英文也不足以认定是内部术语。
- 对象：['课程提醒的“开启／关闭”', '作业到期的“ON／OFF”']
- 必需证据类型：['design', 'statement', 'observation']
- 缺项：['目标用户及其专业背景', '这些词是否具有产品内部含义', '目标用户辨认这些选项时的理解记录']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：选择目标状态需要理解“开启／关闭”和 ON／OFF。材料未说明目标用户、专业程度、对这些词的熟悉度或词语是否有内部含义，仅凭英文标签无法判定理解障碍。
- 判据/方法定义：关键文案避免未解释的内部术语；适用：已确认非领域专家用户，存在非错误状态的关键任务文案；错误文案转R23。；检查：逐词记录任务必要性、内部术语含义来源、目标用户熟悉度依据与可见解释；词表只能证明含义，不能证明熟悉度。；触发：有依据确认非专家完成主任务必须理解某内部术语，该用户群不熟悉该词，界面又未解释。；弃权：明确没有相关对象或目标用户为领域专家时不适用；用户、含义、必要性或熟悉度影响结论却未知时证据不足。已解释/有熟悉依据时不能报问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R07 · 输入项名称说明所需信息

- 检查 ID / 类型：`check-963e46c5f11f0623` / rule
- 计划：not_applicable；两项提醒均以行内预设选项表达调整方式，任务是辨认并选择已有值，无需填写字段。
- 对象：['课程提醒行', '作业到期行']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：两行均提供预设选项，调整提醒无需填写表单字段。
- 判据/方法定义：输入项名称说明所需信息；适用：存在需要填写的重要表单字段，字段任务可确认。；检查：核对字段名称与紧邻说明；运行时分别查看输入前后，确认必要名称线索是否仍可获取。；触发：字段无名称或名称模糊，结合邻近内容仍无法知道应填什么；运行证据显示输入后唯一必要说明消失并产生含义不明。；弃权：无输入对象时不适用；字段说明区域裁切、业务含义未知或未取得输入后画面时，对相应判断记证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R08 · 弹窗具有可见退出方式

- 检查 ID / 类型：`check-ca2972b3610d5d1a` / rule
- 计划：not_applicable；调整选项和保存按钮位于“个人设置”正文卡片内。当前检查对象是页内面板，普通弹窗的退出判据不适用于该面板。
- 对象：['“个人设置”正文中的通知偏好卡片']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：“通知偏好”是“个人设置”页内的正文卡片，当前画面没有需要退出的弹窗。
- 判据/方法定义：弹窗具有可见退出方式；适用：存在普通信息/输入弹窗，完整边界可取得；高风险确认归R10。；检查：检查可见关闭/取消/返回方式；只有实际执行后才描述是否成功退出，行为验证转E01/E04。；触发：普通可中断弹窗占据焦点，完整边界和相关说明可查，但没有任何可见退出方式。；弃权：高风险确认或已确认不可中断流程不适用；边缘被裁、弹窗性质不明时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R09 · 多步骤页面具有可见返回方式

- 检查 ID / 类型：`check-1d15677138683765` / rule
- 计划：needs_context；页面标题为“个人设置”，不能据此确定它是独立页还是流程中的非首步；截图也未涵盖浏览器导航。
- 对象：['个人设置页']
- 必需证据类型：['design']
- 缺项：['设置页在任务流程中的位置', '若为非首步，需该步完整的页面及系统导航设计']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：材料未确认“个人设置”处于多步骤任务的非首步，截图也未涵盖系统返回入口，无法判定该步的返回方式。
- 判据/方法定义：多步骤页面具有可见返回方式；适用：确认当前是多步骤任务非首步，且不是高风险确认页。；检查：检查可见返回/退出入口，说明系统/浏览器返回是否在本次观察范围内；执行结果交E01/E04。；触发：当前非首步已确认且相关区域完整，页面与可观察系统入口均无可见返回或退出方式。；弃权：已确认首步/独立页或高风险确认时不适用；步骤未知、系统导航未涵盖且可能承担功能、页面不全时证据不足。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R10 · 确认页允许取消高风险操作

- 检查 ID / 类型：`check-86bd669bec9be07a` / rule
- 计划：not_applicable；当前画面供用户选择偏好并找到“保存设置”，不是要求用户确认高风险操作的界面。
- 对象：['通知偏好卡片', '保存设置']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：当前画面供用户编辑通知偏好，没有高风险操作的确认界面可检查。
- 判据/方法定义：确认页允许取消高风险操作；适用：已确认删除/清空/永久变更等高风险操作的确认界面。；检查：检查清楚可见的取消/返回入口；默认仅观察，不为验证本条而执行真实危险操作。；触发：高风险性质已确认，确认区域完整且仅能执行，没有可见取消/返回入口。；弃权：明确非高风险确认时不适用；风险性质未知或取消区未取得时证据不足；无授权不执行真实副作用。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R11 · 同一动作使用一致名称

- 检查 ID / 类型：`check-10644cfee856c4f3` / rule
- 计划：needs_context；“开启/关闭”和“ON/OFF”分别作用于课程提醒和作业到期。可比较措辞，但不能仅凭含义相近认定它们是同一动作的两个入口。
- 对象：['课程提醒：开启、关闭', '作业到期：ON、OFF']
- 必需证据类型：['design']
- 缺项：['说明两组入口所指动作及命名语境的设计标注']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R11 要求两个入口指向同一动作。“开启／关闭”对应课程提醒，“ON／OFF”对应作业到期。两组措辞可比较，但材料未证明它们是同一动作的两个入口。
- 判据/方法定义：同一动作使用一致名称；适用：在同一材料或已确认的同版本多页面中，至少两个入口明确指向同一动作。；检查：记录动作同一性的依据，比较入口名称与解释；不同对象的名称差异不据此判动作不一致。；触发：已证实同一动作、同一语境使用互相矛盾或无解释的不同名称。；弃权：仅一个相关入口时不适用；动作是否相同、版本或语境未知时证据不足；功能/对象/阶段确有差异且名称合理时未见问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R13 · 必填项在填写前可识别

- 检查 ID / 类型：`check-8cbced4a72a0ab42` / rule
- 计划：needs_context；画面列出了两组提醒选项，但未说明保存前是否必须作出选择；不能用有无星号推断必填规则。
- 对象：['课程提醒', '作业到期', '保存设置']
- 必需证据类型：['requirement', 'design']
- 缺项：['是否允许不选，以及哪些提醒必须选择的要求']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R13 需要已确认的必填要求。画面列出两组提醒选项，但材料未说明保存前哪些项必须选择。
- 判据/方法定义：必填项在填写前可识别；适用：存在已知必填要求的表单字段；要求有来源。；检查：在填写前查看字段标记和整体说明，与已确认必填清单对照。；触发：已知必填字段既无字段标记也无清楚整体说明，提交前无法辨认必填要求。；弃权：明确无必填字段时不适用；哪些必填未知时证据不足；全部必填且有整体说明时未见问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R14 · 受格式限制的字段提供输入提示

- 检查 ID / 类型：`check-2f352d685082e045` / rule
- 计划：not_applicable；本任务的两项提醒均从列出的开关值中选择，不涉及用户按指定格式或长度录入内容。
- 对象：['课程提醒：开启、关闭', '作业到期：ON、OFF']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：R14 检查录入前的格式提示。两行都直接列出可选值，无需输入指定格式或长度的内容。
- 判据/方法定义：受格式限制的字段提供输入提示；适用：字段有已确认的格式、长度或有效值限制。；检查：对照限制来源，查看填写前可获得的字段名、提示与有效示例。；触发：限制已知，但填写前无可理解线索，用户必须猜测要求；或提示与已确认限制冲突。；弃权：确认无特定格式限制时不适用；限制未知或提示区域不可查时证据不足；有效示例已清楚表达时未见问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R15 · 高后果操作确认页说明对象和动作

- 检查 ID / 类型：`check-2f47b35c98c916b9` / rule
- 计划：not_applicable；当前是偏好编辑页，不是高后果操作确认页。“消息工具”的叉形图标也不能作为删除对象或造成损失的依据。
- 对象：['通知偏好卡片', '保存设置', '消息工具的叉形图标']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：R15 适用于高后果操作确认界面。本图是带有“保存设置”入口的偏好编辑页，没有待核对的高后果确认操作。
- 判据/方法定义：高后果操作确认页说明对象和动作；适用：已确认是后果较大的操作确认界面，动作、对象及必要后果要求可确定。；检查：检查确认文字与邻近内容能否支持核对动作、对象和必要后果。；触发：完整上下文仍只有泛化确认，无法核对具体对象/动作，或遗漏已明确会影响决定的后果。；弃权：确认不是高后果确认时不适用；后果、对象未知或说明裁切时证据不足；无需为观察而实际执行危险动作。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R16 · 重要图标操作具有可见含义线索

- 检查 ID / 类型：`check-edced33fe17dcf42` / rule
- 计划：needs_context；提醒选项和保存入口有文字。“消息工具”行有三个图标，但材料未说明调整提醒是否依赖它们，也未说明目标用户是否熟悉其含义。
- 对象：['消息工具行的折线、矩形、叉形图标']
- 必需证据类型：['design', 'statement']
- 缺项：['图标功能及其与调整提醒的关系', '若任务依赖图标，需目标用户及熟悉度依据', '对应设备可获得的图标说明设计']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R16 要求图标对主任务有明确作用。两行提醒选项和保存入口均有文字，但“消息工具”的三个图标是否参与调整提醒、目标用户是否熟悉其含义均未知。
- 判据/方法定义：重要图标操作具有可见含义线索；适用：有影响已知主任务的图标操作，目标用户和任务语境可确定。；检查：检查文字标签、邻近解释及有依据的通用含义；必要时查看可取得的悬停/聚焦说明，并注明设备条件。；触发：任务必需的自定义图标没有可见说明，且有依据表明其含义在本语境中不可辨认。；弃权：无重要图标对象时不适用；重要性或用户熟悉度影响结论但未知、辅助说明未取得时证据不足；不因无常驻文字自动报问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R20 · 无关信息不压过主要任务

- 检查 ID / 类型：`check-884c569f409333bd` / rule
- 计划：applicable；委托限定了提醒调整任务，可比较主题、文字大小和消息工具各行是否遮挡或挤占提醒选项及保存入口。
- 对象：['通知偏好卡片内各设置行', '保存设置按钮']
- 必需证据类型：['design', 'statement']
- 缺项：[]
- 执行 / 判断：executed / no_visible_issue
- 判断理由：就 TASK02 的定位任务而言，“课程提醒”行右侧是“开启／关闭”，“作业到期”行右侧是“ON／OFF”。其他设置各占一行，没有遮挡这两组选项或卡片右下角的蓝色“保存设置”按钮。
- 判据/方法定义：无关信息不压过主要任务；适用：主任务及内容相关性有依据，主要内容与竞争区域可取得。；检查：比较任务内容和装饰/推广/重复信息，说明具体干扰机制；高饱和或元素多不单独构成违反。；触发：有依据确认无关内容明显压制、遮挡或挤占关键任务内容，并指出具体区域与影响。；弃权：无相关比较对象时不适用；任务相关性未知或区域不全时证据不足；目标需要的角色展示/奖励说明不能仅凭面积大判无关。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R21 · 错误状态指明问题位置

- 检查 ID / 类型：`check-6ebe51bfc9f73c9d` / rule
- 计划：needs_context；仅有设置页当前画面，未提供已确认的错误状态，无法核对提示指向哪项设置或操作。
- 对象：['提醒调整或保存操作所关联的错误提示（待确认）']
- 必需证据类型：['design']
- 缺项：['含错误原文、位置及关联操作的错误态设计']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R21 检查错误提示指向的位置。本次只评审正常设置页的入口，画面中没有调整或保存错误提示可供定位。；计划中的适用条件或必要证据尚未满足，不能据此通过或判违规。
- 判据/方法定义：错误状态指明问题位置；适用：已取得明确错误状态及其相关任务/操作范围。；检查：查看错误提示与字段/操作关联，记录错误原文和位置；多错误逐项检查。；触发：错误状态已确认，相关区域完整却只有笼统提示，无法辨别应处理的字段或操作。；弃权：确认不是错误状态时不适用；错误范围在未取得区域或状态性质未知时证据不足；只缺字段高亮但提示已清楚定位时不报问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R22 · 错误提示给出修正办法

- 检查 ID / 类型：`check-4f0aea52ec948754` / rule
- 计划：needs_context；尚未确认错误及用户可采取的处理方式。页首“帮助中心”不足以说明某项错误如何修正。
- 对象：['提醒调整或保存出错后的修正说明（待确认）']
- 必需证据类型：['design', 'statement']
- 缺项：['错误态提示及其关联的修正说明', '该错误是否可由用户处理的依据']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R22 检查已呈现错误的修正说明。当前静态任务只需定位选项和保存入口，没有需要修正的错误对象。；计划中的适用条件或必要证据尚未满足，不能据此通过或判违规。
- 判据/方法定义：错误提示给出修正办法；适用：已确认错误状态，且存在用户可以执行的修正或后续处理。；检查：检查当前提示和明确关联的帮助/恢复入口，核对建议步骤是否可执行；执行结果由E05记录。；触发：错误及可行修正途径已知，但当前信息没有可执行线索，或所给线索与已确认处理方法冲突。；弃权：确认无用户可执行处理时本条不适用；可修正性未知或帮助入口内容未取得时证据不足；已有明确关联修正说明时未见问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### R23 · 错误提示使用用户可理解的语言

- 检查 ID / 类型：`check-c560a1a548a82de7` / rule
- 计划：needs_context；材料未给出错误原文或目标用户背景。设置选项 ON／OFF 不能作为错误提示评审。
- 对象：['提醒调整或保存操作的错误文案（待确认）']
- 必需证据类型：['design', 'statement']
- 缺项：['完整错误提示', '目标用户对提示用语的熟悉度依据']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R23 需要可评审的错误文案。当前画面中的 ON／OFF 是设置选项，画面没有面向用户的错误提示。；计划中的适用条件或必要证据尚未满足，不能据此通过或判违规。
- 判据/方法定义：错误提示使用用户可理解的语言；适用：存在面向已知目标用户的错误提示。；检查：记录错误原文，结合已知用户背景检查是否有可理解说明；技术码可作为辅助。；触发：面向非技术用户的错误信息只有内部码/异常栈/开发术语，且无可理解解释。；弃权：无错误提示对象时不适用；用户背景影响理解却未知、文字不清时证据不足；技术码同时附清楚说明或目标开发者确可理解时未见问题。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### R24 · 复杂任务提供就近帮助入口

- 检查 ID / 类型：`check-b1cbe309b14ad5b9` / rule
- 计划：needs_context；尚不清楚目标用户是否需要解释才能选择或保存提醒。画面可定位“帮助中心”，其内容及与任务的关系未知。
- 对象：['两类提醒的选项', '保存设置按钮', '帮助中心']
- 必需证据类型：['design', 'statement']
- 缺项：['目标用户在哪一步需要解释及原因', '若确有需要，与该步骤关联的说明或帮助内容']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：R24 需要明确哪一步必须向目标用户解释。材料未说明这种需要，也未提供页首“帮助中心”与提醒设置相关的内容。
- 判据/方法定义：复杂任务提供就近帮助入口；适用：已确认目标用户在某关键复杂/领域字段或步骤上需要解释才能完成任务。；检查：记录复杂性与用户需要的依据，查看邻近说明/示例/帮助入口及实际取得内容。；触发：解释需要已确认，当前可查范围既无可理解说明，也无清楚关联且可取得的帮助，必须脱离任务自行猜测含义。；弃权：确认无需要解释的对象时不适用；解释需要、用户知识或帮助内容未知时证据不足；专家也可能需特定业务解释，不自动排除。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)

### E01 · 关键任务路径衔接

- 检查 ID / 类型：`check-d7274928ea5c09b4` / method
- 计划：not_applicable；任务终点是指出提醒所在行、目标选项和保存入口。三者均在当前画面，无需到达另一页面或状态。
- 对象：['课程提醒行', '作业到期行', '卡片右下角的“保存设置”']
- 必需证据类型：['statement', 'design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：E01 检查跨页或跨状态的路径。TASK02 到指出两行选项和“保存设置”的位置即结束，所需入口均在同一画面。
- 判据/方法定义：关键任务路径衔接；对象：任务起点、动作入口、目标页面/状态和已声明终点。；适用：存在需要跨页或跨状态的任务，关系可由已确认要求、原型连接或实际路径建立。；触发：目标关系明确且入口条件满足，本次操作到达错误对象、陷入可复现死路或无法抵达明确必需的下一步，且已排除访问/工具阻断。；弃权：关系或目标未知、权限失败、工具未执行、原型未实现分支时证据不足；明确独立静态任务无连接对象时不适用。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E02 · 跨页面对象与信息一致性

- 检查 ID / 类型：`check-a2894af7076cb1f6` / method
- 计划：not_applicable；课程提醒和作业到期是两个不同设置，在所给状态中各展示一处，无同一设置的第二处值可供比对。
- 对象：['课程提醒行', '作业到期行']
- 必需证据类型：['design']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：E02 需要同一对象的两个可比位置。课程提醒和作业到期是不同设置，各出现一次。就 TASK01 而言，课程提醒的“开启”为蓝底白字，“关闭”为白底深字，画面指示当前选择“开启”。作业到期的 ON 和 OFF 共用浅色底，两侧均无独立选中标记，无法据图区分当前选择。
- 判据/方法定义：跨页面对象与信息一致性；对象：同一角色、订单、任务或其他对象在不同页面/状态中的名称、属性、数量和指代。；适用：至少两个材料位置已确认属于同一对象、可比版本与可比条件。；触发：同一对象与条件已确认，名称/属性/数量发生无依据矛盾或错误传递，且不是已确认的合法变化。；弃权：对象同一性、版本或允许变化条件未知时证据不足；只有一个对象位置时不适用。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E04 · 返回取消后的任务恢复

- 检查 ID / 类型：`check-e2bd07e048c4d3ca` / method
- 计划：not_applicable；委托限定从静态页辨认操作入口，TASK02 到找到“保存设置”为止，无返回、取消或重进后恢复选择的任务分支。
- 对象：['TASK02 的保存入口定位终点']
- 必需证据类型：['statement']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：E04 检查返回、取消或重新进入后的恢复。TASK02 的终点是找到保存入口，任务中没有上述分支。
- 判据/方法定义：返回取消后的任务恢复；对象：返回、取消、退出再进入时的数据、选择、进度及定位。；适用：任务包含返回/取消/恢复分支，且预期的保留或重置要求可确定。；触发：返回/取消后的状态与已确认要求矛盾，造成已证实的任务丢失、错误续接或不应保留的数据残留。；弃权：保留规则不明、未执行分支或新旧状态不可比时证据不足；无返回/取消分支时不适用；不默认所有进度都必须保留。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E05 · 异常分支与恢复路径

- 检查 ID / 类型：`check-e2c9e462f51a449a` / method
- 计划：not_applicable；本次任务仅要求在给定画面指出调整和保存的位置，任务步骤不含触发异常或从异常恢复。
- 对象：['TASK02 的正常状态入口定位范围']
- 必需证据类型：['statement']
- 缺项：[]
- 执行 / 判断：executed / not_applicable
- 判断理由：E05 检查异常恢复路径。本次仅在正常设置页辨认入口，任务范围明确不含异常分支。
- 判据/方法定义：异常分支与恢复路径；对象：已取得的网络/输入/业务异常状态及可执行恢复步骤。；适用：已观察异常或提供明确异常设计，并存在应向用户交付的处理/恢复方式。；触发：条件明确且实际可测，恢复入口失效、进入同一无解循环或恢复结果违反明确要求；静态设计缺已确认必需分支只报设计层遗漏。；弃权：不能安全触发异常、无恢复依据或实际结果未取得时证据不足；任务确认无本条异常对象时不适用，不以未遇错误证明无错误。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E06 · 前置条件与操作开放状态

- 检查 ID / 类型：`check-87b3c3d4db7bdffa` / method
- 计划：needs_context；可定位“保存设置”，但未说明保存是否需要先修改选项。仅凭按钮底色无法核对开放条件。
- 对象：['“保存设置”按钮']
- 必需证据类型：['requirement', 'design']
- 缺项：['保存是否有前置条件的项目说明', '若有条件，标明条件满足与未满足时按钮状态的设计']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：E06 需要保存的前置条件及其满足情况。材料未说明是否必须先修改选项，蓝色按钮只能用于定位，无法据此判断保存是否开放。
- 判据/方法定义：前置条件与操作开放状态；对象：任务前置条件、按钮可用/禁用状态及操作结果。；适用：项目明确规定某操作的前置条件，且有可比状态或测试方式。；触发：已确认条件与当前操作开放/拦截行为矛盾；仅凭按钮外观可疑只形成待验证线索，不声称业务已绕过。；弃权：前置条件、账号状态或实际执行未知时证据不足；明确无该类条件时不适用；需真实发奖等未授权动作保持阻断。
- 证据链：
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-150eb9bdafaab863` / goal
- 计划：needs_context；委托说明了要检查什么，但未给出产品对两项提醒及选中标记的正式要求。
- 对象：['评审委托原文', '两项提醒的选项及选中标记']
- 必需证据类型：['requirement', 'design']
- 缺项：['适用于该版提醒选项与状态表达的已确认要求原文']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：程序按当前任务内全部覆盖单元的明确目标/要求根项汇总，未知或未执行不算满足。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E07 · 目标与明确要求落实

- 检查 ID / 类型：`check-86bf0b3cd6e2a017` / goal
- 计划：needs_context；画面展示了行内选项和保存按钮，但材料未规定调整与保存入口应如何呈现，无法建立产品验收对照。
- 对象：['两项提醒的调整入口', '“保存设置”按钮']
- 必需证据类型：['requirement', 'design']
- 缺项：['适用于该版调整与保存入口的已确认要求原文']
- 执行 / 判断：executed / insufficient_evidence
- 判断理由：程序按当前任务内全部覆盖单元的明确目标/要求根项汇总，未知或未执行不算满足。
- 判据/方法定义：目标与明确要求落实；对象：已确认目标、可检查子要求与相应设计/实现/观察。；适用：存在明确目标或要求；可检查部分可拆分，抽象效果需要独立验证。；触发：至少一项已确认且可检查要求有支持违反的证据；若目标本身未知/未确认，不形成正式不符合项。；弃权：目标含义、阈值或必要证据缺失则相应子项证据不足；明确不在本轮范围标范围排除，不伪装met。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

### E08 · 跨职能要求冲突识别与处理

- 检查 ID / 类型：`check-958846aae414cc12` / conflict
- 计划：not_applicable；已提交材料分别是评审委托和静态设计，未形成针对同一提醒状态的两项职能要求或约束。
- 对象：['评审委托原文', '通知偏好设计画面']
- 必需证据类型：['statement', 'design']
- 缺项：[]
- 执行 / 判断：executed / needs_clarification
- 判断理由：TASK01：“课程提醒”的“开启”为蓝底、“关闭”为白底，画面指示当前选择“开启”；“作业到期”的 ON 和 OFF 共用浅色底，未见可区分当前选择的标记。评审委托未指定任一提醒应处于何种状态，材料中不存在对同一状态互不相容的要求。；计划已依据适用条件证据判定不适用，模型关于执行或补充证据的结论不改为未通过。
- 判据/方法定义：跨职能要求冲突识别与处理；对象：策划/产品、设计、开发材料或用户决定对同一对象的要求与限制。；适用：两项以上要求/约束指向同一对象，可能无法同时满足或存在证据描述矛盾。；触发：原文可定位且同范围，两项要求无法同时成立。输出conflict记录，不未经裁决转换为产品违规。已裁决正式要求被实现违反时转E07。；弃权：同一对象或版本关系未知则待澄清；只有单份要求、或解释后可同时满足则不构成冲突。
- 证据链：
- `ev-0505f5c1a4a14b61b1364d9b21983f16` / statement / 来源 `src-9e806f11666a4996a5284eeba516d441` / 版本 context-1
  - 定位：文档分块 0/1；行 1-1；字符 0-36
  - 内容：从这张设置页判断如何查看与调整通知偏好，检查选项、操作和当前状态的表达。
  - 原始记录：[`artifact-369638fd512d43d591a4f64562e0ac55`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-369638fd512d43d591a4f64562e0ac55.txt)
  - 原始文件：[`artifact-260a44ce42d54e189598ef8c72d981ea`](artifacts/ev-0505f5c1a4a14b61b1364d9b21983f16-artifact-260a44ce42d54e189598ef8c72d981ea.txt)
- `ev-6feecfb26247416bab7e0910276f6258` / design / 来源 `src-da076a3af03d4740afa0d4552a1aef4a` / 版本 490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7
  - 定位：{"sha256": "490a35029c5a2cd09ff5863502d82a2f9c10a169039442ac97ea1654586d71a7", "width": 1440, "height": 900, "controls": [], "partial": false}
  - 内容：用户提供的静态界面，不证明点击后行为。
  - 画面：[`artifact-71c698b3e9834b23af5880130120d9b7`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-71c698b3e9834b23af5880130120d9b7.bin)
  - 视觉分析：[`artifact-9e3b945a873c4fb39d0442e1c3f4ad47`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-9e3b945a873c4fb39d0442e1c3f4ad47.json)
  - 叠加图 overlay-elements.png：[`artifact-7569e6fa9ffc4fcb84010c3e9e387885`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-7569e6fa9ffc4fcb84010c3e9e387885.png)
  - 叠加图 overlay-focus.png：[`artifact-731bc46f11fa4598b76745706aadc129`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-731bc46f11fa4598b76745706aadc129.png)
  - 叠加图 overlay-flow.png：[`artifact-be583ead2de74c4681f85bf28f1e9686`](artifacts/ev-6feecfb26247416bab7e0910276f6258-artifact-be583ead2de74c4681f85bf28f1e9686.png)

## 八、发现与修改建议

当前没有通过证据核验的候选发现。

## 九、问题、冲突与业务决定

- `question-3d86375ef6a44effb006544f33ed915b` [未回答] 是否授权动作：在同一张截图中对照“开启”的蓝底与“关闭”的白底，检查 ON 和 OFF 是否也有可区分的选中标记，并核对各组选项与行标签、保存入口的位置。；影响检查：未关联；答复：无
- `question-d8406096bbdb4be5af56d2da31bc906f` [未回答] 设计中，这张图的“作业到期”一行应呈现什么状态（ON、OFF 或尚未选择）？该控件当时是否可用？；影响检查：check-0af2ad49d3698698, check-415dd13a3cbe551e, check-ec74622a8c0def8a；答复：无

## 十、模型调用、输入与原始输出

| 调用 | 阶段/操作 | 模型 | 输入索引 | 输出摘要 | 原始响应 |
| --- | --- | --- | --- | --- | --- |
| `call-bc8f990805184d8caa6b07f1dd9f1bbb` | T03 / understand | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 目标 0；要求 0；意见 0；冲突 0 | [`artifact-4fc653ad18df4aaf99b499b512ef5c2f`](raw/call-bc8f990805184d8caa6b07f1dd9f1bbb-artifact-4fc653ad18df4aaf99b499b512ef5c2f.txt) |
| `call-a36671dc9905480abd7205b8cf96402a` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['R01', 'R02', 'R03', 'R04', 'R05', 'R06', 'R07', 'R08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08 | [`artifact-fa836668711640c7bd7f932c8c249238`](raw/call-a36671dc9905480abd7205b8cf96402a-artifact-fa836668711640c7bd7f932c8c249238.txt) |
| `call-1a5fb90c52a34bb28c7fb093eb1d2161` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['R09', 'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16 | [`artifact-626dcd01c44a447d98e941a6bbddb1b7`](raw/call-1a5fb90c52a34bb28c7fb093eb1d2161-artifact-626dcd01c44a447d98e941a6bbddb1b7.txt) |
| `call-2894d51bb7c741daa260e966335c655d` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['R17', 'R18', 'R19', 'R20', 'R21', 'R22', 'R23', 'R24'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 9 项：R17, R17, R18, R19, R20, R21, R22, R23, R24 | [`artifact-20446ef673514d4c866f067e364dae6c`](raw/call-2894d51bb7c741daa260e966335c655d-artifact-20446ef673514d4c866f067e364dae6c.txt) |
| `call-6285d28c6ed04164ad2e3ede9dcc34ee` | T04 / plan_checks | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08'], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 计划 9 项：E01, E02, E03, E04, E05, E06, E07, E07, E08 | [`artifact-ddf208b817c84a7e9662fdd90abf913c`](raw/call-6285d28c6ed04164ad2e3ede9dcc34ee-artifact-ddf208b817c84a7e9662fdd90abf913c.txt) |
| `call-ec8b509087024302b49a72e59cc8f8d0` | T05 / plan | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': [], 'check_ids': [], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | ready_for_review=True；动作 observe | [`artifact-a712be77ee1343e6a7b84026a1719185`](raw/call-ec8b509087024302b49a72e59cc8f8d0-artifact-a712be77ee1343e6a7b84026a1719185.txt) |
| `call-c2b6f0bf93b44dfeb5ad671ed9f54167` | T06 / judge | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['R17', 'R17', 'E03', 'R18', 'R19', 'R06', 'R12', 'R01', 'R02', 'R03', 'R04', 'R05', 'R07', 'R08', 'R09', 'R10'], 'check_ids': ['check-7de4b434ec81105e', 'check-0af2ad49d3698698', 'check… | 判断 16；发现 0；状态 insufficient_evidence, no_visible_issue, not_applicable | [`artifact-9976581252394c42889cd08a5ef36536`](raw/call-c2b6f0bf93b44dfeb5ad671ed9f54167-artifact-9976581252394c42889cd08a5ef36536.txt) |
| `call-4ccf5bd95a2c47658259351968ad6c7c` | T06 / judge | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['R11', 'R13', 'R14', 'R15', 'R16', 'R20', 'R21', 'R22', 'R23', 'R24', 'E01', 'E02', 'E04', 'E05', 'E06', 'E07'], 'check_ids': ['check-10644cfee856c4f3', 'check-8cbced4a72a0ab42', 'check… | 判断 16；发现 0；状态 insufficient_evidence, no_visible_issue, not_applicable | [`artifact-1a82b39c9af6404d9be0bbd9fbf635b5`](raw/call-4ccf5bd95a2c47658259351968ad6c7c-artifact-1a82b39c9af6404d9be0bbd9fbf635b5.txt) |
| `call-050cfc0d105c4b9492b39b8536f74318` | T06 / judge | codex_cli/gpt-6-astra | 原始索引：{'context_version': 1, 'operation_mode': '', 'source_ids': ['src-da076a3af03d4740afa0d4552a1aef4a', 'src-9e806f11666a4996a5284eeba516d441'], 'evidence_ids': ['ev-0505f5c1a4a14b61b1364d9b21983f16', 'ev-6feecfb26247416bab7e0910276f6258'], 'image_evidence_ids': ['ev-6feecfb26247416bab7e0910276f6258'], 'check_refs': ['E07', 'E08'], 'check_ids': ['check-86bf0b3cd6e2a017', 'check-958846aae414cc12'], 'finding_ids': [], 'previous_finding_ids': [], 'evidence_gap_count': 0, 'evidence_gap_refs': []} | 判断 2；发现 0；状态 insufficient_evidence, no_conflict | [`artifact-f84f8acfa0af41d88b94a59c683be2e1`](raw/call-050cfc0d105c4b9492b39b8536f74318-artifact-f84f8acfa0af41d88b94a59c683be2e1.txt) |

### call-bc8f990805184d8caa6b07f1dd9f1bbb · T03 understand

- 状态：validated；尝试：1；耗时：19610ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 26117, 'cached_input_tokens': 15872, 'cache_write_input_tokens': 0, 'output_tokens': 614, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：目标 0；要求 0；意见 0；冲突 0
- 完整原始响应：[`artifact-4fc653ad18df4aaf99b499b512ef5c2f`](raw/call-bc8f990805184d8caa6b07f1dd9f1bbb-artifact-4fc653ad18df4aaf99b499b512ef5c2f.txt)

### call-a36671dc9905480abd7205b8cf96402a · T04 plan_checks

- 状态：validated；尝试：1；耗时：33953ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28323, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1870, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R01, R02, R03, R04, R05, R06, R07, R08
- 完整原始响应：[`artifact-fa836668711640c7bd7f932c8c249238`](raw/call-a36671dc9905480abd7205b8cf96402a-artifact-fa836668711640c7bd7f932c8c249238.txt)

### call-1a5fb90c52a34bb28c7fb093eb1d2161 · T04 plan_checks

- 状态：validated；尝试：1；耗时：34515ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28011, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 1943, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["R09", "R10", "R11", "R12", "R13", "R14", "R15", "R16"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 8 项：R09, R10, R11, R12, R13, R14, R15, R16
- 完整原始响应：[`artifact-626dcd01c44a447d98e941a6bbddb1b7`](raw/call-1a5fb90c52a34bb28c7fb093eb1d2161-artifact-626dcd01c44a447d98e941a6bbddb1b7.txt)

### call-2894d51bb7c741daa260e966335c655d · T04 plan_checks

- 状态：validated；尝试：1；耗时：38203ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 30636, 'cached_input_tokens': 15872, 'cache_write_input_tokens': 0, 'output_tokens': 2290, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["R17", "R18", "R19", "R20", "R21", "R22", "R23", "R24"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 9 项：R17, R17, R18, R19, R20, R21, R22, R23, R24
- 完整原始响应：[`artifact-20446ef673514d4c866f067e364dae6c`](raw/call-2894d51bb7c741daa260e966335c655d-artifact-20446ef673514d4c866f067e364dae6c.txt)

### call-6285d28c6ed04164ad2e3ede9dcc34ee · T04 plan_checks

- 状态：validated；尝试：1；耗时：36781ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28193, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 2312, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08"], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：计划 9 项：E01, E02, E03, E04, E05, E06, E07, E07, E08
- 完整原始响应：[`artifact-ddf208b817c84a7e9662fdd90abf913c`](raw/call-6285d28c6ed04164ad2e3ede9dcc34ee-artifact-ddf208b817c84a7e9662fdd90abf913c.txt)

### call-ec8b509087024302b49a72e59cc8f8d0 · T05 plan

- 状态：validated；尝试：1；耗时：13969ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 28978, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 339, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": [], "check_ids": [], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：ready_for_review=True；动作 observe
- 完整原始响应：[`artifact-a712be77ee1343e6a7b84026a1719185`](raw/call-ec8b509087024302b49a72e59cc8f8d0-artifact-a712be77ee1343e6a7b84026a1719185.txt)

### call-c2b6f0bf93b44dfeb5ad671ed9f54167 · T06 judge

- 状态：validated；尝试：1；耗时：38000ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 37692, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1924, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["R17", "R17", "E03", "R18", "R19", "R06", "R12", "R01", "R02", "R03", "R04", "R05", "R07", "R08", "R09", "R10"], "check_ids": ["check-7de4b434ec81105e", "check-0af2ad49d3698698", "check-415dd13a3cbe551e", "check-71234159b928ef65", "check-ae6d7f132427e23c", "check-61ea34a0297f3bed", "check-ec74622a8c0def8a", "check-0a9e41533c8cdeb1", "check-95903e428c6c287f", "check-41092d8e37c0af4e", "check-53c2ba44ff91d3c1", "check-68a85fab8bacc5d1", "check-963e46c5f11f0623", "check-ca2972b3610d5d1a", "check-1d15677138683765", "check-86bd669bec9be07a"], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：判断 16；发现 0；状态 insufficient_evidence, no_visible_issue, not_applicable
- 完整原始响应：[`artifact-9976581252394c42889cd08a5ef36536`](raw/call-c2b6f0bf93b44dfeb5ad671ed9f54167-artifact-9976581252394c42889cd08a5ef36536.txt)

### call-4ccf5bd95a2c47658259351968ad6c7c · T06 judge

- 状态：validated；尝试：1；耗时：35797ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 37717, 'cached_input_tokens': 12544, 'cache_write_input_tokens': 0, 'output_tokens': 1900, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["R11", "R13", "R14", "R15", "R16", "R20", "R21", "R22", "R23", "R24", "E01", "E02", "E04", "E05", "E06", "E07"], "check_ids": ["check-10644cfee856c4f3", "check-8cbced4a72a0ab42", "check-2f352d685082e045", "check-2f47b35c98c916b9", "check-edced33fe17dcf42", "check-884c569f409333bd", "check-6ebe51bfc9f73c9d", "check-4f0aea52ec948754", "check-c560a1a548a82de7", "check-b1cbe309b14ad5b9", "check-d7274928ea5c09b4", "check-a2894af7076cb1f6", "check-e2bd07e048c4d3ca", "check-e2c9e462f51a449a", "check-87b3c3d4db7bdffa", "check-150eb9bdafaab863"], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：判断 16；发现 0；状态 insufficient_evidence, no_visible_issue, not_applicable
- 完整原始响应：[`artifact-1a82b39c9af6404d9be0bbd9fbf635b5`](raw/call-4ccf5bd95a2c47658259351968ad6c7c-artifact-1a82b39c9af6404d9be0bbd9fbf635b5.txt)

### call-050cfc0d105c4b9492b39b8536f74318 · T06 judge

- 状态：validated；尝试：1；耗时：13172ms
- 运行范围 / 输入来源：current / recorded
- 用量：{'input_tokens': 29319, 'cached_input_tokens': 12416, 'cache_write_input_tokens': 0, 'output_tokens': 361, 'reasoning_output_tokens': 0}
- 输入索引：{"context_version": 1, "operation_mode": "", "source_ids": ["src-da076a3af03d4740afa0d4552a1aef4a", "src-9e806f11666a4996a5284eeba516d441"], "evidence_ids": ["ev-0505f5c1a4a14b61b1364d9b21983f16", "ev-6feecfb26247416bab7e0910276f6258"], "image_evidence_ids": ["ev-6feecfb26247416bab7e0910276f6258"], "check_refs": ["E07", "E08"], "check_ids": ["check-86bf0b3cd6e2a017", "check-958846aae414cc12"], "finding_ids": [], "previous_finding_ids": [], "evidence_gap_count": 0, "evidence_gap_refs": []}
- 输出来源：判断 2；发现 0；状态 insufficient_evidence, no_conflict
- 完整原始响应：[`artifact-f84f8acfa0af41d88b94a59c683be2e1`](raw/call-050cfc0d105c4b9492b39b8536f74318-artifact-f84f8acfa0af41d88b94a59c683be2e1.txt)

## 十一、复审、历史与限制

- 完整性：`partial`
- 当前运行限制：逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.
- 会话历史警告：逐屏技术审查未启用：Reviewer config was not found at config/reviewer.toml.；存在待授权动作；只判断现有证据，不把待执行路径算通过。
- 本轮没有登记复审项。

## 十二、可复核文件

报告包应同时包含 `report.json`、`process.json`、`checks.json`、`evidence.json`、`findings.json`、`stages/T01.json`—`stages/T10.json`、`report-showcase.md`、`report-summary.md`、`method/` 方法原文与哈希以及原始响应附件。单独打开 Markdown 时，模型原始响应和证据画面仍可通过会话 artifact 接口按 ID 读取。

> 本报告引用模型调用 9 次；测试夹具否。